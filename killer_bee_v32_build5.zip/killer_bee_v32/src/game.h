// =====================================================================
//  KILLER BEE for Vircon32 - gameplay core: constants and state
//  Written in the Vircon32 C dialect (arrays are "type[n] name").
//  tools/to_host_c.py converts it to standard C for the PC test build.
// =====================================================================
#ifndef GAME_H
#define GAME_H

#include "levels.h"

// ---------------------------------------------------------------- screen / grid
#define SCREEN_W 640
#define SCREEN_H 360
#define CW 20                 // one NES 8x8 cell becomes 20x12 pixels
#define CH 12
#define GRID_COLS 32
#define GRID_ROWS 30
#define GROUND_ROW 26
#define PLANK 6               // a platform plank is the top 6 px of its cell
#define FP 256                // positions and speeds are fixed point (1/256 px)

// ---------------------------------------------------------------- states
#define ST_TITLE 0
#define ST_SETUP 1
#define ST_PLAY 2
#define ST_FREEZE 3
#define ST_OVER 4
#define ST_PAUSE 5

#define WIN_MILITARY 0
#define WIN_ECONOMY 1
#define WIN_SNAIL 2
#define WIN_HOOPS 3                   // NEW: bonus round won

// ---------------------------------------------------------------- rules (same as NES)
#define ECON_GOAL 8
#define QUEEN_LIVES 3
#define SNAIL_STEP 14             // frames per snail step
#define SNAIL_STEP_FP 384         // 1.5 px per step (NES: 1 px)
#define SNAIL_FEED_FRAMES 180     // NEW: a fed berry doubles the snail's speed for 3 s
#define SNAIL_CLOSE_PCT 35        // CPU feeds the snail when <= 35% of the track is left
#define QUEEN_RESPAWN 150
#define QUEEN_SHIELD 120
#define WORKER_RESPAWN 150
#define DASH_FRAMES 14
#define DASH_COOL 34
#define DASH_LIVE 12              // eatk <= 12: the 2-frame wind-up is over
#define YOYO_SPIN 24
#define YOYO_COOL 90
#define SONG_COOL 240
#define FREEZE_FRAMES 100

// NEW: down-dash dive (Down + B)
#define DIVE_SPEED 1536            // 6 px/frame straight down
#define DIVE_MAX 70                // safety cap (e.g. diving down the Wrap Hive pit)
#define STUN_FRAMES 30             // half a second of shaking after a missed dive

// NEW: thrown berries (B while carrying)
#define MAX_TB 10                  // berries in the air or lying on the board
#define TB_VX 896                  // 3.5 px/frame forward
#define TB_VX_RUN 384              // +1.5 px/frame when running the same way
#define TB_VY (-1152)              // -4.5 px/frame upward
#define TB_GRAV 72                 // same gravity as workers
#define TB_LIFE 900                // a dropped berry stays 15 s, then regrows elsewhere

// NEW: HONEYCOMB HOOPS bonus round
#define HC_W 40                    // honeycomb: 2 x 5 holes
#define HC_H 100
#define HC_X0 50                   // blue honeycomb x (yellow is the mirror image)
#define HC_TOP 76
#define HC_BOTTOM 212              // honeycomb y at the bottom: its base touches the ground (312)
#define HC_HALF 180                // 3 s down, 3 s up
#define HOOPS_GOAL 10
#define NUM_VINES 8
#define VINE_REGROW 300            // 5 s
#define PLACE_FRAMES 40            // a worker on the ground placing a berry into the hole

// CPU difficulty
#define DIFF_EASY 0
#define DIFF_NORMAL 1
#define DIFF_HARD 2

// ---------------------------------------------------------------- physics (NES x 1.5)
#define QW 24
#define QH 24
#define WW 12
#define WH 12
#define Q_AIR_SPEED 768           // 3.0 px/frame
#define Q_GROUND_SPEED 384        // 1.5
#define Q_DASH_SPEED 1152         // 4.5
#define Q_FLAP (-1152)            // -4.5
#define Q_GRAV 42
#define Q_VMAX 768
#define W_SPEED 384
#define W_JUMP (-1824)            // -7.125
#define W_GRAV 72
#define W_VMAX 1536
#define DROP_FRAMES 16
#define STEP_UP 7                 // feet up to 7 px into a plank: step onto it
#define CEIL_Y 60
#define GROUND_Y_QUEEN 288
#define GROUND_Y_WORKER 300
#define WRAP_DY 300               // pit <-> ceiling gap distance

// ---------------------------------------------------------------- buttons
#define BTN_RIGHT 1
#define BTN_LEFT 2
#define BTN_UP 4
#define BTN_DOWN 8
#define BTN_A 16
#define BTN_B 32
#define BTN_SELECT 64
#define BTN_START 128

// ---------------------------------------------------------------- entities
#define MAXE 8
// platform settings (the PS1 edition overrides these before including game.h)
#ifndef MAX_PLAYERS
#define MAX_PLAYERS 4
#endif
#ifndef DEFAULT_TEAM
#define DEFAULT_TEAM(p) ((p) & 1)
#endif
#ifndef ART_SETS
#define ART_SETS 2                   // the Vircon32 edition has 3 (adds NES classic)
#endif
#ifndef TITLE_ROWS
#define TITLE_ROWS 3                 // the PS1 edition adds a 4th row: MUSIC
#endif
#ifndef FIXED_TEAM_SIZE
#define FIXED_TEAM_SIZE 0
#endif

struct Ent
{
    int x, y;            // fixed point, top-left
    int vy;
    int ground, face;    // face: 0 right, 1 left
    int alive, timer;    // dead: respawn countdown; alive queen: shield
    int carry, atk, cool, drop, anim;
    int inp, inpn;       // held / newly pressed virtual buttons
    int block;           // a wall stopped horizontal movement this frame
    int warrior, spin, yox, yoy;
    int team, isq, slot; // slot: 0 = queen, 1.. = workers
    int spawnx, spawny, spawnface;
    // AI memory
    int ai_lastx, ai_stuck, ai_alt, ai_altx, ai_jdir, ai_launch, ai_lrow, ai_ltx;
    int ai_lasty, ai_lastin, ai_nodrop;   // stuck / failed-drop memory
    int dive, stun;                       // NEW: down-dash dive frames, stun countdown
    int place;                            // NEW: Hoops - frames left placing a berry
};

// ---------------------------------------------------------------- global state
Ent[MAXE] ents;
int num_ents;
int team_size;                       // bees per team (queen + workers)
int[2] lives;
int[2] berries;
int snail_x;                         // fixed point
int snail_rider;
int snail_timer;
int snail_anim;
int snail_row;
int snail_ry;
int snail_rem;                       // sub-step remainder for smooth movement
int snail_boost;                     // NEW: frames of fed-berry boost left
int snail_boost_team;                // the team whose rider the boost helps
int winner;
int win_type;
int game_state;
int state_timer;
int frame;
int cur_level;
int last_level;
int force_level;                     // test hook: 0 random, n = level n-1
int[NUM_BERRIES] berry_on;
int[NUM_BERRIES] berry_tmr;
int[NUM_BERRIES] berry_px;
int[NUM_BERRIES] berry_py;
int[NUM_BERRIES] berry_row;
int fx_x, fx_y, fx_t, fx_kind;       // hit spark / clash effect
int[MAX_TB] tb_on;                   // 0 free, 1 flying, 2 lying on a platform
int[MAX_TB] tb_x;                    // fixed point, top-left of a 12x12 berry
int[MAX_TB] tb_y;
int[MAX_TB] tb_vx;
int[MAX_TB] tb_vy;
int[MAX_TB] tb_team;                 // thrower's team
int[MAX_TB] tb_age;
int rng_state;
int hunt_first;                      // which CPU queen hunts first this match

// level tables for the current board
int[960] lvl_grid;
int[30] lvl_rowidx;
int[160] lvl_launch_l;
int[160] lvl_launch_r;
int[LP_COUNT] lp;
int[800] lvl_throw;                  // NEW: throw table for this board (see levels.h)

// players: up to 4 humans; the rest of the bees are CPU
int[MAX_PLAYERS] pl_joined;          // set on the team-select screen
int[MAX_PLAYERS] pl_team;
int[MAX_PLAYERS] pl_wantq;           // 1 = wants the queen
int[MAX_PLAYERS] pl_locked;
int[MAX_PLAYERS] pl_lockorder;
int[MAX_PLAYERS] pl_ctrl;            // entity this player steers (-1 none)
int[MAX_PLAYERS] pad;                // held buttons this frame
int[MAX_PLAYERS] pad_new;            // pressed this frame
int[MAX_PLAYERS] pl_bumped;          // flash: asked for queen, got worker
int lock_counter;
int cpu_all;                         // test hook: every bee is CPU-driven
int difficulty;                      // DIFF_EASY / NORMAL / HARD (title menu)
int art_set;                         // 0 clean, 1 grunge, 2 NES classic (title menu)
// NEW: bonus round state
int bonus_mode;                      // 1 while Honeycomb Hoops is being played
int bonus_pending_crown;             // team whose queen starts the next match with a 4th crown (-1 none)
int[2] hoops;                        // holes filled per team
int hc_phase;
int hc_y;                            // both honeycombs share the same height (mirror-fair)
int[NUM_VINES] vine_on;
int[NUM_VINES] vine_tmr;
int[NUM_VINES] vine_x;               // berry centre
int[NUM_VINES] vine_y;
int[NUM_VINES] vine_top;             // where the vine hangs from
int title_sel;                       // title menu row
int music_on;                        // PS1 title menu: MUSIC 1 = MY SONGS, 2 = SYNTH, 0 = OFF

// events for the presentation layer (sound / music), cleared each frame
#define MAX_EVENTS 24
int[MAX_EVENTS] ev_list;
int ev_count;
#define EV_JUMP 0
#define EV_FLAP 1
#define EV_PICK 2
#define EV_DEPOSIT 3
#define EV_HITQ 4
#define EV_MENU 5
#define EV_DASH 6
#define EV_HIT 7
#define EV_CLANK 8
#define EV_ARM 9
#define EV_YOYO 10
#define EV_RIDE 11
#define EV_MUSIC 12          // big moment: switch song
#define EV_WIN 13
#define EV_LOCK 14
#define EV_BUMP 15
#define EV_DIVE 16
#define EV_STUN 17
#define EV_FEED 18
#define EV_THROW 19
#define EV_CATCH 20
#define EV_SCORE_HOLE 21
#define EV_VINE 22

#endif
