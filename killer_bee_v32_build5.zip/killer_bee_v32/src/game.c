// =====================================================================
//  KILLER BEE for Vircon32 - gameplay core
//  A translation of the NES 6502 routines (src/main.s) to C. Comments name
//  the NES routine each function comes from.
// =====================================================================
#include "game.h"

// ---------------------------------------------------------------- helpers
int iabs(int v) { if (v < 0) return -v; return v; }
int imin(int a, int b) { if (a < b) return a; return b; }
int imax(int a, int b) { if (a > b) return a; return b; }

int rand8()
{
    // xorshift; deterministic for tests
    if (rng_state == 0) rng_state = 0x2545F491;
    rng_state = rng_state ^ (rng_state << 13);
    rng_state = rng_state ^ ((rng_state >> 17) & 0x7FFF);
    rng_state = rng_state ^ (rng_state << 5);
    return (rng_state >> 4) & 255;
}

void emit(int ev)
{
    if (ev_count < MAX_EVENTS) { ev_list[ev_count] = ev; ev_count++; }
}

// fixed point -> pixel. FAIRNESS: round to nearest, halves to the even pixel.
// Rounding down (v >> 8) is not mirror-symmetric: blue at 146.6 became 146 but
// the mirrored yellow at 481.4 became 481, not 482, so every pixel threshold was
// one pixel off for one team. With halves-to-even and an even mirror axis
// (640 - bee width), mirrored positions always give mirrored pixels.
// Branch-free macro (this runs very often): add 127, plus 1 when the integer
// part is odd, then shift.
// NOTE: on Vircon32 ">>" does NOT keep the sign of negative numbers (it is a
// logical shift: -512 >> 8 gave 16777214), so the value is first offset by an
// even 2^24 to keep it positive, then the offset (65536 px) is removed.
#define px(v) (((((v) + 16777216) + 127 + ((((v) + 16777216) >> 8) & 1)) >> 8) - 65536)

int ent_w(Ent* e) { if (e->isq) return QW; return WW; }
int ent_h(Ent* e) { if (e->isq) return QH; return WH; }

// horizontal wrap on open-sided boards: pixel x -> 0..639
int wrapx(int x)
{
    while (x < 0) x += SCREEN_W;
    while (x >= SCREEN_W) x -= SCREEN_W;
    return x;
}

// signed horizontal distance b - a, across the seam on open-sided boards
int dxs(int a, int b)
{
    int d = b - a;
    if (lp[LP_SIDE])
    {
        while (d >= SCREEN_W / 2) d -= SCREEN_W;
        while (d < -SCREEN_W / 2) d += SCREEN_W;
    }
    return d;
}

// ---------------------------------------------------------------- level queries
int grid_at(int col, int row)
{
    if (row < 0) return 0;
    if (row >= GRID_ROWS) return 1;               // below the screen counts as solid
    if (lp[LP_SIDE]) col = (col % GRID_COLS + GRID_COLS) % GRID_COLS;
    if (col < 0 || col >= GRID_COLS) return 0;
    return lvl_grid[row * GRID_COLS + col];
}
int is_plat(int col, int row) { return grid_at(col, row) & 1; }      // NES is_plat
int is_wall(int col, int row)                                        // NES is_wall
{
    if (row < 0 || row >= GRID_ROWS) return 0;
    return grid_at(col, row) & 2;
}
int colof(int pxx) { if (lp[LP_SIDE]) pxx = wrapx(pxx); if (pxx < 0) return -1; return pxx / CW; }
int rowof(int pyy) { if (pyy < 0) return -1; return pyy / CH; }

// NES check_under: is there a platform under entity e in tile row `row`?
int check_under(Ent* e, int row)
{
    int x = px(e->x);
    int w = ent_w(e);
    if (is_plat(colof(x + 3), row)) return 1;
    if (is_plat(colof(x + w - 4), row)) return 1;
    return 0;
}

// NES wall_below: a wall directly under the platform e stands on
int wall_below(Ent* e)
{
    int x = px(e->x);
    int row = rowof(px(e->y) + ent_h(e)) + 1;
    if (is_wall(colof(x + 3), row)) return 1;
    if (is_wall(colof(x + ent_w(e) - 4), row)) return 1;
    return 0;
}

// NES wall_rows: a wall tile in column `col` overlapping e's body rows
int wall_rows(Ent* e, int col)
{
    int y = px(e->y);
    int r0 = rowof(y);
    int r1 = rowof(y + ent_h(e) - 1);
    int r;
    for (r = r0; r <= r1; r++)
        if (is_wall(col, r)) return 1;
    return 0;
}

// NES shaft_clamp: inside the ceiling gap or the pit, bees stay in the shaft
void shaft_clamp(Ent* e)
{
    if (!lp[LP_WRAP]) return;
    int y = px(e->y);
    int w = ent_w(e);
    if (y < CEIL_Y || y + ent_h(e) >= GROUND_ROW * CH + 1)
    {
        if (px(e->x) < lp[LP_SX0]) e->x = lp[LP_SX0] * FP;
        if (px(e->x) > lp[LP_SX1] - w) e->x = (lp[LP_SX1] - w) * FP;
    }
}

// NES plat_side: a plank is solid from the side too. Small step: climb on.
void plat_side(Ent* e, int oldx, int dir)
{
    int x = px(e->x);
    int y = px(e->y);
    int w = ent_w(e);
    int h = ent_h(e);
    int col;
    if (dir == 0) col = colof(x + w - 1); else col = colof(x);
    int r0 = rowof(y + PLANK);
    int r1 = rowof(y + h - 1);
    int r;
    for (r = r0; r <= r1; r++)
    {
        if (r >= 0 && is_plat(col, r))
        {
            int top = r * CH;
            if (y + h - top <= STEP_UP)
            {
                e->y = (top - h) * FP;
                e->vy = 0;
                e->ground = 1;
            }
            else
            {
                e->x = oldx;
                e->block = 1;
            }
            return;
        }
    }
}

int max_x(Ent* e) { return SCREEN_W - ent_w(e); }

// NES move_right / move_left. amount is fixed point.
void move_h(Ent* e, int amount, int dir)
{
    int oldx = e->x;
    int w = ent_w(e);
    if (dir == 0) e->x += amount; else e->x -= amount;
    if (lp[LP_SIDE])
    {
        // FAIRNESS: wrap on the bee's centre. Wrapping on the left edge made a
        // bee leaving through the left side wrap a whole body-width earlier than
        // one leaving through the right side (a blue/yellow asymmetry).
        if (e->x + (w / 2) * FP < 0) e->x += SCREEN_W * FP;
        if (e->x + (w / 2) * FP > SCREEN_W * FP) e->x -= SCREEN_W * FP;
    }
    else
    {
        if (e->x < 0) e->x = 0;
        if (e->x > max_x(e) * FP) e->x = max_x(e) * FP;
    }
    int x = px(e->x);
    if (dir == 0)
    {
        int col = colof(x + w - 1);
        if (wall_rows(e, col)) { e->x = (col * CW - w) * FP; e->block = 1; }
    }
    else
    {
        int col = colof(x);
        if (wall_rows(e, col)) { e->x = ((col + 1) * CW) * FP; e->block = 1; }
    }
    plat_side(e, oldx, dir);
    shaft_clamp(e);
}

// ---------------------------------------------------------------- vertical physics
// NES phys_vertical, with the landing test fixed.
//
// NES BUG (queen falls through a plank after a dash): the NES only landed a bee
// when its whole-pixel fall speed was >= how far its feet were into the tile
// (evyh >= feet&7). A stinger dash zeroes the speed but kept the sub-pixel
// fraction, so the first gravity tick after a dash could carry the feet 1 px
// into a plank with whole-pixel speed 0 -> no landing, every frame, all the way
// through. Here landing asks the real question: did the feet reach or cross a
// plank top between last frame and this frame?
void phys_vertical(Ent* e, int grav, int vmax)
{
    int h = ent_h(e);
    int w = ent_w(e);
    if (e->ground)
    {
        if (check_under(e, rowof(px(e->y) + h)))
        {
            if (e->drop > 0) e->drop--;
            return;
        }
        e->ground = 0;
    }
    e->vy += grav;
    if (e->vy > vmax) e->vy = vmax;
    int oldy = px(e->y);
    e->y += e->vy;
    int y = px(e->y);
    if (e->vy < 0)
    {
        // rising: platforms are solid from below (underside at row*CH + PLANK)
        int row = rowof(oldy - PLANK);
        int bnd = row * CH + PLANK;
        if (row >= 0 && y < bnd && check_under(e, row))
        {
            e->y = bnd * FP;
            e->vy = 0;
            y = bnd;
        }
    }
    // ceiling, with the Wrap Hive gap
    int x = px(e->x);
    int inshaft = 0;
    if (lp[LP_WRAP] && x >= lp[LP_SX0] && x + w <= lp[LP_SX1]) inshaft = 1;
    if (inshaft)
    {
        if (y < 24) { e->y += WRAP_DY * FP; oldy += WRAP_DY; y += WRAP_DY; }
    }
    else if (y < CEIL_Y)
    {
        e->y = CEIL_Y * FP;
        y = CEIL_Y;
        if (e->vy < 0) e->vy = 0;
    }
    if (lp[LP_WRAP] && y >= 324) { e->y -= WRAP_DY * FP; oldy -= WRAP_DY; y -= WRAP_DY; }
    // landing: swept test over every plank top between old and new feet
    if (e->vy >= 0 && e->drop == 0)
    {
        int f0 = oldy + h;
        int f1 = y + h;
        int r = (f0 + CH - 1) / CH;          // first tile top at or below the old feet
        while (r * CH <= f1)
        {
            if (check_under(e, r))
            {
                e->y = (r * CH - h) * FP;
                e->vy = 0;
                e->ground = 1;
                break;
            }
            r++;
        }
    }
    if (e->drop > 0) e->drop--;
}

// ---------------------------------------------------------------- level / match setup
int team_of(int i) { return ents[i].team; }

void load_level(int lvl)
{
    int i;
    for (i = 0; i < 960; i++) lvl_grid[i] = lvl_grid_all[lvl * 960 + i];
    for (i = 0; i < 30; i++) lvl_rowidx[i] = lvl_rowidx_all[lvl * 30 + i];
    for (i = 0; i < 160; i++) { lvl_launch_l[i] = lvl_launch_l_all[lvl * 160 + i]; lvl_launch_r[i] = lvl_launch_r_all[lvl * 160 + i]; }
    for (i = 0; i < LP_COUNT; i++) lp[i] = lvl_params_all[lvl * LP_COUNT + i];
    for (i = 0; i < 800; i++) lvl_throw[i] = lvl_throw_all[lvl * 800 + i];
    for (i = 0; i < NUM_BERRIES; i++)
    {
        int r = lvl_berry_row_all[lvl * NUM_BERRIES + i];
        int c = lvl_berry_col_all[lvl * NUM_BERRIES + i];
        berry_row[i] = r;
        berry_px[i] = c * CW + 4;
        berry_py[i] = r * CH;
    }
}

// NES pick_level: random, never the same board twice in a row
void pick_level()
{
    int l;
    if (force_level > 0) l = force_level - 1;
    else
    {
        l = rand8() % NUM_MATCH_LEVELS;
        if (l == last_level) l = (l + 1) % NUM_MATCH_LEVELS;
    }
    cur_level = l;
    last_level = l;
}

// team-1 positions are exact mirrors of team-0 positions
int mirror_x(int x, int w) { return SCREEN_W - w - x; }

void spawn_entity(int i)
{
    Ent* e = &ents[i];
    e->alive = 1;
    e->x = e->spawnx * FP;
    e->y = e->spawny * FP;
    e->face = e->spawnface;
    e->vy = 0; e->ground = 0; e->carry = 0; e->atk = 0; e->cool = 0; e->drop = 0; e->anim = 0;
    e->inp = 0; e->inpn = 0; e->timer = 0; e->warrior = 0; e->spin = 0; e->block = 0;
    e->dive = 0; e->stun = 0; e->place = 0;
    e->ai_alt = 0; e->ai_stuck = 0; e->ai_nodrop = 0; e->ai_lrow = -1;
    if (e->isq) e->timer = QUEEN_SHIELD;
}

// entity layout: 0 blue queen, 1 yellow queen, then blue workers, then yellow workers
int worker_index(int team, int k) { return 2 + team * (team_size - 1) + k; }

void setup_entities()
{
    int t; int k;
    num_ents = 2 + 2 * (team_size - 1);
    // NES spawn points mapped onto the wider board (centre x * 2.5), blue side
    int[3] wx = { 34, 54, 74 };
    for (t = 0; t < 2; t++)
    {
        Ent* q = &ents[t];
        q->team = t; q->isq = 1; q->slot = 0;
        q->spawnx = 68; q->spawny = 72; q->spawnface = 0;
        if (t == 1) { q->spawnx = mirror_x(68, QW); q->spawnface = 1; }
        for (k = 0; k < team_size - 1; k++)
        {
            Ent* w = &ents[worker_index(t, k)];
            w->team = t; w->isq = 0; w->slot = k + 1;
            w->spawnx = wx[k]; w->spawny = GROUND_Y_WORKER; w->spawnface = 0;
            if (t == 1) { w->spawnx = mirror_x(wx[k], WW); w->spawnface = 1; }
        }
    }
}

void start_match()
{
    int i;
    pick_level();
    load_level(cur_level);
    setup_entities();
    bonus_mode = 0;
    lives[0] = QUEEN_LIVES; lives[1] = QUEEN_LIVES;
    if (bonus_pending_crown >= 0) { lives[bonus_pending_crown] = QUEEN_LIVES + 1; bonus_pending_crown = -1; }
    berries[0] = 0; berries[1] = 0;
    snail_timer = 0; snail_anim = 0; fx_t = 0; snail_rem = 0; snail_boost = 0; snail_boost_team = 0;
    snail_x = lp[LP_SNAIL_START] * FP;
    snail_row = rowof(lp[LP_SNAIL_Y] + 12);
    snail_ry = lp[LP_SNAIL_Y] - 12;
    snail_rider = -1;
    winner = -1;
    for (i = 0; i < NUM_BERRIES; i++) { berry_on[i] = 1; berry_tmr[i] = 0; }
    for (i = 0; i < MAX_TB; i++) tb_on[i] = 0;
    for (i = 0; i < num_ents; i++)
    {
        spawn_entity(i);
        ents[i].ai_lrow = -1; ents[i].ai_alt = 0; ents[i].ai_stuck = 0; ents[i].ai_jdir = 0;
        ents[i].ai_lastx = ents[i].x;
        ents[i].ai_lasty = ents[i].y; ents[i].ai_lastin = 0; ents[i].ai_nodrop = 0; ents[i].ai_altx = 0;
    }
    hunt_first = rand8() & 1;
    game_state = ST_PLAY;
    emit(EV_MUSIC);
}

// ---------------------------------------------------------------- outcomes
void declare_win(int team, int type)
{
    if (winner >= 0) return;
    winner = team;
    win_type = type;
    if (type == WIN_HOOPS) bonus_pending_crown = team;
    game_state = ST_FREEZE;
    state_timer = FREEZE_FRAMES;
    emit(EV_WIN);
}

int player_of(int ent)
{
    int p;
    for (p = 0; p < MAX_PLAYERS; p++)
        if (pl_joined[p] && pl_ctrl[p] == ent) return p;
    return -1;
}

// NES kill_entity
void kill_entity(int vi)
{
    Ent* v = &ents[vi];
    fx_x = px(v->x) + ent_w(v) / 2; fx_y = px(v->y) + ent_h(v) / 2; fx_t = 14; fx_kind = 0;
    emit(EV_HIT);
    if (v->isq && bonus_mode)
    {
        // Hoops: a stung queen is out for a while (her team is slowed down), no crown lost
        emit(EV_HITQ);
        v->alive = 0; v->atk = 0; v->dive = 0;
        v->timer = QUEEN_RESPAWN;
        return;
    }
    if (v->isq)
    {
        emit(EV_HITQ);
        lives[v->team]--;
        v->alive = 0; v->atk = 0;
        v->timer = QUEEN_RESPAWN;
        emit(EV_MUSIC);
        if (lives[v->team] <= 0) declare_win(1 - v->team, WIN_MILITARY);
        return;
    }
    v->alive = 0;
    v->carry = 0;
    v->warrior = 0;
    v->spin = 0;
    v->timer = WORKER_RESPAWN;
    if (snail_rider == vi) snail_rider = -1;
    // a player steering this worker goes back to the queen, if she is free
    int p = player_of(vi);
    if (p >= 0)
    {
        int q = v->team;
        if (player_of(q) < 0) pl_ctrl[p] = q;
    }
}

// ---------------------------------------------------------------- berries
// NES try_arm: a carrying worker touching its own team's box trades for a yo-yo
int try_arm(int i)
{
    Ent* e = &ents[i];
    if (!lp[LP_BOXES]) return 0;
    int bx = lp[LP_BOX0];
    if (e->team == 1) bx = lp[LP_BOX1];
    int x = px(e->x); int y = px(e->y);
    if (x < bx - 10 || x > bx + 38) return 0;
    if (y < lp[LP_BOXY] - 10 || y > lp[LP_BOXY] + 22) return 0;
    int k;
    for (k = 2; k < num_ents; k++)
        if (k != i && ents[k].team == e->team && ents[k].alive && ents[k].warrior) return 0;   // one per team
    e->carry = 0;
    e->cool = 0;
    e->warrior = 1;
    emit(EV_ARM);
    emit(EV_MUSIC);
    return 1;
}

int try_feed_snail(int i);    // defined in the snail section below
int tb_pickup(int i);         // defined in the thrown-berries section below
int berry_in_hc(int team, int bx, int by, int hy);   // Hoops section
void hoops_score(int team);

int hc_left(int team) { if (team == 0) return HC_X0; return SCREEN_W - HC_W - HC_X0; }

// NES worker_berries
void worker_berries(int i)
{
    Ent* e = &ents[i];
    if (e->warrior) return;
    if (bonus_mode)
    {
        // Hoops: pick up loose berries; on the ground under your own honeycomb, when it
        // comes down to you, place the berry into a hole (slow, but sure)
        if (!e->carry) { tb_pickup(i); return; }
        int x = px(e->x); int y = px(e->y);
        int hx = hc_left(e->team);
        if (e->ground && y >= GROUND_Y_WORKER && x + WH > hx && x < hx + HC_W && hc_y + HC_H >= GROUND_Y_WORKER)
        {
            e->place = PLACE_FRAMES;
            emit(EV_LOCK);
        }
        return;
    }
    int x = px(e->x); int y = px(e->y);
    if (!e->carry)
    {
        if (tb_pickup(i)) return;
        int b;
        for (b = 0; b < NUM_BERRIES; b++)
        {
            if (!berry_on[b]) continue;
            if (iabs(x - berry_px[b]) > 9 || iabs(y - berry_py[b]) > 9) continue;
            berry_on[b] = 0;
            berry_tmr[b] = (rand8() & 63) + 180;
            e->carry = 1;
            emit(EV_PICK);
            return;
        }
        return;
    }
    if (try_arm(i)) return;
    if (try_feed_snail(i)) return;
    if (y < 276) return;
    if (e->team == 0) { if (x >= 30) return; }
    else { if (x <= SCREEN_W - WW - 30) return; }   // exact mirror of blue's x < 30
    e->carry = 0;
    berries[e->team]++;
    emit(EV_DEPOSIT);
    if (berries[e->team] == 6) emit(EV_MUSIC);
    if (berries[e->team] >= ECON_GOAL) declare_win(e->team, WIN_ECONOMY);
}

// NES berry_update: picked berries regrow
void berry_update()
{
    if (frame & 3) return;
    int b;
    for (b = 0; b < NUM_BERRIES; b++)
    {
        if (berry_on[b]) continue;
        berry_tmr[b]--;
        if (berry_tmr[b] <= 0) berry_on[b] = 1;
    }
}

// ---------------------------------------------------------------- snail
int touching_snail(int i)
{
    int x = px(ents[i].x); int y = px(ents[i].y);
    int sx = px(snail_x);
    if (x < sx - 10 || x > sx + 22) return 0;
    if (y < lp[LP_SNAIL_Y] - 13 || y > lp[LP_SNAIL_Y] + 5) return 0;
    return 1;
}

// speed multiplier of the snail in halves: 2 = normal (NES speed x 1.5 px)
// NEW: a rider carrying a berry -> x1.5; a fed berry from a teammate -> x2 for
// 3 s; both together multiply -> x3
int snail_speed_halves()
{
    if (snail_rider < 0) return 0;
    Ent* r = &ents[snail_rider];
    int m = 2;
    if (r->carry) m = 3;
    if (snail_boost > 0 && snail_boost_team == r->team) m = m * 2;
    return m;
}

int snail_close_to_win(int team)
{
    int sx = px(snail_x);
    int start = lp[LP_SNAIL_START];
    if (team == 0) return (lp[LP_GOAL_R] - sx) * 100 <= (lp[LP_GOAL_R] - start) * SNAIL_CLOSE_PCT;
    return (sx - lp[LP_GOAL_L]) * 100 <= (start - lp[LP_GOAL_L]) * SNAIL_CLOSE_PCT;
}

// NES snail_update (now moves smoothly every frame instead of 1 step per 14 frames)
void snail_update()
{
    if (snail_boost > 0) snail_boost--;
    if (snail_rider < 0) return;
    Ent* r = &ents[snail_rider];
    if (!r->alive) { snail_rider = -1; return; }
    int m = snail_speed_halves();
    // same average speed as before: SNAIL_STEP_FP per SNAIL_STEP frames, times m/2
    int num = SNAIL_STEP_FP * m + snail_rem;
    int delta = num / (2 * SNAIL_STEP);
    snail_rem = num - delta * 2 * SNAIL_STEP;
    snail_timer += m;
    if (snail_timer >= 2 * SNAIL_STEP) { snail_timer -= 2 * SNAIL_STEP; snail_anim++; }
    int before = px(snail_x);
    if (r->team == 0)
    {
        snail_x += delta;
        int sx = px(snail_x);
        if (before < lp[LP_GOAL_R] - 36 && sx >= lp[LP_GOAL_R] - 36) emit(EV_MUSIC);
        if (sx >= lp[LP_GOAL_R]) declare_win(0, WIN_SNAIL);
    }
    else
    {
        snail_x -= delta;
        int sx = px(snail_x);
        if (before > lp[LP_GOAL_L] + 36 && sx <= lp[LP_GOAL_L] + 36) emit(EV_MUSIC);
        if (sx <= lp[LP_GOAL_L]) declare_win(1, WIN_SNAIL);
    }
    r->x = snail_x + 6 * FP;
    r->y = snail_ry * FP;
    r->vy = 0;
    r->ground = 1;
}

// NEW: a teammate carrying a berry who touches the snail while their team is
// riding feeds it (automatic): berry used up, snail boosted for 3 s
int try_feed_snail(int i)
{
    Ent* e = &ents[i];
    if (snail_rider < 0 || snail_rider == i) return 0;
    if (ents[snail_rider].team != e->team) return 0;
    if (!touching_snail(i)) return 0;
    e->carry = 0;
    snail_boost = SNAIL_FEED_FRAMES;
    snail_boost_team = e->team;
    fx_x = px(snail_x) + 12; fx_y = lp[LP_SNAIL_Y] + 2; fx_t = 12; fx_kind = 2;
    emit(EV_FEED);
    return 1;
}

// ---------------------------------------------------------------- thrown berries (NEW)
int tb_hive_team(int xfp, int y)
{
    // a berry falling into a hive: blue hive at the left edge, yellow at the right.
    // Checked on exact (fixed point) x so yellow's zone is the precise mirror of
    // blue's - rounding pixels down is not symmetric for mirrored positions.
    if (y < 270 || y > 316) return -1;
    if (xfp < 34 * FP) return 0;
    if (xfp > (SCREEN_W - 12 - 34) * FP) return 1;
    return -1;
}

// one frame of flight (shared by tb_update and the CPU's throw prediction so they
// can never disagree). Returns the new pixel position via tbs_x / tbs_y.
int tbs_x, tbs_y;
void tb_step(int* x, int* y, int* vx, int* vy)
{
    int oldx = *x;
    *vy += TB_GRAV;
    if (*vy > W_VMAX) *vy = W_VMAX;
    *x += *vx;
    *y += *vy;
    if (lp[LP_SIDE])
    {
        // wrap on the berry's CENTRE so both directions wrap at mirrored points
        if (*x + 6 * FP < 0) *x += SCREEN_W * FP;
        if (*x + 6 * FP > SCREEN_W * FP) *x -= SCREEN_W * FP;
    }
    else if (*x < 0 || *x > (SCREEN_W - 12) * FP)
    {
        *x = oldx; *vx = 0;                                 // stopped by the board edge
    }
    tbs_x = px(*x); tbs_y = px(*y);
    int cl = colof(tbs_x + 1); int cr = colof(tbs_x + 10); int rr = rowof(tbs_y + 6);
    if (is_wall(cl, rr) || is_wall(cr, rr)) { *x = oldx; *vx = 0; tbs_x = px(oldx); }
    if (tbs_y < CEIL_Y && !(lp[LP_WRAP] && tbs_x >= lp[LP_SX0] && tbs_x + 12 <= lp[LP_SX1]))
    {
        *y = CEIL_Y * FP; if (*vy < 0) *vy = 0; tbs_y = CEIL_Y;
    }
}

void throw_berry(int i)
{
    Ent* e = &ents[i];
    int k; int slot = -1;
    for (k = 0; k < MAX_TB; k++) if (tb_on[k] == 0) { slot = k; break; }
    if (slot < 0)
    {
        // all slots busy: reuse the oldest berry lying on the board
        int oldest = -1;
        for (k = 0; k < MAX_TB; k++) if (tb_on[k] == 2 && (oldest < 0 || tb_age[k] > tb_age[oldest])) oldest = k;
        if (oldest < 0) return;
        slot = oldest;
    }
    int dir = 1;
    if (e->face == 1) dir = -1;
    tb_on[slot] = 1;
    tb_team[slot] = e->team;
    tb_age[slot] = 0;
    tb_x[slot] = e->x + dir * 6 * FP;
    tb_y[slot] = e->y - 4 * FP;
    tb_vx[slot] = dir * TB_VX;
    if ((dir > 0 && (e->inp & BTN_RIGHT)) || (dir < 0 && (e->inp & BTN_LEFT))) tb_vx[slot] += dir * TB_VX_RUN;
    tb_vy[slot] = TB_VY;
    if (!e->ground) tb_vy[slot] = TB_VY + e->vy / 2;     // jumping throws inherit some lift
    e->carry = 0;
    emit(EV_THROW);
}

void tb_update()
{
    int k;
    for (k = 0; k < MAX_TB; k++)
    {
        if (tb_on[k] == 0) continue;
        tb_age[k]++;
        if (tb_on[k] == 2)
        {
            if (tb_age[k] > TB_LIFE) tb_on[k] = 0;
            continue;
        }
        // flying
        int oldy = px(tb_y[k]);
        tb_step(&tb_x[k], &tb_y[k], &tb_vx[k], &tb_vy[k]);
        int x = tbs_x; int y = tbs_y;
        if (lp[LP_WRAP] && y >= 324) { tb_y[k] -= WRAP_DY * FP; oldy -= WRAP_DY; y -= WRAP_DY; }
        if (bonus_mode)
        {
            if (tb_team[k] >= 0 && berry_in_hc(tb_team[k], x, y, hc_y))
            {
                tb_on[k] = 0;
                hoops_score(tb_team[k]);
                continue;
            }
        }
        // scores in the thrower's own hive
        int h = -1;
        if (!bonus_mode) h = tb_hive_team(tb_x[k], y);
        if (h >= 0 && h == tb_team[k])
        {
            tb_on[k] = 0;
            berries[h]++;
            emit(EV_DEPOSIT);
            if (berries[h] == 6) emit(EV_MUSIC);
            if (berries[h] >= ECON_GOAL) declare_win(h, WIN_ECONOMY);
            continue;
        }
        // feeds the snail if a teammate is riding (same turbo rules as feeding by hand)
        if (!bonus_mode && snail_rider >= 0 && ents[snail_rider].team == tb_team[k])
        {
            int sx = px(snail_x);
            if (iabs(dxs(sx + 12, x + 6)) < 18 && y + 12 >= snail_ry && y <= lp[LP_SNAIL_Y] + 12)
            {
                tb_on[k] = 0;
                snail_boost = SNAIL_FEED_FRAMES;
                snail_boost_team = tb_team[k];
                fx_x = sx + 12; fx_y = lp[LP_SNAIL_Y] + 2; fx_t = 12; fx_kind = 2;
                emit(EV_FEED);
                continue;
            }
        }
        // lands on a platform (swept test, like the bees) -> a pickup anyone can grab
        if (tb_vy[k] >= 0)
        {
            int f0 = oldy + 12; int f1 = y + 12;
            int r = (f0 + CH - 1) / CH;
            while (r * CH <= f1)
            {
                if (is_plat(colof(x + 2), r) || is_plat(colof(x + 9), r))
                {
                    tb_y[k] = (r * CH - 12) * FP;
                    tb_on[k] = 2;
                    tb_age[k] = 0;
                    break;
                }
                r++;
            }
        }
    }
}

// a worker with empty hands picks up a berry lying on the board (any team)
int tb_pickup(int i)
{
    Ent* e = &ents[i];
    int x = px(e->x); int y = px(e->y);
    int k;
    for (k = 0; k < MAX_TB; k++)
    {
        if (tb_on[k] != 2) continue;
        if (iabs(dxs(x, px(tb_x[k]))) > 9 || iabs(y - px(tb_y[k])) > 9) continue;
        tb_on[k] = 0;
        e->carry = 1;
        emit(EV_PICK);
        return 1;
    }
    return 0;
}

// ---------------------------------------------------------------- HONEYCOMB HOOPS (NEW)
void hoops_score(int team)
{
    if (winner >= 0) return;
    hoops[team]++;
    emit(EV_SCORE_HOLE);
    if (hoops[team] >= HOOPS_GOAL) declare_win(team, WIN_HOOPS);
}

int hc_y_at(int phase)
{
    // triangle wave: down for HC_HALF frames, up for HC_HALF frames
    int t = phase % (2 * HC_HALF);
    if (t >= HC_HALF) t = 2 * HC_HALF - t;
    return HC_TOP + (HC_BOTTOM - HC_TOP) * t / HC_HALF;
}

// does a 12x12 berry at pixel (bx, by) touch team's honeycomb at height hy?
int berry_in_hc(int team, int bx, int by, int hy)
{
    int hx = hc_left(team);
    if (bx + 12 <= hx || bx >= hx + HC_W) return 0;
    if (by + 12 <= hy || by >= hy + HC_H) return 0;
    return 1;
}

void setup_vines()
{
    // berries hang under the two upper levels (mirrored pairs)
    int[8] cols = { 9, 22, 13, 18, 7, 24, 11, 20 };
    int k;
    for (k = 0; k < NUM_VINES; k++)
    {
        vine_x[k] = cols[k] * CW + 10;
        if (k < 4) { vine_top[k] = 8 * CH + PLANK; vine_y[k] = 10 * CH + 4; }
        else { vine_top[k] = 14 * CH + PLANK; vine_y[k] = 16 * CH + 4; }
        vine_on[k] = 1; vine_tmr[k] = 0;
    }
}

void hoops_update()
{
    hc_phase++;
    hc_y = hc_y_at(hc_phase);
    int k;
    for (k = 0; k < NUM_VINES; k++)
        if (!vine_on[k]) { vine_tmr[k]--; if (vine_tmr[k] <= 0) vine_on[k] = 1; }
}

// a queen stinging (dash or dive) through a vine knocks its berry down.
// Runs BEFORE combat, so a sting that ends in a queen-vs-queen clash still counts.
void hoops_vine_strikes()
{
    int k;
    int q;
    for (q = 0; q < 2; q++)
    {
        Ent* e = &ents[q];
        if (!e->alive) continue;
        if (!((e->atk >= 1 && e->atk <= DASH_LIVE) || e->dive > 0)) continue;
        int cx = px(e->x) + 12; int cy = px(e->y) + 12;
        for (k = 0; k < NUM_VINES; k++)
        {
            if (!vine_on[k]) continue;
            if (iabs(cx - vine_x[k]) >= 20 || iabs(cy - vine_y[k]) >= 20) continue;
            vine_on[k] = 0; vine_tmr[k] = VINE_REGROW;
            int s2; int slot = -1;
            for (s2 = 0; s2 < MAX_TB; s2++) if (tb_on[s2] == 0) { slot = s2; break; }
            if (slot >= 0)
            {
                tb_on[slot] = 1; tb_team[slot] = -1; tb_age[slot] = 0;
                tb_x[slot] = (vine_x[k] - 6) * FP; tb_y[slot] = (vine_y[k] - 6) * FP;
                tb_vx[slot] = 0; tb_vy[slot] = 0;
            }
            emit(EV_VINE);
        }
    }
}

void start_bonus()
{
    int i;
    bonus_mode = 1;
    cur_level = LEVEL_HOOPS;
    load_level(cur_level);
    setup_entities();
    hoops[0] = 0; hoops[1] = 0;
    hc_phase = 0; hc_y = hc_y_at(0);
    setup_vines();
    for (i = 0; i < NUM_BERRIES; i++) { berry_on[i] = 0; berry_tmr[i] = 1 << 20; }
    for (i = 0; i < MAX_TB; i++) tb_on[i] = 0;
    snail_rider = -1; snail_boost = 0; snail_x = -200 * FP;
    snail_timer = 0; snail_anim = 0; fx_t = 0; snail_rem = 0;
    snail_row = 0; snail_ry = -100;
    winner = -1;
    for (i = 0; i < num_ents; i++)
    {
        spawn_entity(i);
        ents[i].ai_lrow = -1; ents[i].ai_alt = 0; ents[i].ai_stuck = 0; ents[i].ai_jdir = 0;
        ents[i].ai_lastx = ents[i].x; ents[i].ai_lasty = ents[i].y; ents[i].ai_lastin = 0; ents[i].ai_nodrop = 0;
    }
    hunt_first = rand8() & 1;
    game_state = ST_PLAY;
    emit(EV_MUSIC);
}

// ---------------------------------------------------------------- per-entity update
// NES queen_update
void queen_update(int i)
{
    Ent* e = &ents[i];
    e->block = 0;
    if (e->cool > 0) e->cool--;
    if (e->timer > 0) e->timer--;
    if (e->stun > 0)
    {
        // NEW: missed dive -> stunned, frozen in place (and stingable)
        e->stun--;
        e->vy = 0;
        e->anim++;
        return;
    }
    if (e->dive > 0)
    {
        // NEW: down-dash dive: straight down fast until something is hit
        e->dive++;
        e->vy = DIVE_SPEED;
        phys_vertical(e, 0, DIVE_SPEED);
        if (e->ground)
        {
            e->dive = 0;
            e->stun = STUN_FRAMES;
            emit(EV_STUN);
        }
        else if (e->dive > DIVE_MAX) { e->dive = 0; e->vy = 0; }
        e->anim++;
        return;
    }
    if (e->atk > 0)
    {
        // stinger dash: fast, straight, locked direction, no gravity
        e->atk--;
        move_h(e, Q_DASH_SPEED, e->face);
        e->vy = 0;
        e->anim++;
        return;
    }
    int speed = Q_AIR_SPEED;
    if (e->ground) speed = Q_GROUND_SPEED;
    if (e->inp & BTN_RIGHT) { e->face = 0; move_h(e, speed, 0); }
    if (e->inp & BTN_LEFT) { e->face = 1; move_h(e, speed, 1); }
    if ((e->inpn & BTN_B) && e->cool == 0 && (e->inp & BTN_DOWN) && px(e->y) < GROUND_Y_QUEEN)
    {
        // NEW: Down + B = dive. From a platform she drops through it first.
        e->dive = 1;
        e->cool = DASH_COOL;
        if (e->ground)
        {
            if (wall_below(e)) { e->dive = 0; e->cool = 0; }
            else { e->ground = 0; e->drop = 4; }
        }
        if (e->dive) { e->vy = DIVE_SPEED; emit(EV_DIVE); return; }
    }
    if ((e->inpn & BTN_B) && e->cool == 0)
    {
        e->atk = DASH_FRAMES;
        e->cool = DASH_COOL;
        emit(EV_DASH);
    }
    if (e->inpn & BTN_A)
    {
        int dropped = 0;
        if (e->ground && (e->inp & BTN_DOWN) && px(e->y) < GROUND_Y_QUEEN)
        {
            if (!wall_below(e)) { e->drop = DROP_FRAMES; e->ground = 0; }
            dropped = 1;
        }
        if (!dropped)
        {
            e->vy = Q_FLAP;
            e->ground = 0;
            emit(EV_FLAP);
        }
    }
    phys_vertical(e, Q_GRAV, Q_VMAX);
    e->anim++;
}

// NES yoyo_hit: the yo-yo orbits the armed worker and kills the enemy queen
int[12] yo_dx = { 21, 18, 11, 0, -11, -18, -21, -18, -11, 0, 11, 18 };
int[12] yo_dy = { 0, 11, 18, 21, 18, 11, 0, -11, -18, -21, -18, -11 };
void yoyo_hit(int i)
{
    Ent* e = &ents[i];
    int k = e->spin / 2;
    if (k > 11) k = 11;
    e->yox = px(e->x) + 6 + yo_dx[k];
    e->yoy = px(e->y) + 6 + yo_dy[k];
    if (lp[LP_SIDE]) e->yox = wrapx(e->yox);
    Ent* q = &ents[1 - e->team];
    if (!q->alive || q->timer > 0) return;
    if (iabs(dxs(e->yox, px(q->x) + 12)) >= 15) return;
    if (iabs(px(q->y) + 12 - e->yoy) >= 15) return;
    kill_entity(1 - e->team);
}

// NES worker_update
void worker_update(int i)
{
    Ent* e = &ents[i];
    if (snail_rider == i)
    {
        if (e->inpn & (BTN_A | BTN_B))
        {
            snail_rider = -1;                    // hop off the snail
            e->vy = Q_FLAP;
            e->ground = 0;
            emit(EV_JUMP);
        }
        return;
    }
    e->block = 0;
    if (e->place > 0)
    {
        // Hoops: placing a berry into the honeycomb (frozen for a moment)
        e->place--;
        e->anim++;
        if (e->place == 0 && e->carry) { e->carry = 0; hoops_score(e->team); }
        return;
    }
    if (e->inp & BTN_RIGHT) { e->face = 0; move_h(e, W_SPEED, 0); e->anim++; }
    if (e->inp & BTN_LEFT) { e->face = 1; move_h(e, W_SPEED, 1); e->anim++; }
    if ((e->inpn & BTN_A) && e->ground)
    {
        int dropped = 0;
        if ((e->inp & BTN_DOWN) && px(e->y) < GROUND_Y_WORKER)
        {
            if (!wall_below(e)) { e->drop = DROP_FRAMES; e->ground = 0; }
            dropped = 1;
        }
        if (!dropped)
        {
            e->vy = W_JUMP;
            e->ground = 0;
            emit(EV_JUMP);
        }
    }
    if (e->cool > 0) e->cool--;
    if (e->spin > 0) e->spin--;
    if ((e->inpn & BTN_B) && e->carry && !(snail_rider < 0 && touching_snail(i)))
    {
        throw_berry(i);                      // NEW: B while carrying = throw
    }
    else if (e->inpn & BTN_B)
    {
        if (e->warrior)
        {
            if (e->cool == 0)
            {
                e->spin = YOYO_SPIN;
                e->cool = YOYO_COOL;
                emit(EV_YOYO);
            }
        }
        else if (snail_rider < 0 && touching_snail(i))
        {
            snail_rider = i;
            emit(EV_RIDE);
            return;
        }
    }
    phys_vertical(e, W_GRAV, W_VMAX);
    worker_berries(i);
    if (e->spin > 0) yoyo_hit(i);
}

// ---------------------------------------------------------------- combat
// NES clash: both queens stinging into each other bounce apart
void clash(int a, int b)
{
    Ent* qa = &ents[a];
    Ent* qb = &ents[b];
    qa->atk = 0; qb->atk = 0;
    qa->vy = Q_FLAP; qb->vy = Q_FLAP;
    qa->ground = 0; qb->ground = 0;
    fx_x = (px(qa->x) + px(qb->x)) / 2 + 12; fx_y = (px(qa->y) + px(qb->y)) / 2 + 12; fx_t = 12; fx_kind = 1;
    if (dxs(px(qa->x), px(qb->x)) < 0)
    {
        move_h(qa, 21 * FP, 0);
        move_h(qb, 21 * FP, 1);
    }
    else
    {
        move_h(qa, 21 * FP, 1);
        move_h(qb, 21 * FP, 0);
    }
    emit(EV_CLANK);
}

// NES queen_attack
void queen_attack(int qi)
{
    Ent* q = &ents[qi];
    if (!q->alive) return;
    if (q->atk < 1 || q->atk > DASH_LIVE) return;
    int t0 = px(q->x) + 12;
    int t1 = px(q->y) + 12;
    int k;
    for (k = 0; k < num_ents; k++)
    {
        Ent* v = &ents[k];
        if (v->team == q->team || !v->alive) continue;
        if (bonus_mode && !v->isq) continue;      // Hoops: queens only fight queens
        int t2; int t3; int rx; int ry;
        if (v->isq)
        {
            if (v->timer > 0) continue;
            t2 = px(v->x) + 12; t3 = px(v->y) + 12; rx = 30; ry = 21;
        }
        else
        {
            t2 = px(v->x) + 6; t3 = px(v->y) + 6; rx = 26; ry = 18;
        }
        int d = dxs(t0, t2);
        // must be in front of the stinger (small grace behind)
        if (q->face == 0) { if (d + 6 < 0) continue; }
        else { if (6 - d < 0) continue; }
        if (iabs(d) >= rx) continue;
        if (iabs(t3 - t1) >= ry) continue;
        if (v->isq && v->atk > 0) { clash(qi, k); return; }
        kill_entity(k);
    }
}

// NEW: a diving queen kills whatever is right below her stinger; a kill ends
// the dive cleanly (no stun)
void dive_attack(int qi)
{
    Ent* q = &ents[qi];
    if (!q->alive || q->dive == 0) return;
    int cx = px(q->x) + 12;
    int cy = px(q->y) + 12;
    int k;
    for (k = 0; k < num_ents; k++)
    {
        Ent* v = &ents[k];
        if (v->team == q->team || !v->alive) continue;
        if (v->isq && v->timer > 0) continue;
        if (bonus_mode && !v->isq) continue;
        int tx; int ty;
        if (v->isq) { tx = px(v->x) + 12; ty = px(v->y) + 12; }
        else { tx = px(v->x) + 6; ty = px(v->y) + 6; }
        if (iabs(dxs(cx, tx)) >= 21) continue;
        int dy = ty - cy;
        if (dy < 0 || dy >= 33) continue;
        kill_entity(k);
        q->dive = 0;
        q->vy = 0;
        return;
    }
}

void combat()
{
    dive_attack(0);
    dive_attack(1);
    // random which queen's sting resolves first (fair same-frame trades)
    if (rand8() & 1) { queen_attack(1); queen_attack(0); }
    else { queen_attack(0); queen_attack(1); }
}
