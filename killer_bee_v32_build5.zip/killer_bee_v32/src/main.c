// =====================================================================
//  KILLER BEE for Vircon32 - main program (platform layer)
//  Build: see build.sh. Gameplay lives in game.c / ai.c / flow.c.
// =====================================================================
#include "video.h"
#include "audio.h"
#include "input.h"
#include "time.h"
#include "math.h"
#include "string.h"
#include "misc.h"

#define ART_SETS 3                // Clean, Grunge, NES Classic
#include "game.h"
#include "art.h"
#include "music.h"
#include "game.c"
#include "ai.c"
#include "flow.c"

int tex_base;              // 0 = clean art set, TEX_PER_SET = grunge

// ---------------------------------------------------------------- input
int[MAX_PLAYERS] pad_prev;

// Vircon32 gamepads have no SELECT button: Y, L and R all act as SELECT.
void read_pads()
{
    int p;
    for (p = 0; p < MAX_PLAYERS; p++)
    {
        select_gamepad(p);
        int b = 0;
        if (gamepad_is_connected())
        {
            if (gamepad_right() > 0) b = b | BTN_RIGHT;
            if (gamepad_left() > 0) b = b | BTN_LEFT;
            if (gamepad_up() > 0) b = b | BTN_UP;
            if (gamepad_down() > 0) b = b | BTN_DOWN;
            if (gamepad_button_a() > 0) b = b | BTN_A;
            if (gamepad_button_b() > 0) b = b | BTN_B;
            if (gamepad_button_y() > 0 || gamepad_button_l() > 0 || gamepad_button_r() > 0) b = b | BTN_SELECT;
            if (gamepad_button_start() > 0) b = b | BTN_START;
        }
        pad_new[p] = b & ~pad_prev[p];
        pad[p] = b;
        pad_prev[p] = b;
    }
}

// ---------------------------------------------------------------- text
int text_width(int* s, int big)
{
    int w = 0;
    while (*s)
    {
        int c = toupper(*s);
        if (c < 32 || c > 95) c = 32;
        if (big) w += font_big_w[c - 32]; else w += font_small_w[c - 32];
        s++;
    }
    return w;
}

void draw_text(int x, int y, int* s, int big, int color)
{
    select_texture(tex_base);
    set_multiply_color(color);
    while (*s)
    {
        int c = toupper(*s);
        if (c < 32 || c > 95) c = 32;
        if (big) { select_region(R_FONT_BIG + c - 32); draw_region_at(x, y); x += font_big_w[c - 32]; }
        else { select_region(R_FONT_SMALL + c - 32); draw_region_at(x, y); x += font_small_w[c - 32]; }
        s++;
    }
    set_multiply_color(color_white);
}

void draw_text_c(int cx, int y, int* s, int big, int color)
{
    draw_text(cx - text_width(s, big) / 2, y, s, big, color);
}

void draw_rect(int x, int y, int w, int h, int color)
{
    select_texture(tex_base);
    select_region(R_WHITE);
    set_multiply_color(color);
    set_drawing_scale((float)w / 8.0, (float)h / 8.0);
    draw_region_zoomed_at(x, y);
    set_multiply_color(color_white);
}

// ---------------------------------------------------------------- sprites
void spr(int region, int x, int y, bool flip)
{
    select_texture(tex_base);
    select_region(region);
    if (flip) { set_drawing_scale(-1.0, 1.0); draw_region_zoomed_at(x, y); }
    else draw_region_at(x, y);
}

int bg_of_level(int lvl) { if (lvl == LEVEL_HOOPS) return BG_HOOPS; return lvl; }

void draw_bg(int i)
{
    select_texture(tex_base + 1 + i / 2);
    select_region(i % 2);
    draw_region_at(0, 0);
}

int team_col(int t)
{
    if (art_set == 1) { if (t == 0) return 0xFFFFAA28; return 0xFF28FFD7; }   // neon blue / toxic yellow
    if (art_set == 2) { if (t == 0) return 0xFFFCBC3C; return 0xFF00B8F8; }   // NES palette blue / yellow
    if (t == 0) return 0xFFFFA050;
    return 0xFF30D0FF;
}
int accent_col() { if (art_set == 1) return 0xFFA03CFF; if (art_set == 2) return 0xFF00B8F8; return 0xFF30D8FF; }

// draw a sprite, repeated across the seam on open-sided boards
void spr_wrapped(int region, int x, int y, bool flip, int half)
{
    spr(region, x, y, flip);
    if (lp[LP_SIDE])
    {
        if (x - half < 0) spr(region, x + SCREEN_W, y, flip);
        if (x + half > SCREEN_W) spr(region, x - SCREEN_W, y, flip);
    }
}

void draw_entity(int i)
{
    Ent* e = &ents[i];
    if (!e->alive) return;
    int x = px(e->x); int y = px(e->y);
    bool flip = (e->face == 1);
    int r;
    if (e->isq)
    {
        int base = R_Q_BLUE_FLY0;
        if (e->team == 1) base = R_Q_YEL_FLY0;
        int shake = 0;
        if (e->stun > 0) { r = base + 7; shake = ((frame / 2) % 2) * 4 - 2; }       // stunned: shakes in place
        else if (e->dive > 0) r = base + 6;
        else if (e->atk > 0) r = base + 4;
        else if (e->ground) r = base + 5;
        else r = base + ((e->anim / 3) % 4);
        if (e->timer > 0 && (e->timer / 4) % 2 == 0) set_multiply_color(0xA0FFFFFF);
        int qdx = 3; int qdy = 2;                       // wasp queen body sits left/up of its cell centre
        if (art_set == 2) { qdx = 0; qdy = 0; }          // NES queen is centred
        if (flip) qdx = -qdx;
        spr_wrapped(r, x + 12 + qdx + shake, y + 12 + qdy, flip, 26);
        set_multiply_color(color_white);
        if (e->timer > 0) spr_wrapped(R_SHIELD, x + 12, y + 12, false, 22);
    }
    else
    {
        int base = R_W_BLUE_WALK0;
        if (e->team == 1) base = R_W_YEL_WALK0;
        if (!e->ground) { if (e->vy < 0) r = base + 4; else r = base + 5; }
        else r = base + ((e->anim / 5) % 4);
        spr_wrapped(r, x + 6, y + 4, flip, 12);
        if (e->carry) spr_wrapped(R_BERRY, x + 6, y - 6, false, 8);
        if (e->warrior)
        {
            if (e->spin > 0) spr(R_YOYO, e->yox, e->yoy, false);
            else if (e->face == 0) spr_wrapped(R_YOYO, x + 14, y + 8, false, 7);
            else spr_wrapped(R_YOYO, x - 2, y + 8, false, 7);
        }
    }
}

int[8] numbuf;

void draw_hud()
{
    int t; int k;
    draw_text(10, 4, "BLUE", false, team_col(0));
    draw_text(SCREEN_W - 10 - text_width("YELLOW", false), 4, "YELLOW", false, team_col(1));
    for (k = 0; k < ECON_GOAL && !bonus_mode; k++)
    {
        int on0 = 0; int on1 = 0;
        if (k < berries[0]) on0 = 1;
        if (k < berries[1]) on1 = 1;
        spr(R_METER_OFF - on0, 18 + k * 17, 32, false);
        spr(R_METER_OFF - on1, SCREEN_W - 18 - k * 17, 32, false);
    }
    int ncrowns = imax(QUEEN_LIVES, imax(lives[0], lives[1]));
    if (bonus_mode) ncrowns = 0;
    for (k = 0; k < ncrowns; k++)
    {
        int c0 = R_CROWN_OFF; int c1 = R_CROWN_OFF;
        if (k < lives[0]) c0 = R_CROWN_ON;
        if (k < lives[1]) c1 = R_CROWN_ON;
        spr(c0, 170 + k * 20, 32, false);
        spr(c1, SCREEN_W - 170 - k * 20, 32, false);
    }
    if (cur_level == 0) draw_text_c(320, 4, "MEADOW", false, 0xFFC0F0FF);
    if (cur_level == 1) draw_text_c(320, 4, "WRAP HIVE", false, 0xFFC0F0FF);
    if (cur_level == 2) draw_text_c(320, 4, "MEADOW WARP", false, 0xFFC0F0FF);
    if (cur_level == 3) draw_text_c(320, 4, "WRAP HIVE WARP", false, 0xFFC0F0FF);
    if (cur_level == 4) draw_text_c(320, 4, "DIVIDE", false, 0xFFC0F0FF);
    if (bonus_mode)
    {
        draw_text_c(320, 4, "BONUS: HONEYCOMB HOOPS", false, 0xFFC0F0FF);
        // holes filled, shown as honey cells
        for (k = 0; k < HOOPS_GOAL; k++)
        {
            int on0 = 0; int on1 = 0;
            if (k < hoops[0]) on0 = 1;
            if (k < hoops[1]) on1 = 1;
            spr(R_METER_OFF - on0, 18 + k * 17, 32, false);
            spr(R_METER_OFF - on1, SCREEN_W - 18 - k * 17, 32, false);
        }
    }
    draw_text_c(320, 24, "KILLER BEE", false, accent_col());
}

void draw_play()
{
    int i;
    draw_bg(bg_of_level(cur_level));
    for (i = 0; i < NUM_BERRIES; i++)
        if (berry_on[i]) spr(R_BERRY, berry_px[i] + 6, berry_py[i] + 4, false);
    // NEW: thrown berries (flying) and dropped ones (lying on a platform; blink before vanishing)
    for (i = 0; i < MAX_TB; i++)
    {
        if (tb_on[i] == 0) continue;
        if (tb_on[i] == 2 && tb_age[i] > TB_LIFE - 120 && (frame / 6) % 2 == 0) continue;
        spr_wrapped(R_BERRY, px(tb_x[i]) + 6, px(tb_y[i]) + 6, false, 8);
    }
    // snail
    bool sflip = false;
    if (snail_rider >= 0 && ents[snail_rider].team == 1) sflip = true;
    if (bonus_mode)
    {
        // vines: berry hanging at the end of each (stems are in the background)
        int k;
        for (k = 0; k < NUM_VINES; k++)
            if (vine_on[k]) spr(R_BERRY, vine_x[k], vine_y[k], false);
        // the two moving honeycombs, holes filling with berries
        int t;
        for (t = 0; t < 2; t++)
        {
            int hx = hc_left(t);
            spr(R_HONEYCOMB, hx, hc_y, false);
            for (k = 0; k < hoops[t] && k < HOOPS_GOAL; k++)
                spr(R_HOLE, hx + 10 + 20 * (k % 2), hc_y + 10 + 20 * (k / 2), false);
            draw_rect(hx + 2, hc_y - 3, HC_W - 4, 3, team_col(t));
        }
    }
    // NEW: speed streaks behind a boosted snail (more streaks = faster)
    int sm = snail_speed_halves();
    if (sm > 2)
    {
        int k; int sx = px(snail_x) + 12; int dir = -1;
        if (sflip) dir = 1;
        int col = team_col(ents[snail_rider].team) & 0x00FFFFFF;
        for (k = 0; k < sm - 2; k++)
        {
            int len = 10 + ((frame + k * 5) % 8);
            int lx = sx + dir * (20 + k * 6);
            if (dir < 0) lx -= len;
            draw_rect(lx, lp[LP_SNAIL_Y] - 4 + k * 5, len, 2, col | 0xC0000000);
        }
    }
    if (!bonus_mode) spr(R_SNAIL0 + (snail_anim % 2), px(snail_x) + 12, lp[LP_SNAIL_Y] - 1, sflip);
    // bees: workers first, queens on top; rotate order a little for fairness
    for (i = 2; i < num_ents; i++) draw_entity(i);
    draw_entity(0); draw_entity(1);
    // player markers
    int p;
    for (p = 0; p < MAX_PLAYERS; p++)
    {
        if (!pl_joined[p] || pl_ctrl[p] < 0) continue;
        Ent* e = &ents[pl_ctrl[p]];
        if (!e->alive) continue;
        int bob = (frame / 8) % 2;
        spr_wrapped(R_MARK0 + p, px(e->x) + ent_w(e) / 2, px(e->y) - 16 - bob, false, 13);
    }
    if (fx_t > 0)
    {
        int k = 2 - fx_t / 5;
        if (k < 0) k = 0;
        spr(R_SPARK0 + k, fx_x, fx_y, false);
    }
    draw_hud();
}

void draw_title()
{
    draw_bg(BG_TITLE);
    int bob = (int)(sin((float)frame * 0.08) * 6.0);
    draw_text_c(320, 44 + bob / 2, "KILLER BEE", true, accent_col());
    draw_text_c(320, 96, "A HIVE BATTLE FOR UP TO 4 PLAYERS", false, 0xFFE0F0FF);
    spr(R_Q_BLUE_FLY0 + (frame / 4) % 4, 110, 70 + bob, false);
    spr(R_Q_YEL_FLY0 + (frame / 4 + 2) % 4, 530, 70 - bob, true);
    // menu
    int k;
    for (k = 0; k < 3; k++)
    {
        int y = 136 + k * 30;
        int c = 0xFFA0A0A0;
        if (k == title_sel) { c = 0xFFFFFFFF; draw_rect(200, y - 3, 240, 26, 0x60000000); }
        if (k == 0) draw_text_c(320, y, "PLAY", false, c);
        if (k == 1)
        {
            if (difficulty == DIFF_EASY) draw_text_c(320, y, "< CPU: EASY >", false, c);
            if (difficulty == DIFF_NORMAL) draw_text_c(320, y, "< CPU: NORMAL >", false, c);
            if (difficulty == DIFF_HARD) draw_text_c(320, y, "< CPU: HARD >", false, c);
        }
        if (k == 2)
        {
            if (art_set == 0) draw_text_c(320, y, "< ART: CLEAN >", false, c);
            if (art_set == 1) draw_text_c(320, y, "< ART: GRUNGE >", false, c);
            if (art_set == 2) draw_text_c(320, y, "< ART: NES CLASSIC >", false, c);
        }
    }
    draw_text_c(320, 240, "A: FLAP / JUMP     B: STING / RIDE SNAIL     DOWN + B: DIVE", false, 0xFFC0C0C0);
    draw_text_c(320, 260, "DOWN + A: DROP THROUGH     Y, L OR R: SWITCH BEE", false, 0xFFC0C0C0);
    draw_text_c(320, 280, "WIN BY QUEEN, BERRIES OR SNAIL", false, 0xFFFFFFFF);
    if ((frame / 30) % 2 == 0) draw_text_c(320, 312, "PRESS START", true, 0xFFFFFFFF);
}

void draw_setup()
{
    draw_bg(BG_SETUP);
    draw_text_c(320, 22, "CHOOSE YOUR TEAM AND BEE", false, accent_col());
    draw_text_c(320, 42, "UP TO 4 PLAYERS - CPU BEES FILL EVERY EMPTY SLOT", false, 0xFFC0C0C0);
    int p;
    for (p = 0; p < MAX_PLAYERS; p++)
    {
        int y = 82 + p * 52;
        draw_rect(60, y - 6, 520, 44, 0x70000000);
        spr(R_MARK0 + p, 86, y + 14, false);
        if (!pl_joined[p])
        {
            select_gamepad(p);
            if (gamepad_is_connected()) draw_text(120, y + 6, "PRESS A TO JOIN   (CPU PLAYS)", false, 0xFF909090);
            else draw_text(120, y + 6, "NO GAMEPAD   (CPU PLAYS)", false, 0xFF606060);
            continue;
        }
        // team
        if (pl_team[p] == 0) draw_text(120, y + 6, "< BLUE >", false, team_col(0));
        else draw_text(120, y + 6, "< YELLOW >", false, team_col(1));
        // bee
        int base = R_Q_BLUE_FLY0;
        if (pl_team[p] == 1) base = R_Q_YEL_FLY0;
        if (pl_wantq[p]) { spr(base + (frame / 4) % 4, 270, y + 14, false); draw_text(300, y + 6, "QUEEN", false, 0xFFFFFFFF); }
        else
        {
            int wb = R_W_BLUE_WALK0; if (pl_team[p] == 1) wb = R_W_YEL_WALK0;
            spr(wb + (frame / 6) % 4, 270, y + 16, false); draw_text(300, y + 6, "WORKER", false, 0xFFFFFFFF);
        }
        if (pl_locked[p]) draw_text(420, y + 6, "LOCKED IN", false, 0xFF60FF60);
        else if ((frame / 20) % 2 == 0) draw_text(420, y + 6, "A: LOCK IN", false, 0xFFFFFFFF);
        if (pl_bumped[p] > 0) draw_text(300, y + 24, "QUEEN TAKEN - YOU ARE A WORKER", false, 0xFF6060FF);
    }
    draw_text_c(320, 292, "LEFT/RIGHT: TEAM     UP/DOWN, Y, L OR R: QUEEN / WORKER", false, 0xFFC0C0C0);
    draw_text_c(320, 310, "A: LOCK IN     B: UNLOCK / BACK", false, 0xFFC0C0C0);
    if (all_locked()) { if ((frame / 20) % 2 == 0) draw_text_c(320, 334, "PRESS START TO PLAY", false, accent_col()); }
    else draw_text_c(320, 334, "FIRST TO LOCK IN GETS THE QUEEN", false, accent_col());
}

void draw_over()
{
    draw_play();
    draw_rect(0, 0, SCREEN_W, SCREEN_H, 0x90000000);
    if (winner == 0) draw_text_c(320, 110, "BLUE WINS!", true, team_col(0));
    else draw_text_c(320, 110, "YELLOW WINS!", true, team_col(1));
    if (win_type == WIN_MILITARY) draw_text_c(320, 170, "MILITARY VICTORY - THE ENEMY QUEEN FELL 3 TIMES", false, 0xFFFFFFFF);
    if (win_type == WIN_ECONOMY) draw_text_c(320, 170, "ECONOMIC VICTORY - THE HIVE IS FULL OF BERRIES", false, 0xFFFFFFFF);
    if (win_type == WIN_SNAIL) draw_text_c(320, 170, "SNAIL VICTORY - THE SNAIL REACHED THE GOAL", false, 0xFFFFFFFF);
    if (win_type == WIN_HOOPS)
    {
        draw_text_c(320, 170, "BONUS WON - ALL 10 HONEYCOMB HOLES FILLED", false, 0xFFFFFFFF);
        draw_text_c(320, 194, "THEIR QUEEN STARTS THE NEXT MATCH WITH A 4TH CROWN", false, 0xFF60FFFF);
    }
    if (state_timer >= 30)
    {
        if (bonus_mode) draw_text_c(320, 240, "START: NEXT MATCH", false, 0xFFFFFFFF);
        else draw_text_c(320, 240, "START: BONUS ROUND - HONEYCOMB HOOPS", false, 0xFFFFFFFF);
        draw_text_c(320, 262, "Y, L OR R: TITLE", false, 0xFFC0C0C0);
    }
}

// ---------------------------------------------------------------- music + sfx
#define SFX_CH0 10
#define NUM_SFX_CH 6
int[MAX_TRACKS] tr_pos;
int[MAX_TRACKS] tr_timer;
int[MAX_TRACKS] tr_on;
int cur_song;
int song_first;
int song_n;
int song_cool;
int mus_trans;
int sfx_next;
float[97] semis;           // speed for -48..+48 semitones
int[4] octave_tbl = { 0, 12, -12, 0 };

void audio_init()
{
    int k;
    semis[48] = 1.0;
    float up = pow(2.0, 1.0 / 12.0);
    for (k = 1; k <= 48; k++) { semis[48 + k] = semis[47 + k] * up; semis[48 - k] = semis[49 - k] / up; }
    set_global_volume(0.32);
    cur_song = -1;
}

void stop_music()
{
    int k;
    for (k = 0; k < MAX_TRACKS; k++) { tr_on[k] = 0; stop_channel(k); }
}

void start_song(int s)
{
    stop_music();
    cur_song = s;
    song_first = mus_songs[s * 2];
    song_n = mus_songs[s * 2 + 1];
    int k;
    for (k = 0; k < song_n; k++)
    {
        tr_pos[k] = mus_tracks[(song_first + k) * 5];
        tr_timer[k] = 1;
        tr_on[k] = 1;
    }
    mus_trans = 0;
}

void music_tick()
{
    int k;
    for (k = 0; k < song_n; k++)
    {
        if (!tr_on[k]) continue;
        tr_timer[k]--;
        if (tr_timer[k] > 0) continue;
        int t = song_first + k;
        int n = mus_data[tr_pos[k]];
        if (n == -1)
        {
            if (cur_song == SONG_WIN) { tr_on[k] = 0; stop_channel(k); continue; }
            tr_pos[k] = mus_tracks[t * 5];
            if (k == 0) mus_trans = octave_tbl[rand8() & 3];      // lead may jump an octave each loop
            n = mus_data[tr_pos[k]];
        }
        int d = mus_data[tr_pos[k] + 1];
        tr_pos[k] += 2;
        tr_timer[k] = d;
        int inst = mus_tracks[t * 5 + 1];
        float vol = (float)mus_tracks[t * 5 + 3] / 100.0;
        select_channel(k);
        if (n == 0) { stop_channel(k); continue; }
        set_channel_volume(vol);
        if (inst < 0) { set_channel_speed(1.0); play_sound_in_channel(n, k); continue; }
        int semi = n - mus_tracks[t * 5 + 2];
        if (mus_tracks[t * 5 + 4]) semi += mus_trans;
        if (semi < -48) semi = -48;
        if (semi > 48) semi = 48;
        set_channel_speed(semis[48 + semi]);
        play_sound_in_channel(inst, k);
    }
}

void play_sfx(int snd, float vol)
{
    int ch = SFX_CH0 + sfx_next;
    sfx_next = (sfx_next + 1) % NUM_SFX_CH;
    select_channel(ch);
    set_channel_volume(vol);
    set_channel_speed(1.0);
    play_sound_in_channel(snd, ch);
}

// a big moment: switch to a different song, at most once every 4 seconds
void music_event()
{
    if (song_cool > 0 || game_state != ST_PLAY) return;
    int s = rand8() % NUM_SONGS;
    if (s == cur_song) s = (s + 1) % NUM_SONGS;
    start_song(s);
    mus_trans = octave_tbl[rand8() & 3];        // each new song starts at a random octave
    song_cool = SONG_COOL;
}

void handle_events()
{
    int k;
    for (k = 0; k < ev_count; k++)
    {
        int ev = ev_list[k];
        if (ev == EV_JUMP) play_sfx(SND_JUMP, 0.5);
        if (ev == EV_FLAP) play_sfx(SND_FLAP, 0.35);
        if (ev == EV_PICK) play_sfx(SND_PICK, 0.6);
        if (ev == EV_DEPOSIT) play_sfx(SND_DEPOSIT, 0.7);
        if (ev == EV_HITQ) play_sfx(SND_HITQ, 0.8);
        if (ev == EV_MENU) play_sfx(SND_MENU, 0.6);
        if (ev == EV_DASH) play_sfx(SND_DASH, 0.6);
        if (ev == EV_HIT) play_sfx(SND_HIT, 0.8);
        if (ev == EV_CLANK) play_sfx(SND_CLANK, 0.8);
        if (ev == EV_ARM) play_sfx(SND_ARM, 0.7);
        if (ev == EV_YOYO) play_sfx(SND_YOYO, 0.6);
        if (ev == EV_RIDE) play_sfx(SND_RIDE, 0.7);
        if (ev == EV_LOCK) play_sfx(SND_LOCK, 0.7);
        if (ev == EV_BUMP) play_sfx(SND_BUMP, 0.7);
        if (ev == EV_DIVE) play_sfx(SND_DIVE, 0.7);
        if (ev == EV_FEED) play_sfx(SND_FEED, 0.8);
        if (ev == EV_THROW) play_sfx(SND_THROW, 0.6);
        if (ev == EV_SCORE_HOLE) play_sfx(SND_DEPOSIT, 0.8);
        if (ev == EV_VINE) play_sfx(SND_PICK, 0.7);
        if (ev == EV_STUN) play_sfx(SND_STUN, 0.8);
        if (ev == EV_MUSIC) music_event();
        if (ev == EV_WIN) start_song(SONG_WIN);
    }
}

// ---------------------------------------------------------------- main
void main(void)
{
    define_all_regions();
    audio_init();
    game_init(12345);
    start_song(0);
    int last_state = ST_TITLE;
    while (true)
    {
        read_pads();
        tex_base = art_set * TEX_PER_SET;
        if (game_state == ST_TITLE) rng_state = rng_state ^ (get_frame_counter() << 3);
        int before = game_state;
        game_frame();
        // a new match always opens with a fresh song
        if (game_state == ST_PLAY && before != ST_PLAY && before != ST_PAUSE) song_cool = 0;
        if (game_state == ST_PLAY && song_cool > 0) song_cool--;
        handle_events();
        if (game_state == ST_TITLE && before != ST_TITLE) start_song(0);
        music_tick();
        clear_screen(color_black);
        if (game_state == ST_TITLE) draw_title();
        else if (game_state == ST_SETUP) draw_setup();
        else if (game_state == ST_OVER) draw_over();
        else
        {
            draw_play();
            if (game_state == ST_PAUSE)
            {
                draw_rect(0, 0, SCREEN_W, SCREEN_H, 0x80000000);
                draw_text_c(320, 150, "PAUSED", true, 0xFFFFFFFF);
            }
        }
        end_frame();
    }
}
