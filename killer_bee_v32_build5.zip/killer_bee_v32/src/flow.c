// =====================================================================
//  KILLER BEE for Vircon32 - game flow (platform independent)
//  Title -> team select -> match -> freeze -> result.
//  The platform layer fills pad[] / pad_new[] each frame, calls
//  game_frame(), then draws from the state and plays ev_list[].
// =====================================================================

int setup_msg_timer;

void reset_players()
{
    int p;
    for (p = 0; p < MAX_PLAYERS; p++)
    {
        pl_joined[p] = 0;
        pl_team[p] = DEFAULT_TEAM(p);    // Vircon32: P1/P3 blue, P2/P4 yellow
        pl_wantq[p] = 1;
        pl_locked[p] = 0;
        pl_lockorder[p] = 0;
        pl_ctrl[p] = -1;
        pl_bumped[p] = 0;
    }
    lock_counter = 0;
}

void enter_title()
{
    game_state = ST_TITLE;
    state_timer = 0;
}

void enter_setup()
{
    game_state = ST_SETUP;
    reset_players();
    pl_joined[0] = 1;                // whoever pressed START on the title is P1
    state_timer = 0;
}

int queen_taken(int team, int except)
{
    int p;
    for (p = 0; p < MAX_PLAYERS; p++)
        if (p != except && pl_joined[p] && pl_locked[p] && pl_team[p] == team && pl_wantq[p]) return 1;
    return 0;
}

int humans_on(int team)
{
    int p; int n = 0;
    for (p = 0; p < MAX_PLAYERS; p++)
        if (pl_joined[p] && pl_team[p] == team) n++;
    return n;
}

int all_locked()
{
    int p; int any = 0;
    for (p = 0; p < MAX_PLAYERS; p++)
        if (pl_joined[p]) { any = 1; if (!pl_locked[p]) return 0; }
    return any;
}

// assign every human to a bee: the locked-in queen-chooser gets the queen,
// workers go in lock-in order; the CPU plays everything else
void assign_bees()
{
    int t; int p; int k;
    team_size = imax(3, imax(humans_on(0), humans_on(1)));
    if (team_size > 4) team_size = 4;
    if (FIXED_TEAM_SIZE) team_size = FIXED_TEAM_SIZE;
    for (p = 0; p < MAX_PLAYERS; p++) pl_ctrl[p] = -1;
    for (t = 0; t < 2; t++)
    {
        for (p = 0; p < MAX_PLAYERS; p++)
            if (pl_joined[p] && pl_team[p] == t && pl_wantq[p]) pl_ctrl[p] = t;
        int next = 0;
        for (k = 1; k <= lock_counter; k++)
            for (p = 0; p < MAX_PLAYERS; p++)
                if (pl_joined[p] && pl_team[p] == t && !pl_wantq[p] && pl_lockorder[p] == k)
                {
                    pl_ctrl[p] = worker_index(t, next);
                    next++;
                }
    }
}

void setup_update()
{
    int p;
    state_timer++;
    for (p = 0; p < MAX_PLAYERS; p++)
    {
        int b = pad_new[p];
        if (pl_bumped[p] > 0) pl_bumped[p]--;
        if (!pl_joined[p])
        {
            if (b & (BTN_A | BTN_START)) { pl_joined[p] = 1; emit(EV_MENU); }
            continue;
        }
        if (pl_locked[p])
        {
            if (b & BTN_B) { pl_locked[p] = 0; emit(EV_MENU); }
            else if ((b & BTN_START) && all_locked())
            {
                assign_bees();
                start_match();
                return;
            }
            continue;
        }
        if (b & (BTN_LEFT | BTN_RIGHT)) { pl_team[p] = 1 - pl_team[p]; emit(EV_MENU); }
        if (b & (BTN_SELECT | BTN_UP | BTN_DOWN)) { pl_wantq[p] = 1 - pl_wantq[p]; emit(EV_MENU); }
        if (b & BTN_B) { pl_joined[p] = 0; if (p == 0) { enter_title(); return; } emit(EV_MENU); }
        else if (b & (BTN_A | BTN_START))
        {
            // first to lock in gets the queen; anyone after is bumped to worker
            if (pl_wantq[p] && queen_taken(pl_team[p], p)) { pl_wantq[p] = 0; pl_bumped[p] = 90; emit(EV_BUMP); }
            // a team can field at most 4 bees
            if (humans_on(pl_team[p]) > 4) continue;
            pl_locked[p] = 1;
            lock_counter++;
            pl_lockorder[p] = lock_counter;
            emit(EV_LOCK);
        }
    }
}

// NES cycle_ctrl: SELECT moves a player to the next bee on the team
// (queen -> worker -> worker ...), skipping dead bees and teammates' bees
void cycle_ctrl(int p)
{
    int cur = pl_ctrl[p];
    if (cur < 0) return;
    int team = ents[cur].team;
    int[4] order;
    int n = 0; int k;
    order[n] = team; n++;
    for (k = 0; k < team_size - 1; k++) { order[n] = worker_index(team, k); n++; }
    int pos = 0;
    for (k = 0; k < n; k++) if (order[k] == cur) pos = k;
    for (k = 1; k < n; k++)
    {
        int cand = order[(pos + k) % n];
        if (!ents[cand].alive) continue;
        if (player_of(cand) >= 0) continue;
        pl_ctrl[p] = cand;
        emit(EV_MENU);
        return;
    }
}

void gather_inputs()
{
    int i;
    for (i = 0; i < num_ents; i++)
    {
        Ent* e = &ents[i];
        if (!e->alive) continue;
        int p = -1;
        if (!cpu_all) p = player_of(i);
        if (p >= 0)
        {
            e->inp = pad[p] & (BTN_LEFT | BTN_RIGHT | BTN_UP | BTN_DOWN | BTN_A | BTN_B);
            e->inpn = pad_new[p] & (BTN_LEFT | BTN_RIGHT | BTN_UP | BTN_DOWN | BTN_A | BTN_B);
        }
        else
        {
            if (e->isq) ai_queen(i); else ai_worker(i);
            e->inp = ai_t0;
            e->inpn = ai_t1;
        }
    }
}

void play_update()
{
    int p; int i;
    for (p = 0; p < MAX_PLAYERS; p++)
        if (pl_joined[p] && (pad_new[p] & BTN_START)) { game_state = ST_PAUSE; emit(EV_MENU); return; }
    for (p = 0; p < MAX_PLAYERS; p++)
        if (pl_joined[p] && (pad_new[p] & BTN_SELECT)) cycle_ctrl(p);
    gather_inputs();
    // FAIRNESS: which team's bees update first matters (measured: going second
    // won ~2:1 on Meadow). Alternating by frame parity was not enough, because
    // events like berry regrowth run on even frames only and lock onto the
    // parity. The order is now chosen at random every frame.
    int k;
    int reverse = rand8() & 1;
    for (k = 0; k < num_ents; k++)
    {
        i = k;
        if (reverse) i = num_ents - 1 - k;
        Ent* e = &ents[i];
        if (!e->alive)
        {
            if (e->timer > 0) { e->timer--; if (e->timer == 0) spawn_entity(i); }
            continue;
        }
        if (e->isq) queen_update(i); else worker_update(i);
    }
    if (bonus_mode) hoops_vine_strikes();
    combat();
    tb_update();
    if (bonus_mode) hoops_update();
    else { snail_update(); berry_update(); }
    if (fx_t > 0) fx_t--;
}

void game_frame()
{
    ev_count = 0;
    frame++;
    int p;
    if (game_state == ST_TITLE)
    {
        // title menu: PLAY / CPU difficulty / ART style
        state_timer++;
        for (p = 0; p < MAX_PLAYERS; p++)
        {
            int b = pad_new[p];
            if (b & BTN_UP) { title_sel = (title_sel + TITLE_ROWS - 1) % TITLE_ROWS; emit(EV_MENU); }
            if (b & BTN_DOWN) { title_sel = (title_sel + 1) % TITLE_ROWS; emit(EV_MENU); }
            if (title_sel == 3 && (b & (BTN_LEFT | BTN_RIGHT | BTN_A))) { music_on = (music_on + 1) % 3; emit(EV_MENU); }   // PS1: 1 MY SONGS, 2 SYNTH, 0 OFF
            if (title_sel == 1 && (b & BTN_LEFT)) { difficulty = (difficulty + 2) % 3; emit(EV_MENU); }
            if (title_sel == 1 && (b & (BTN_RIGHT | BTN_A))) { difficulty = (difficulty + 1) % 3; emit(EV_MENU); }
            if (title_sel == 2 && (b & BTN_LEFT)) { art_set = (art_set + ART_SETS - 1) % ART_SETS; emit(EV_MENU); }
            if (title_sel == 2 && (b & (BTN_RIGHT | BTN_A))) { art_set = (art_set + 1) % ART_SETS; emit(EV_MENU); }
            if ((b & BTN_START) || (title_sel == 0 && (b & BTN_A))) { emit(EV_MENU); enter_setup(); return; }
        }
    }
    else if (game_state == ST_SETUP) setup_update();
    else if (game_state == ST_PLAY) play_update();
    else if (game_state == ST_PAUSE)
    {
        for (p = 0; p < MAX_PLAYERS; p++)
            if (pl_joined[p] && (pad_new[p] & BTN_START)) { game_state = ST_PLAY; emit(EV_MENU); }
    }
    else if (game_state == ST_FREEZE)
    {
        if (fx_t > 0) fx_t--;
        state_timer--;
        if (state_timer <= 0) { game_state = ST_OVER; state_timer = 0; }
    }
    else if (game_state == ST_OVER)
    {
        state_timer++;
        if (state_timer < 30) return;
        for (p = 0; p < MAX_PLAYERS; p++)
        {
            // after a match: bonus round; after a bonus round: the next match
            if (pad_new[p] & BTN_START) { if (bonus_mode) start_match(); else start_bonus(); return; }
            if (pad_new[p] & BTN_SELECT) { emit(EV_MENU); bonus_mode = 0; bonus_pending_crown = -1; enter_title(); return; }
        }
    }
}

void game_init(int seed)
{
    rng_state = seed | 1;
    frame = 0;
    last_level = -1;
    force_level = 0;
    cpu_all = 0;
    team_size = 3;
    difficulty = DIFF_NORMAL;
    art_set = 0;
    title_sel = 0;
    music_on = 1;
    bonus_mode = 0;
    bonus_pending_crown = -1;
    reset_players();
    enter_title();
}
