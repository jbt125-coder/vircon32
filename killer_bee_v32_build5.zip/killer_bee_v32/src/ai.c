// =====================================================================
//  KILLER BEE for Vircon32 - CPU players
//  Translated from the NES routines ai_worker, find_berry, lookup_launch,
//  ai_queen, queen_overhead, armed_open, ai_avoid_yoyo and ai_react.
//  Distances that relate to bee movement are NES values x 1.5; positions on
//  the board use the stretched layout. Team 1 targets are exact mirrors of
//  team 0 targets (the NES tables were not; see the README).
// =====================================================================

// How a CPU queen reacts to an incoming stinger, per difficulty (Easy, Normal,
// Hard), in eighths: freeze, dodge; the rest counter-sting. Tuned against a
// sharp scripted player (tests/test_main.c head-to-head): human share of first
// kills ~76% Easy, ~55% Normal, ~30% Hard. (NES original: 2/8, 2/8 = ~35%.)
int[3] react_freeze = { 3, 2, 0 };
int[3] react_dodge = { 2, 4, 0 };
int ai_t0;      // held buttons
int ai_t1;      // new presses
int ai_b;       // extra buttons (yo-yo spin)

// mirrored per-team targets
int home_x(int team) { if (team == 0) return 14; return mirror_x(14, WW); }        // worker x at the hive
int guard_x(int team) { if (team == 0) return 104; return mirror_x(104, WW); }    // worker x
int qhome_cx(int team) { if (team == 0) return 100; return SCREEN_W - 100; }      // queen centre x
int guard_qcx(int team) { if (team == 0) return 180; return SCREEN_W - 180; }     // queen centre x
int box_x(int team) { if (team == 0) return lp[LP_BOX0]; return lp[LP_BOX1]; }
int box_wx(int team) { return box_x(team) + 14; }                                  // worker x centred on its box

// NEW: would a berry thrown right now hit the goal? Simulates the same arc
// physics as tb_update (1 = own hive, 2 = own snail with a teammate riding).
int throw_would_hit(Ent* e, int goal)
{
    int dir = 1;
    if (e->face == 1) dir = -1;
    int x = e->x + dir * 6 * FP;
    int y = e->y - 4 * FP;
    int vx = dir * TB_VX;
    if ((dir > 0 && (ai_t0 & BTN_RIGHT)) || (dir < 0 && (ai_t0 & BTN_LEFT))) vx += dir * TB_VX_RUN;
    int vy = TB_VY;
    int n;
    for (n = 0; n < 70; n++)
    {
        tb_step(&x, &y, &vx, &vy);                          // exactly the real berry's physics
        int pxx = tbs_x; int pyy = tbs_y;
        if (goal == 1 && tb_hive_team(x, pyy) == e->team) return 1;
        if (goal == 2 && snail_rider >= 0 && ents[snail_rider].team == e->team)
        {
            int sx = px(snail_x);
            if (iabs(dxs(sx + 12, pxx + 6)) < 18 && pyy + 12 >= snail_ry && pyy <= lp[LP_SNAIL_Y] + 12) return 1;
        }
        if (vy > 0 && pyy > 330) return 0;
        // stopped by a platform below it?
        if (vy > 0 && (is_plat(colof(pxx + 2), rowof(pyy + 12)) || is_plat(colof(pxx + 9), rowof(pyy + 12)))) return 0;
    }
    return 0;
}

// NEW: instant hive-throw check from the precomputed table (tools/gen_levels.py).
// The table is for blue; yellow looks up the mirror image, so it is fair by design.
int throw_table_hit(Ent* e, int running)
{
    if (!e->ground) return 0;
    int ri = lvl_rowidx[rowof(px(e->y) + WH)];
    if (ri == 255) return 0;
    int x2 = ((e->x + 64 + 16777216) >> 7) - 131072;   // half-pixel position (sign-safe on Vircon32)
    int dirbit = 0;
    if (e->face == 1) dirbit = 1;
    if (e->team == 1) { x2 = 1256 - x2; dirbit = 1 - dirbit; }
    if (x2 < 0 || x2 > 1256) return 0;
    int w = lvl_throw[(((ri * 2) + running) * 2 + dirbit) * THROW_WORDS + (x2 >> 5)];
    return (w >> (x2 & 31)) & 1;
}

// NEW (Hoops): would a berry thrown now go into our moving honeycomb?
int hoops_throw_hits(Ent* e)
{
    int dir = 1;
    if (e->face == 1) dir = -1;
    int x = e->x + dir * 6 * FP;
    int y = e->y - 4 * FP;
    int vx = dir * TB_VX;
    if ((dir > 0 && (ai_t0 & BTN_RIGHT)) || (dir < 0 && (ai_t0 & BTN_LEFT))) vx += dir * TB_VX_RUN;
    int vy = TB_VY;
    if (!e->ground) vy = TB_VY + e->vy / 2;
    int n;
    for (n = 1; n < 60; n++)
    {
        tb_step(&x, &y, &vx, &vy);
        if (berry_in_hc(e->team, tbs_x, tbs_y, hc_y_at(hc_phase + n))) return 1;
        if (vy > 0 && tbs_y > SCREEN_H) return 0;
        if (vy > 0 && (is_plat(colof(tbs_x + 2), rowof(tbs_y + 12)) || is_plat(colof(tbs_x + 9), rowof(tbs_y + 12)))) return 0;
    }
    return 0;
}

// NES hold_toward_t2
void hold_toward(Ent* e, int tx)
{
    int d = dxs(px(e->x), tx);
    if (d >= 3) ai_t0 = ai_t0 | BTN_RIGHT;
    else if (d <= -3) ai_t0 = ai_t0 | BTN_LEFT;
}

// NES find_berry: nearest berry (distance weighted like the NES square grid)
int find_berry(Ent* e)
{
    int best = 1000000;
    int bi = -1;
    int b;
    for (b = 0; b < NUM_BERRIES; b++)
    {
        if (!berry_on[b]) continue;
        int d = iabs(dxs(px(e->x), berry_px[b])) * 3 + iabs(berry_py[b] - px(e->y)) * 5;
        // FAIRNESS: ties used to go to the first berry listed (always the left one,
        // i.e. toward blue's side for both teams). Now ties go toward your own hive.
        int closer_home = 0;
        if (bi >= 0 && d == best)
        {
            if (e->team == 0 && berry_px[b] < berry_px[bi]) closer_home = 1;
            if (e->team == 1 && berry_px[b] > berry_px[bi]) closer_home = 1;
        }
        if (d < best || closer_home) { best = d; bi = b; }
    }
    return bi;
}

// NES lookup_launch: launch column for a worker on row `row` heading to x = tx
int lookup_launch(Ent* e, int row, int tx)
{
    if (row < 0 || row >= 30) return 255;
    int ri = lvl_rowidx[row];
    if (ri == 255) return 255;
    int c = colof(px(e->x) + 6);
    if (c < 0) c = 0;
    if (c > 31) c = 31;
    int idx = ri * 32 + c;
    int d = dxs(px(e->x), tx);
    if (d >= 0)
    {
        if (lvl_launch_r[idx] != 255) return lvl_launch_r[idx];
        return lvl_launch_l[idx];
    }
    if (lvl_launch_l[idx] != 255) return lvl_launch_l[idx];
    return lvl_launch_r[idx];
}

// NES ai_worker. Writes ai_t0 / ai_t1.
void ai_worker(int i)
{
    Ent* e = &ents[i];
    ai_t0 = 0; ai_t1 = 0; ai_b = 0;
    int tsnail = 0;
    int throw_goal = 0;              // NEW: 1 = own hive, 2 = feed own snail
    int tx; int trow;
    if (snail_rider == i) return;                  // ride it home
    int team = e->team;
    if (e->ai_nodrop > 0) e->ai_nodrop--;
    if (e->ai_alt > 0)
    {
        // escaping a dead end (any worker, armed or not): head the other way, low
        e->ai_alt--;
        tx = e->ai_altx; trow = 26;
    }
    else if (bonus_mode)
    {
        // HOOPS: carrying -> to our honeycomb; otherwise -> the nearest loose berry on a
        // reachable level, or wait on the ground under the nearest hanging berry
        if (e->carry) { tx = hc_left(team) + HC_W / 2 - WW / 2; trow = 26; throw_goal = 3; }
        else
        {
            int best = 1000000; int k;
            tx = px(e->x); trow = 26;
            for (k = 0; k < MAX_TB; k++)
            {
                if (tb_on[k] == 0) continue;
                int bx = px(tb_x[k]); int by = px(tb_y[k]);
                int brow = rowof(by + 12);
                if (tb_on[k] == 1) brow = 26;                 // falling: meet it below
                if (brow < 20) continue;                      // upper levels: queens only
                int d = iabs(dxs(px(e->x), bx)) + iabs(by - px(e->y));
                if (d < best) { best = d; tx = bx; trow = brow; }
            }
            if (best == 1000000)
            {
                for (k = 0; k < NUM_VINES; k++)
                {
                    if (!vine_on[k]) continue;
                    int d = iabs(dxs(px(e->x), vine_x[k] - 6));
                    if (d < best) { best = d; tx = vine_x[k] - 6; trow = 26; }
                }
            }
        }
    }
    else if (e->warrior)
    {
        // armed: hunt the enemy queen and spin when she's close
        Ent* q = &ents[1 - team];
        if (q->alive)
        {
            tx = px(q->x) + 6;
            trow = rowof(px(q->y) + 24);
            if (trow > 26) trow = 26;
            if (e->cool == 0)
            {
                int ddx = iabs(dxs(px(e->x) + 6, px(q->x) + 12));
                int ddy = iabs(px(q->y) + 12 - px(e->y) - 6);
                if (ddx < 30 && ddy < 30) ai_b = BTN_B;
            }
        }
        else { tx = guard_x(team); trow = 26; }
    }
    else if (e->carry && snail_rider >= 0 && snail_rider != i && ents[snail_rider].team == team && snail_close_to_win(team))
    {
        // NEW: our snail is close to winning: walk into it to feed it the berry
        tx = px(snail_x) + 6; trow = snail_row; throw_goal = 2;
    }
    else if (e->carry)
    {
        int armed_mate = 0;
        int k;
        for (k = 2; k < num_ents; k++)
            if (ents[k].team == team && ents[k].alive && ents[k].warrior) armed_mate = 1;
        if (lp[LP_BOXES] && !armed_mate) { tx = box_wx(team); trow = lp[LP_BOXROW]; }
        else { tx = home_x(team); trow = 26; throw_goal = 1; }
    }
    else
    {
        int go_snail = 0;
        if (e->slot == 2 && snail_rider < 0) go_snail = 1;     // the second worker prefers the snail
        if (!go_snail)
        {
            int b = find_berry(e);
            if (b >= 0) { tx = berry_px[b]; trow = berry_row[b] + 1; }
            else if (snail_rider < 0) go_snail = 1;
            else { tx = guard_x(team); trow = 26; }
        }
        if (go_snail)
        {
            tx = px(snail_x) + 6; trow = snail_row; tsnail = 1;
        }
    }
    // ---- movement (NES @move)
    if (!e->ground)
    {
        if (e->vy < 0) { }                         // rising: straight up, steer after the apex
        else if (e->ai_jdir) ai_t0 = ai_t0 | e->ai_jdir;
        else hold_toward(e, tx);
    }
    else
    {
        e->ai_jdir = 0;
        int srow = rowof(px(e->y) + WH);           // standing row
        int walk = 0;
        if (trow > srow)
        {
            // target is lower: drop through when near it (or when a wall blocks)
            if ((iabs(dxs(px(e->x), tx)) < 11 || e->block) && srow < 26 && e->ai_nodrop == 0)
            {
                ai_t0 = BTN_DOWN | BTN_A; ai_t1 = BTN_A;
            }
            else walk = 1;
        }
        else if (trow < srow)
        {
            // commit to one launch point while the tier and target stay the same
            int l;
            if (srow == e->ai_lrow && tx == e->ai_ltx) l = e->ai_launch;
            else
            {
                l = lookup_launch(e, srow, tx);
                e->ai_launch = l; e->ai_lrow = srow; e->ai_ltx = tx;
            }
            if (l == 255) walk = 1;
            else
            {
                int lx = (l & 63) * CW + 4;
                if (iabs(dxs(px(e->x), lx)) < 3)
                {
                    if (l & 64) e->ai_jdir = BTN_LEFT; else e->ai_jdir = BTN_RIGHT;
                    ai_t0 = BTN_A; ai_t1 = BTN_A;
                }
                else
                {
                    hold_toward(e, lx);
                    walk = 2;                      // still check for being stuck
                }
            }
        }
        else
        {
            // same level: a wall in the way -> go down and under
            if (e->block && srow < 26 && e->ai_nodrop == 0) { ai_t0 = BTN_DOWN | BTN_A; ai_t1 = BTN_A; }
            else if (tsnail && touching_snail(i)) { ai_t0 = BTN_B; ai_t1 = BTN_B; }
            else walk = 1;
        }
        if (walk == 1) hold_toward(e, tx);
        // NEW: CPU throws when a simulated throw would actually land (hive / own snail)
        int running = 0;
        if ((e->face == 0 && (ai_t0 & BTN_RIGHT)) || (e->face == 1 && (ai_t0 & BTN_LEFT))) running = 1;
        int shot = 0;
        if (throw_goal == 1 && e->carry) shot = throw_table_hit(e, running);                    // hive: table lookup
        if (throw_goal == 3 && e->carry && iabs(dxs(px(e->x), tx)) < 260) shot = hoops_throw_hits(e);    // moving honeycomb
        if (throw_goal == 2 && e->carry && iabs(dxs(px(e->x), tx)) < 200) shot = throw_would_hit(e, 2);  // snail moves: simulate (rare)
        if (shot)
        {
            ai_t0 = ai_t0 | BTN_B; ai_t1 = ai_t1 | BTN_B;
        }
        // a drop-through that did not happen (wall below, ground floor...)
        if ((e->ai_lastin & BTN_DOWN) && e->ground && e->y == e->ai_lasty) e->ai_nodrop = 120;
        // NEW: stuck check on every path, armed or not. NES only checked while
        // walking unarmed, so armed workers could push a wall forever.
        if (e->x == e->ai_lastx && e->y == e->ai_lasty)
        {
            e->ai_stuck++;
            if (e->ai_stuck >= 60)
            {
                e->ai_stuck = 0;
                int dir = 1;                                   // turn away from where we pushed
                if (e->ai_lastin & BTN_RIGHT) dir = -1;
                else if (!(e->ai_lastin & BTN_LEFT) && (rand8() & 1)) dir = -1;
                int ax = px(e->x) + dir * (120 + (rand8() & 63));
                if (lp[LP_SIDE]) ax = wrapx(ax);
                else ax = imax(0, imin(SCREEN_W - WW, ax));
                e->ai_altx = ax;
                e->ai_alt = 90;
                e->ai_lrow = -1;                               // re-plan launches afterwards
            }
        }
        else e->ai_stuck = 0;
    }
    ai_t0 = ai_t0 | ai_b;
    ai_t1 = ai_t1 | ai_b;
    e->ai_lastx = e->x;
    e->ai_lasty = e->y;
    e->ai_lastin = ai_t0;
}

// NES armed_open: armed enemy worker whose yo-yo is recharging
int armed_open(int k)
{
    Ent* w = &ents[k];
    return w->alive && w->warrior && w->spin == 0 && w->cool > 0;
}

// NES ai_avoid_yoyo: keep clear of a spinning or ready yo-yo. 1 if fleeing.
// (The NES version could pick the wrong worker as "the threat" when deciding
// whether to climb or drop; this one uses the worker that triggered it.)
int ai_avoid_yoyo(int qi)
{
    Ent* q = &ents[qi];
    int k;
    for (k = 2; k < num_ents; k++)
    {
        Ent* w = &ents[k];
        if (w->team == q->team || !w->alive || !w->warrior) continue;
        if (w->spin == 0 && w->cool > 0) continue;
        int dx = dxs(px(q->x), px(w->x));
        if (iabs(dx - 6) >= 60) continue;
        if (iabs(px(w->y) - px(q->y) - 6) >= 60) continue;
        // FAIRNESS: flee by comparing CENTRES (worker centre - queen centre = dx - 6).
        // Comparing left edges sent both teams left whenever the worker was 0-12 px
        // to the right of the queen's edge - a blue/yellow asymmetry on Divide.
        int cdx = dx - 6;
        int dir = BTN_RIGHT;
        if (cdx > 0) dir = BTN_LEFT;              // move away horizontally
        else if (cdx == 0) { if (q->face == 0) dir = BTN_LEFT; }
        if (q->block) dir = dir ^ (BTN_LEFT | BTN_RIGHT);
        ai_t0 = dir;
        if (px(w->y) >= px(q->y) && q->vy >= 0)  // worker below us: climb
        {
            ai_t0 = ai_t0 | BTN_A;
            ai_t1 = BTN_A;
        }
        return 1;
    }
    return 0;
}

// NES ai_react: incoming stinger -> counter-sting (clash), dodge, or freeze.
// Easy also notices the dash 4 frames late.
int ai_react(int qi)
{
    Ent* q = &ents[qi];
    Ent* a = &ents[1 - qi];
    if (!a->alive || a->atk == 0) return 0;
    if (difficulty == DIFF_EASY && a->atk > DASH_FRAMES - 4) return 0;
    if (iabs(px(a->y) - px(q->y)) >= 30) return 0;
    int d = dxs(px(q->x), px(a->x));              // attacker relative to us
    int face;
    if (d == 0) return 0;                         // exactly overlapping: no meaningful side
    if (d < 0)
    {
        if (a->face != 0) return 0;               // must be heading toward us
        if (-d >= 78) return 0;
        face = BTN_LEFT;
    }
    else
    {
        if (a->face != 1) return 0;
        if (d >= 78) return 0;
        face = BTN_RIGHT;
    }
    ai_t0 = face;
    // react: 0 = froze up, 1 = dodge (flap clear), 2 = counter-sting
    int r = rand8() & 7;
    int act;
    act = 0;
    if (r >= react_freeze[difficulty]) act = 1;
    if (r >= react_freeze[difficulty] + react_dodge[difficulty]) act = 2;
    if (act == 0) return 0;
    if (act == 1 || q->cool > 0)
    {
        ai_t1 = BTN_A;
        ai_t0 = ai_t0 | BTN_A;
        return 1;
    }
    ai_t0 = ai_t0 | BTN_B;
    ai_t1 = ai_t0;
    return 1;
}

// NES queen_overhead: platform within 4 rows above? steer to its nearer edge
void queen_overhead(Ent* q)
{
    int row = rowof(px(q->y));
    int k;
    int blocked = 0;
    for (k = 0; k < 4; k++)
    {
        if (check_under(q, row)) { blocked = 1; break; }
        row--;
    }
    if (!blocked) return;
    int x = px(q->x);
    int lb = is_plat(colof(x + 3), row);
    int rb = is_plat(colof(x + 20), row);
    int goleft = 0;
    if (!rb && lb) { ai_t0 = (ai_t0 & ~(BTN_LEFT | BTN_RIGHT)) | BTN_RIGHT; return; }
    if (!lb && rb) goleft = 1;
    else if (!lb && !rb) return;
    else
    {
        // both blocked: scan for the nearer edge (ties go toward the board centre)
        int c0 = colof(x + 12);
        int kl = 0; int kr = 0; int c;
        c = c0;
        while (is_plat(c, row)) { kl++; c--; if (c < 0 && !lp[LP_SIDE]) { kl = 255; break; } if (kl > 32) break; }
        c = c0;
        while (is_plat(c, row)) { kr++; c++; if (c > 31 && !lp[LP_SIDE]) { kr = 255; break; } if (kr > 32) break; }
        if (kl < kr) goleft = 1;
        else if (kl == kr) { if (x + 12 >= SCREEN_W / 2) goleft = 1; }
    }
    if (goleft) ai_t0 = (ai_t0 & ~(BTN_LEFT | BTN_RIGHT)) | BTN_LEFT;
    else ai_t0 = (ai_t0 & ~(BTN_LEFT | BTN_RIGHT)) | BTN_RIGHT;
}

// The CPU queens hunt in alternating quarter-cycles (NES hunt_phase).
// DIVIDE BIAS FIX, part 1: on the NES blue always got the first window and
// yellow the window right after it; measured CPU-vs-CPU this alone swung the
// Divide board by ~100 of 400 matches. Which team goes first is now drawn at
// random each match (hunt_first, set in start_match).
int hunt_phase(int team)
{
    if (team == hunt_first) return 0;
    return 128;
}

// NES ai_queen
void ai_queen(int qi)
{
    Ent* q = &ents[qi];
    ai_t0 = 0; ai_t1 = 0;
    if (ai_react(qi)) return;
    if (!bonus_mode && ai_avoid_yoyo(qi)) return;
    int team = q->team;
    int tx = -1; int ty = -1;
    int k;
    Ent* eqb = &ents[1 - qi];
    if (bonus_mode)
    {
        // HOOPS: the vines are the objective - always go for the nearest one (queens
        // still sting each other when their paths cross; targeting each other made
        // both queens stand still face to face)
        {
            int best = 1000000;
            for (k = 0; k < NUM_VINES; k++)
            {
                if (!vine_on[k]) continue;
                int d = iabs(dxs(px(q->x) + 12, vine_x[k])) + iabs(vine_y[k] - px(q->y) - 12);
                if (d < best) { best = d; tx = vine_x[k]; ty = vine_y[k]; }
            }
            if (tx < 0) { tx = SCREEN_W / 2; ty = 150; }
        }
    }
    // 1) enemy snail rider
    if (tx < 0 && snail_rider >= 0 && ents[snail_rider].team != team)
    {
        tx = px(ents[snail_rider].x) + 6; ty = px(ents[snail_rider].y) + 6;
    }
    // 2) armed enemy worker, only while its yo-yo is recharging
    if (tx < 0)
        for (k = 2; k < num_ents; k++)
            if (ents[k].team != team && armed_open(k)) { tx = px(ents[k].x) + 6; ty = px(ents[k].y) + 6; break; }
    // 3) enemy worker carrying a berry
    if (tx < 0)
        for (k = 2; k < num_ents; k++)
            if (ents[k].team != team && ents[k].alive && ents[k].carry) { tx = px(ents[k].x) + 6; ty = px(ents[k].y) + 6; break; }
    Ent* eq = &ents[1 - qi];
    if (tx < 0)
    {
        if (((frame + hunt_phase(team)) & 0xC0) == 0)
        {
            // 4) hunt the enemy queen
            if (eq->alive) { tx = px(eq->x) + 12; ty = px(eq->y) + 12; }
            else { tx = qhome_cx(team); ty = 180; }
        }
        else
        {
            // guard: if the enemy queen comes close, turn and fight
            if (eq->alive && iabs(dxs(px(q->x), px(eq->x))) < 66 && iabs(px(eq->y) - px(q->y)) < 54)
            {
                tx = px(eq->x) + 12; ty = px(eq->y) + 12;
            }
            else { tx = guard_qcx(team); ty = 144; }   // hover above our own worker lane
        }
    }
    if (lp[LP_SIDE]) tx = wrapx(tx);
    // ---- NES @go
    if (q->ai_alt > 0) { q->ai_alt--; ty = 288; }        // detouring under a wall: stay low
    int cx = px(q->x) + 12;
    int cy = px(q->y) + 12;
    int d = dxs(cx, tx);
    // (d == 0: dead ahead either way, so no turn - ties used to go "right")
    if (d > 0)
    {
        if (d >= 21 || q->face != 0) ai_t0 = BTN_RIGHT;
    }
    else if (d < 0)
    {
        if (-d >= 21 || q->face == 0) ai_t0 = BTN_LEFT;
    }
    // standing on a platform with the target well below: drop through
    if (q->ground && px(q->y) < GROUND_Y_QUEEN && cy + 30 < ty)
    {
        ai_t0 = BTN_DOWN | BTN_A; ai_t1 = BTN_A;
        return;
    }
    if (q->block)
    {
        if (lp[LP_BOXES]) q->ai_alt = 60;                  // divide board: go under the wall
        else if (q->vy >= 0) { ai_t0 = ai_t0 | BTN_A; ai_t1 = BTN_A; }
    }
    if (ty + 3 < cy)
    {
        queen_overhead(q);
        if (q->vy >= 0) { ai_t0 = ai_t0 | BTN_A; ai_t1 = BTN_A; }
    }
    // NEW: rare CPU dive when the target is right below with a clear drop
    if (q->cool == 0 && !q->ground && iabs(d) < 12 && ty - cy > 40 && ty - cy < 160 && difficulty != DIFF_EASY)
    {
        int clear = 1; int r2;
        for (r2 = rowof(cy + 12); r2 < rowof(ty); r2++) if (check_under(q, r2)) clear = 0;
        int odds2 = 31;
        if (difficulty == DIFF_HARD) odds2 = 15;
        if (clear && (rand8() & odds2) == 0) { ai_t0 = BTN_DOWN | BTN_B; ai_t1 = BTN_B; return; }
    }
    if (q->cool == 0 && iabs(d) < 60 && iabs(ty - cy) < 18)
    {
        int facing = 0;
        if (d >= 0 && q->face == 0) facing = 1;
        if (d < 0 && q->face == 1) facing = 1;
        if (bonus_mode && iabs(d) < 12) facing = 1;     // right on a vine: a sting either way hits it
        int odds = 7;                                      // Normal: 1 in 8 per frame
        if (difficulty == DIFF_EASY) odds = 15;
        if (difficulty == DIFF_HARD) odds = 3;
        if (facing && (rand8() & odds) == 0)
        {
            ai_t0 = ai_t0 | BTN_B; ai_t1 = ai_t1 | BTN_B;  // reaction delay keeps the CPU beatable
        }
    }
}
