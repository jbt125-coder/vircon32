#!/usr/bin/env python3
"""KILLER BEE (Vircon32) - level data generator.
Ported from the NES tools/gen_assets.py: same five boards, same 32x30 cell grid,
same AI launch tables and the same build-time reachability proof. Each NES 8x8
cell becomes a 20x12 pixel cell, so the boards fill the 640x360 screen.
Writes src/levels.h (Vircon32 C dialect)."""
import sys, os
OUT = sys.argv[1] if len(sys.argv) > 1 else "src"
CW, CH = 20, 12
GROUND_ROW = 26
LEVELS = [
    dict(name="MEADOW",
         platforms={8: [(5, 11), (20, 26)], 14: [(0, 6), (13, 18), (25, 31)], 20: [(3, 9), (12, 19), (22, 28)]},
         berries=[(7, 7), (7, 24), (13, 2), (13, 29), (13, 14), (13, 17), (19, 5), (19, 26), (25, 9), (25, 22)],
         walls=[], shaft=None, snail=dict(y=200, goal=224)),
    dict(name="WRAP HIVE",
         platforms={10: [(3, 9), (13, 18), (22, 28)], 16: [(2, 7), (11, 20), (24, 29)], 20: [(4, 27)], 21: [(0, 1), (30, 31)]},
         berries=[(9, 5), (9, 26), (9, 14), (9, 17), (15, 5), (15, 26), (15, 13), (15, 18), (25, 7), (25, 24)],
         walls=[(4, r) for r in (17, 18, 19)] + [(27, r) for r in (17, 18, 19)],
         shaft=(14, 17), snail=dict(y=152, goal=200)),
]
LEVELS.append(dict(name="DIVIDE",
    platforms={8: [(4, 27)], 14: [(0, 6), (10, 14), (17, 21), (25, 31)], 20: [(3, 9), (22, 28)]},
    berries=[(7, 7), (7, 24), (7, 12), (7, 19), (13, 12), (13, 19), (19, 5), (19, 26), (25, 6), (25, 25)],
    walls=[(c, r) for c in (15, 16) for r in range(9, 22)], bumps=[(15, 21), (16, 21)],
    shaft=None, boxes=dict(row=14, cols=(28, 2)), snail=dict(y=200, goal=224)))
for base in (0, 1):
    L = dict(LEVELS[base]); L["side_wrap"] = True; L["name"] += " WARP"
    LEVELS.insert(2 + base, L)            # meadow, wrap hive, meadow warp, wrap hive warp, divide
# NEW: bonus board for HONEYCOMB HOOPS (not in the normal rotation). Open space at
# both sides for the moving honeycombs, two upper levels where berry vines hang,
# small ledges to shoot from. The berry list is unused (vines replace it).
LEVELS.append(dict(name="HONEYCOMB HOOPS",
    platforms={8: [(7, 24)], 14: [(6, 12), (19, 25)], 20: [(8, 10), (21, 23)], 22: [(14, 17)]},
    berries=[(7, 7), (7, 24), (7, 12), (7, 19), (13, 12), (13, 19), (19, 5), (19, 26), (25, 6), (25, 25)],
    walls=[], shaft=None, snail=dict(y=200, goal=224), bonus=True))

def build(L):
    P, shaft = L["platforms"], L["shaft"]
    wallset, bumps = set(L["walls"]), set(L.get("bumps", []))
    def ground_solid(c): return not (shaft and shaft[0] <= c <= shaft[1])
    def solid(c, r):
        if not (0 <= c < 32): return False
        if (c, r) in bumps: return True
        if r >= GROUND_ROW: return r < 30 and ground_solid(c)
        return any(a <= c <= b for a, b in P.get(r, []))
    def plat(c, r): return 0 <= r < GROUND_ROW and solid(c, r)
    def wall(c, r): return (c, r) in wallset
    stand = sorted({GROUND_ROW} | set(P), reverse=True)
    assert len(stand) <= 5
    rowidx = [255] * 30
    for i, s_ in enumerate(stand): rowidx[s_] = i
    def segments(s_):
        segs, c = [], 0
        while c < 32:
            if solid(c, s_):
                a = c
                while c < 32 and solid(c, s_): c += 1
                segs.append((a, c - 1))
            else: c += 1
        return segs
    def segment_of(c, s_):
        for a, b in segments(s_):
            if a <= c <= b: return (a, b)
    def launch_dir(c, s_, d):
        """a hop from column c drifting in direction d (+1 right, -1 left), or None."""
        if any(plat(c, r) or wall(c, r) for r in range(s_ - 8, s_)): return None
        n = c + d
        for r in range(s_ - 6, s_):
            if plat(n, r) and not any(wall(n, rr) for rr in range(r - 3, r)): return c | (0x40 if d < 0 else 0)
        return None
    def launch_val(c, s_):
        # FAIRNESS: the NES generator always tried "drift right" first, so a column
        # with platforms on both sides was recorded as a right hop for everyone.
        # The tables below now pick per direction; this stays for the proof.
        return launch_dir(c, s_, 1) if launch_dir(c, s_, 1) is not None else launch_dir(c, s_, -1)
    LL, LR = [], []
    for i in range(5):
        s_ = stand[i] if i < len(stand) else None
        for c in range(32):
            seg = segment_of(c, s_) if s_ is not None else None
            l = r_ = 255
            if seg:
                # heading left: nearest left-drifting hop to the left, else nearest hop either way
                left = [launch_dir(cc, s_, -1) for cc in range(c, seg[0] - 1, -1)]
                left = [v for v in left if v is not None]
                anyl = [v for v in (launch_val(cc, s_) for cc in range(c, seg[0] - 1, -1)) if v is not None]
                l = left[0] if left else (anyl[0] if anyl else 255)
                # heading right: the exact mirror
                right = [launch_dir(cc, s_, 1) for cc in range(c, seg[1] + 1)]
                right = [v for v in right if v is not None]
                anyr = [v for v in (launch_dir(cc, s_, -1) if launch_dir(cc, s_, 1) is None else launch_dir(cc, s_, 1) for cc in range(c, seg[1] + 1)) if v is not None]
                r_ = right[0] if right else (anyr[0] if anyr else 255)
            LL.append(l); LR.append(r_)
    def land_below(c, s_):
        for r in range(s_ + 1, 30):
            if solid(c, r): return r
        for r in range(5, 30):
            if solid(c, r): return r
    surfaces = {(s_, seg) for s_ in stand for seg in segments(s_)}
    start = (GROUND_ROW, segment_of(0, GROUND_ROW))
    reach, frontier = {start}, [start]
    while frontier:
        s_, (a, b) = frontier.pop(); nxt = []
        for c in range(a, b + 1):
            for d in (1, -1):
                v = launch_dir(c, s_, d)
                if v is not None:
                    n = (v & 0x3F) + (-1 if v & 0x40 else 1)
                    for r in range(s_ - 6, s_):
                        if plat(n, r): nxt.append((r, segment_of(n, r)))
            if s_ != GROUND_ROW and not wall(c, s_ + 1):
                r = land_below(c, s_); nxt.append((r, segment_of(c, r)))
        for n, side in ((a - 1, a), (b + 1, b)):
            if 0 <= n < 32 and not wall(n, s_ - 1) and not wall(side, s_ - 1):
                r = land_below(n, s_ if s_ != GROUND_ROW else GROUND_ROW - 1)
                if r is not None: nxt.append((r, segment_of(n, r)))
        for t in nxt:
            if t not in reach: reach.add(t); frontier.append(t)
    if L.get("bonus"):
        # bonus board: the two vine levels (rows 8 and 14) are for the flying queens;
        # every surface workers need (ledges + ground) must still be reachable
        surfaces = {sf for sf in surfaces if sf[0] >= 20}
        reach = {sf for sf in reach if sf[0] >= 20}
    assert reach == surfaces, (L["name"], "unreachable", surfaces - reach)
    grid = []
    for r in range(30):
        for c in range(32):
            grid.append((1 if solid(c, r) else 0) | (2 if wall(c, r) else 0))
    sn = L["snail"]; SW = 24
    def snail_x(nes_x): return round((nes_x + 8) * 2.5) - SW // 2
    goal_r = snail_x(sn["goal"]); goal_l = 640 - SW - goal_r
    bx = L.get("boxes")
    params = dict(snail_y=round(sn["y"] * 1.5), snail_start=320 - SW // 2, goal_l=goal_l, goal_r=goal_r,
                  wrap=1 if shaft else 0, sx0=(shaft[0] * CW if shaft else 0), sx1=((shaft[1] + 1) * CW if shaft else 0),
                  side=1 if L.get("side_wrap") else 0, boxes=1 if bx else 0,
                  box0=(bx["cols"][0] * CW if bx else 0), box1=(bx["cols"][1] * CW if bx else 0),
                  boxy=((bx["row"] - 2) * CH if bx else 0), boxrow=(bx["row"] if bx else 0),
                  vines=0 if L.get("side_wrap") else 1)
    return grid, rowidx, LL, LR, L["berries"], params, stand


# ---------------------------------------------------------------- throw tables (NEW)
# For blue workers standing on each tier, at every half-pixel x, facing left or
# right, standing or running: does a thrown berry land in the blue hive?
# Exactly mirrors the C berry physics (game.c tb_step / tb_update / tb_hive_team).
# Yellow uses the mirror image of this table in the game, so it is fair by design.
FP = 256
def pxr(v): return (v + 127 + ((v >> 8) & 1)) >> 8          # round half to even (game.c px)
def throw_table(L, grid, stand, p):
    side = bool(p["side"]); wrap = bool(p["wrap"]); sx0, sx1 = p["sx0"], p["sx1"]
    def grid_at(c, r):
        if r < 0: return 0
        if r >= 30: return 1
        if side: c = c % 32
        if c < 0 or c >= 32: return 0
        return grid[r * 32 + c]
    def is_plat(c, r): return grid_at(c, r) & 1
    def is_wall(c, r): return 0 if (r < 0 or r >= 30) else grid_at(c, r) & 2
    def wrapx(x):
        while x < 0: x += 640
        while x >= 640: x -= 640
        return x
    def colof(x):
        if side: x = wrapx(x)
        return -1 if x < 0 else x // 20
    def rowof(y): return -1 if y < 0 else y // 12
    def hive_team(xfp, y):
        if y < 270 or y > 316: return -1
        if xfp < 34 * FP: return 0
        if xfp > (640 - 12 - 34) * FP: return 1
        return -1
    def throw_hits(wx, wy, d, run):
        x = wx + d * 6 * FP; y = wy - 4 * FP
        vx = d * 896 + (d * 384 if run else 0); vy = -1152
        for n in range(90):
            oldy = pxr(y); oldx = x
            vy += 72
            if vy > 1536: vy = 1536
            x += vx; y += vy
            if side:
                if x + 6 * FP < 0: x += 640 * FP
                if x + 6 * FP > 640 * FP: x -= 640 * FP
            elif x < 0 or x > (640 - 12) * FP:
                x = oldx; vx = 0
            tx = pxr(x); ty = pxr(y)
            cl = colof(tx + 1); cr = colof(tx + 10); rr = rowof(ty + 6)
            if is_wall(cl, rr) or is_wall(cr, rr): x = oldx; vx = 0; tx = pxr(oldx)
            if ty < 60 and not (wrap and tx >= sx0 and tx + 12 <= sx1):
                y = 60 * FP
                if vy < 0: vy = 0
                ty = 60
            if wrap and ty >= 324: y -= 300 * FP; oldy -= 300; ty -= 300
            h = hive_team(x, ty)
            if h == 0: return True
            if vy >= 0:
                f0 = oldy + 12; f1 = ty + 12; r = (f0 + 11) // 12
                while r * 12 <= f1:
                    if is_plat(colof(tx + 2), r) or is_plat(colof(tx + 9), r): return False
                    r += 1
        return False
    words = []
    for ri in range(5):
        row = stand[ri] if ri < len(stand) else None
        for run in (0, 1):
            for dirbit in (0, 1):                       # 0 = facing right, 1 = facing left
                bits = [0] * 40
                if row is not None:
                    wy = (row * 12 - 12) * FP
                    for x2 in range(0, 1257):
                        if throw_hits(x2 * 128, wy, -1 if dirbit else 1, run):
                            bits[x2 >> 5] |= 1 << (x2 & 31)
                words += [b if b < 2**31 else b - 2**32 for b in bits]
    return words

def arr(name, data, per=32):
    s = f"int[{len(data)}] {name} =\n{{\n"
    for i in range(0, len(data), per):
        s += "    " + ", ".join(str(v) for v in data[i:i + per]) + ",\n"
    return s.rstrip(",\n") + "\n};\n"

if __name__ == "__main__":
    out = ["// generated by tools/gen_levels.py - do not edit", "#ifndef LEVELS_H", "#define LEVELS_H",
           f"#define NUM_LEVELS {len(LEVELS)}", f"#define NUM_MATCH_LEVELS {sum(1 for L in LEVELS if not L.get('bonus'))}",
           f"#define LEVEL_HOOPS {[i for i, L in enumerate(LEVELS) if L.get('bonus')][0]}", "#define NUM_BERRIES 10", ""]
    grids, rows, lls, lrs, brs, bcs, params, throws = [], [], [], [], [], [], [], []
    pkeys = ["snail_y", "snail_start", "goal_l", "goal_r", "wrap", "sx0", "sx1", "side", "boxes", "box0", "box1", "boxy", "boxrow", "vines"]
    for L in LEVELS:
        g, ri, ll, lr, br, p, stand = build(L)
        grids += g; rows += ri; lls += ll; lrs += lr
        throws += throw_table(L, g, stand, p)
        brs += [r for r, c in br]; bcs += [c for r, c in br]
        params += [p[k] for k in pkeys]
    for i, k in enumerate(pkeys): out.append(f"#define LP_{k.upper()} {i}")
    out.append(f"#define LP_COUNT {len(pkeys)}")
    for name, data, per in (("lvl_grid_all", grids, 32), ("lvl_rowidx_all", rows, 30), ("lvl_launch_l_all", lls, 32),
                            ("lvl_launch_r_all", lrs, 32), ("lvl_berry_row_all", brs, 10), ("lvl_berry_col_all", bcs, 10),
                            ("lvl_params_all", params, len(pkeys)), ("lvl_throw_all", throws, 40)):
        out.append(arr(name, data, per))
    out.append("// throw table layout: [level][tier 0-4][run 0/1][dir 0 right/1 left][40 words = 1257 half-pixel x bits]")
    out.append("#define THROW_WORDS 40")
    out.append("#endif")
    open(os.path.join(OUT, "levels.h"), "w").write("\n".join(out) + "\n")
    print("levels.h:", len(LEVELS), "boards, reachability proven:", ", ".join(L["name"] for L in LEVELS))
