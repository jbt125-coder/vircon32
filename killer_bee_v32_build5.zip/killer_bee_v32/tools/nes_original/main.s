; =====================================================================
;  KILLER BEE  -  an original 8-bit hive arena game for the NES
;  NROM-256 (mapper 0), 32 KB PRG + 8 KB CHR, ca65/ld65
; =====================================================================

PPUCTRL   = $2000
PPUMASK   = $2001
PPUSTATUS = $2002
OAMADDR   = $2003
PPUSCROLL = $2005
PPUADDR   = $2006
PPUDATA   = $2007
OAMDMA    = $4014
JOY1      = $4016
JOY2      = $4017

BTN_A      = $80
BTN_B      = $40
BTN_SELECT = $20
BTN_START  = $10
BTN_UP     = $08
BTN_DOWN   = $04
BTN_LEFT   = $02
BTN_RIGHT  = $01

ST_TITLE  = 0
ST_PLAY   = 1
ST_FREEZE = 2
ST_OVER   = 3
ST_PAUSE  = 4

WIN_MILITARY = 0
WIN_ECONOMY  = 1
WIN_SNAIL    = 2

ECON_GOAL    = 8
QUEEN_LIVES  = 3
SNAIL_START  = 120
SNAIL_BLUE_GOAL   = 224        ; blue escorts the snail right
SNAIL_YELLOW_GOAL = 16         ; yellow escorts it left
SNAIL_STEP   = 14              ; frames per pixel of snail travel
QUEEN_RESPAWN = 150
QUEEN_SHIELD  = 120
GROUND_Y_WORKER = 200
GROUND_Y_QUEEN  = 192

SFX_JUMP=0
SFX_FLAP=1
SFX_PICK=2
SFX_DEPOSIT=3
SFX_HITP=4
SFX_MENU=5
SFX_DASH=6
SFX_HIT=7
SFX_CLANK=8
SFX_ARM=9
SFX_YOYO=10

; ---------------------------------------------------------------------
.macpack longbranch

.segment "HEADER"
  .byte "NES", $1A
  .byte 2            ; 2 x 16 KB PRG ROM
  .byte 1            ; 1 x 8 KB CHR ROM
  .byte $01          ; mapper 0, vertical mirroring
  .byte $00          ; mapper 0
  .byte 0,0,0,0,0,0,0,0

; ---------------------------------------------------------------------
.segment "ZEROPAGE"
nmi_ready:   .res 1
nmi_count:   .res 1
ctrl_shadow: .res 1
mask_shadow: .res 1
pad1:        .res 1
pad2:        .res 1
pad1_old:    .res 1
pad2_old:    .res 1
pad1_new:    .res 1
pad2_new:    .res 1
t0: .res 1
t1: .res 1
t2: .res 1
t3: .res 1
t4: .res 1
t5: .res 1
t6: .res 1
t7: .res 1
k0: .res 1
k1: .res 1
ptr:  .res 2
sptr: .res 2
rng:  .res 2
rtmp: .res 1
pt:   .res 1
pt2:  .res 1
frame:       .res 1
game_state:  .res 1
state_timer: .res 1
num_players: .res 1
menu_sel:    .res 1
oam_idx:     .res 1
qhi:   .res 1
qlo:   .res 1
qsave: .res 1
ksave: .res 1
ph_h:  .res 1
ph_w:  .res 1
ph_g:  .res 1
ph_max: .res 1
maxx:  .res 1
speed: .res 1
feet:  .res 1
row:   .res 1
col:   .res 1
sp_x:  .res 1
sp_y:  .res 1
sp_t:  .res 1
sp_a:  .res 1
mx:    .res 1
my:    .res 1
mbase: .res 1
mattr: .res 1
dstart: .res 1
dcount: .res 1
oldy:  .res 1
oldx:  .res 1
pdir:  .res 1
prow_hi: .res 1
bnd:   .res 1
; entity arrays: 0 blue queen, 1 yellow queen, 2-3 blue workers, 4-5 yellow workers
ex:     .res 6
ey:     .res 6
eylo:   .res 6
evyh:   .res 6
evyl:   .res 6
eground: .res 6
eface:  .res 6      ; 0 = facing right, 1 = facing left
ealive: .res 6
etimer: .res 6      ; dead: respawn countdown, alive queen: invulnerability
ecarry: .res 6
eatk:   .res 6
ecool:  .res 6
edrop:  .res 6
eanim:  .res 6
einp:   .res 6
einpn:  .res 6
lives:   .res 2
berries: .res 2
ctrl_ent: .res 2
snail_x:     .res 1
snail_rider: .res 1
snail_timer: .res 1
snail_anim:  .res 1
winner:   .res 1
win_type: .res 1
fx_x: .res 1
fx_y: .res 1
fx_t: .res 1
ptr2: .res 2
cur_level: .res 1
snail_row: .res 1
snail_ry:  .res 1        ; rider y on the snail
eblock: .res 6           ; set when a wall stopped horizontal movement

.segment "BSS"
vq_len:   .res 1
vq_buf:   .res 60
berry_on:  .res 10
berry_tmr: .res 10
ai_lastx: .res 6
ai_stuck: .res 6
ai_alt:   .res 6
ai_altx:  .res 6
ai_jdir:  .res 6
ewarrior: .res 6         ; worker is armed with a yo-yo
espin:    .res 6         ; yo-yo spin frames left
eyx:      .res 6         ; yo-yo centre
eyy:      .res 6
aib:      .res 1         ; extra AI buttons
lvl_ram:  .res 768       ; per-level tables copied from ROM at match start
last_level: .res 1
force_level: .res 1      ; test hook: 0 = random, n = level n-1
cpu_both:    .res 1      ; test hook: 1 = blue is CPU-driven too
cur_song:  .res 1
song_cool: .res 1
mus_trans: .res 1
cur_duty:  .res 1
drum_vol:  .res 1
drum_per:  .res 1
drum_dec:  .res 1
ai_launch: .res 6
ai_lrow:  .res 6
ai_ltx:   .res 6
; audio
mus_lo:     .res 3
mus_hi:     .res 3
mus_looplo: .res 3
mus_loophi: .res 3
mus_timer:  .res 3
mus_active: .res 3
p1_env:     .res 1
snote:      .res 1
sfx_p_on:   .res 1
sfx_p_lo:   .res 1
sfx_p_hi:   .res 1
sfx_lasthi: .res 1
sfx_n_on:   .res 1
sfx_n_lo:   .res 1
sfx_n_hi:   .res 1
ssave:      .res 3

; ---------------------------------------------------------------------
.segment "CODE"

.include "build/charmap.inc"   ; ASCII -> tile mapping for strings

reset:
  sei
  cld
  ldx #$40
  stx $4017              ; disable APU frame IRQ
  ldx #$FF
  txs
  inx
  stx PPUCTRL            ; NMI off
  stx PPUMASK            ; rendering off
  stx $4010              ; DMC IRQ off
  bit PPUSTATUS
@vb1:
  bit PPUSTATUS
  bpl @vb1
  txa
@clr:
  sta $0000,x
  sta $0100,x
  sta $0300,x
  sta $0400,x
  sta $0500,x
  sta $0600,x
  sta $0700,x
  inx
  bne @clr
  jsr clear_oam
@vb2:
  bit PPUSTATUS
  bpl @vb2
  jsr load_palettes
  jsr sound_init
  lda #$A5
  sta rng
  lda #$3C
  sta rng+1
  lda #%10000000         ; NMI on, both pattern tables at $0000
  sta ctrl_shadow
  sta PPUCTRL
  lda #1
  sta num_players
  lda #$FF
  sta last_level
  sta cur_song
  jsr enter_title

main_loop:
  jsr read_pads
  jsr rand               ; keep the RNG churning (player timing = entropy)
  lda game_state
  cmp #ST_TITLE
  bne :+
  jsr title_update
  jmp @frame_done
: cmp #ST_PLAY
  bne :+
  jsr play_update
  jmp @frame_done
: cmp #ST_FREEZE
  bne :+
  jsr freeze_update
  jmp @frame_done
: cmp #ST_PAUSE
  bne :+
  jsr pause_update
  jmp @frame_done
: jsr over_update
@frame_done:
  jsr sound_update
  jsr wait_frame
  inc frame
  jmp main_loop

; ---------------------------------------------------------------------
; NMI: OAM DMA + VRAM queue + scroll, only when the main loop says so
nmi:
  pha
  txa
  pha
  tya
  pha
  lda nmi_ready
  beq @skip
  lda #0
  sta OAMADDR
  lda #$02
  sta OAMDMA
  ldy #0
@vq:
  cpy vq_len
  beq @vqdone
  lda vq_buf,y
  sta PPUADDR
  iny
  lda vq_buf,y
  sta PPUADDR
  iny
  lda vq_buf,y
  sta PPUDATA
  iny
  jmp @vq
@vqdone:
  lda #0
  sta vq_len
  sta PPUSCROLL
  sta PPUSCROLL
  lda ctrl_shadow
  sta PPUCTRL
  lda mask_shadow
  sta PPUMASK
  lda #0
  sta nmi_ready
@skip:
  inc nmi_count
  pla
  tay
  pla
  tax
  pla
irq:
  rti

wait_frame:
  lda #1
  sta nmi_ready
@w:
  lda nmi_ready
  bne @w
  rts

ppu_off:
  lda #0
  sta mask_shadow
  sta PPUMASK
  sta vq_len
  rts

ppu_on:
  lda #%00011110
  sta mask_shadow
  jsr wait_frame
  rts

clear_oam:
  lda #$FF
  ldx #0
@l:
  sta $0200,x
  inx
  bne @l
  rts

load_palettes:
  bit PPUSTATUS
  lda #$3F
  sta PPUADDR
  lda #$00
  sta PPUADDR
  ldx #0
@l:
  lda palettes,x
  sta PPUDATA
  inx
  cpx #32
  bne @l
  rts

; ptr -> 1024 bytes, copied to nametable 0 (rendering must be off)
load_nametable:
  bit PPUSTATUS
  lda #$20
  sta PPUADDR
  lda #$00
  sta PPUADDR
  ldx #4
  ldy #0
@l:
  lda (ptr),y
  sta PPUDATA
  iny
  bne @l
  inc ptr+1
  dex
  bne @l
  rts

; ptr -> .byte hi, lo, len, chars...   (rendering must be off)
write_str:
  bit PPUSTATUS
  ldy #0
  lda (ptr),y
  sta PPUADDR
  iny
  lda (ptr),y
  sta PPUADDR
  iny
  lda (ptr),y
  sta t0
@l:
  iny
  lda (ptr),y
  sta PPUDATA
  dec t0
  bne @l
  rts

read_pads:
  lda pad1
  sta pad1_old
  lda pad2
  sta pad2_old
  lda #1
  sta JOY1
  lsr a
  sta JOY1
  ldx #8
@l:
  lda JOY1
  and #3
  cmp #1
  rol pad1
  lda JOY2
  and #3
  cmp #1
  rol pad2
  dex
  bne @l
  lda pad1_old
  eor #$FF
  and pad1
  sta pad1_new
  lda pad2_old
  eor #$FF
  and pad2
  sta pad2_new
  rts

; 8-bit output LFSR, preserves X and Y
rand:
  lda #8
  sta rtmp
  lda rng
@l:
  asl a
  rol rng+1
  bcc :+
  eor #$39
: dec rtmp
  bne @l
  sta rng
  rts

; A = row, col = column  ->  qhi/qlo = nametable address
nt_addr:
  pha
  lsr a
  lsr a
  lsr a
  clc
  adc #$20
  sta qhi
  pla
  and #7
  asl a
  asl a
  asl a
  asl a
  asl a
  ora col
  sta qlo
  rts

; A = tile; queues a write to qhi/qlo for the next vblank. Preserves X, Y.
queue_tile:
  sty qsave
  ldy vq_len
  cpy #57
  bcs @full
  pha
  lda qhi
  sta vq_buf,y
  iny
  lda qlo
  sta vq_buf,y
  iny
  pla
  sta vq_buf,y
  iny
  sty vq_len
  ldy qsave
  rts
@full:
  ldy qsave
  rts

; =====================================================================
; TITLE
; =====================================================================
enter_title:
  jsr ppu_off
  lda #<title_nam
  sta ptr
  lda #>title_nam
  sta ptr+1
  jsr load_nametable
  jsr clear_oam
  lda #ST_TITLE
  sta game_state
  lda #0
  sta menu_sel
  lda #0
  jsr start_song
  jsr ppu_on
  rts

title_update:
  lda pad1_new
  and #(BTN_UP|BTN_DOWN|BTN_SELECT)
  beq @nomove
  lda menu_sel
  eor #1
  sta menu_sel
  lda #SFX_MENU
  jsr play_sfx
@nomove:
  lda pad1_new
  and #(BTN_START|BTN_A)
  beq @draw
  lda menu_sel
  clc
  adc #1
  sta num_players
  jsr start_match
  rts
@draw:
  lda #0
  sta oam_idx
  ; cursor
  lda menu_sel
  asl a
  asl a
  asl a
  asl a
  clc
  adc #127               ; row 16 -> y 128 (minus 1 for OAM)
  sta sp_y
  lda #$56
  sta sp_t
  lda #3
  sta sp_a
  lda #68
  sta sp_x
  jsr put_sprite
  ; two hovering queens
  lda frame
  lsr a
  lsr a
  and #15
  tax
  lda bob_tbl,x
  clc
  adc #52
  sta my
  lda #32
  sta mx
  lda frame
  and #8
  beq :+
  lda #4
: clc
  adc #$40
  sta mbase
  lda #0
  sta mattr
  jsr draw_meta16
  lda #208
  sta mx
  lda #$41
  sta mattr
  jsr draw_meta16
  jsr hide_rest
  rts

bob_tbl: .byte 0,1,2,3,4,4,5,5,5,5,4,4,3,2,1,0

; =====================================================================
; MATCH SETUP
; =====================================================================
start_match:
  jsr ppu_off
  jsr pick_level
  jsr load_level
  jsr load_nametable
  jsr clear_oam
  lda #QUEEN_LIVES
  sta lives
  sta lives+1
  lda #0
  sta berries
  sta berries+1
  sta snail_timer
  sta snail_anim
  sta fx_t
  sta ctrl_ent           ; blue controls queen 0
  lda #1
  sta ctrl_ent+1         ; yellow controls queen 1
  lda lv_snail_start
  sta snail_x
  lda lv_snail_y
  clc
  adc #8
  lsr a
  lsr a
  lsr a
  sta snail_row
  lda lv_snail_y
  sec
  sbc #8
  sta snail_ry
  lda #$FF
  sta snail_rider
  sta winner
  ldx #0
@b:
  lda #1
  sta berry_on,x
  lda #0
  sta berry_tmr,x
  inx
  cpx #NUM_BERRIES
  bne @b
  ldx #0
@e:
  jsr spawn_entity
  lda #$FF
  sta ai_lrow,x
  lda #0
  sta ai_alt,x
  sta ai_stuck,x
  inx
  cpx #6
  bne @e
  lda #ST_PLAY
  sta game_state
  lda #0
  sta song_cool
  jsr music_event        ; random song to open the match
  jsr ppu_on
  rts

; random level, never the same one twice in a row
pick_level:
  lda force_level
  beq @rand
  sec
  sbc #1
  jmp @set
@rand:
  jsr rand
@mod:
  cmp #NUM_LEVELS
  bcc @ok
  sbc #NUM_LEVELS
  jmp @mod
@ok:
  cmp last_level
  bne @set
  clc
  adc #1
  cmp #NUM_LEVELS
  bcc @set
  lda #0
@set:
  sta cur_level
  sta last_level
  rts

; copy the level's tables to RAM; leaves ptr -> its nametable
load_level:
  lda cur_level
  asl a
  tax
  lda level_blobs,x
  sta ptr
  lda level_blobs+1,x
  sta ptr+1
  lda #<lvl_ram
  sta ptr2
  lda #>lvl_ram
  sta ptr2+1
  ldx #LEVEL_BLOB_PAGES
  ldy #0
@c:
  lda (ptr),y
  sta (ptr2),y
  iny
  bne @c
  inc ptr+1
  inc ptr2+1
  dex
  bne @c
  lda cur_level
  asl a
  tax
  lda level_nams,x
  sta ptr
  lda level_nams+1,x
  sta ptr+1
  rts

; X = entity
spawn_entity:
  lda #1
  sta ealive,x
  lda spawn_x,x
  sta ex,x
  lda spawn_y,x
  sta ey,x
  lda spawn_face,x
  sta eface,x
  lda #0
  sta eylo,x
  sta evyh,x
  sta evyl,x
  sta eground,x
  sta ecarry,x
  sta eatk,x
  sta ecool,x
  sta edrop,x
  sta eanim,x
  sta einp,x
  sta einpn,x
  sta etimer,x
  sta ewarrior,x
  sta espin,x
  cpx #2
  bcs :+
  lda #QUEEN_SHIELD       ; queen spawn invulnerability
  sta etimer,x
: rts

spawn_x:    .byte 24, 216, 12, 20, 236, 228
spawn_y:    .byte 48, 48, 200, 200, 200, 200
spawn_face: .byte 0, 1, 0, 0, 1, 1
team_of:    .byte 0, 1, 0, 0, 1, 1
next_ent:   .byte 2, 4, 3, 0, 5, 1      ; SELECT cycles queen -> worker -> worker
enemies:    .byte 1, 4, 5, 0, 2, 3
mul3:       .byte 0, 3
home_x:     .byte 4, 244
guard_x:    .byte 40, 208
qhome_x:    .byte 40, 200
enemy_w1:   .byte 4, 2
enemy_w2:   .byte 5, 3
hunt_phase: .byte $00, $80   ; teams hunt in different quarter-cycles
guard_qx:   .byte 72, 168

; =====================================================================
; PLAY
; =====================================================================
play_update:
  lda pad1_new
  ora pad2_new
  and #BTN_START
  beq @nopause
  lda #ST_PAUSE
  sta game_state
  lda #SFX_MENU
  jsr play_sfx
  jsr draw_game
  rts
@nopause:
  lda song_cool
  beq :+
  dec song_cool
: jsr handle_select
  jsr gather_inputs
  ; update entities
  ldx #0
@u:
  lda ealive,x
  bne @alive
  lda etimer,x
  beq @nx
  dec etimer,x
  bne @nx
  jsr spawn_entity
  jmp @nx
@alive:
  cpx #2
  bcs @w
  jsr queen_update
  jmp @nx
@w:
  jsr worker_update
@nx:
  inx
  cpx #6
  bne @u
  jsr combat
  jsr snail_update
  jsr berry_update
  lda fx_t
  beq :+
  dec fx_t
: jsr draw_game
  rts

pause_update:
  lda pad1_new
  ora pad2_new
  and #BTN_START
  beq :+
  lda #ST_PLAY
  sta game_state
: jsr draw_game
  rts

freeze_update:
  lda fx_t
  beq :+
  dec fx_t
: jsr draw_game
  dec state_timer
  bne :+
  jsr enter_over
: rts

handle_select:
  lda pad1_new
  and #BTN_SELECT
  beq @p2
  ldy #0
  jsr cycle_ctrl
@p2:
  lda num_players
  cmp #2
  bne @r
  lda pad2_new
  and #BTN_SELECT
  beq @r
  ldy #1
  jsr cycle_ctrl
@r:
  rts

; Y = team
cycle_ctrl:
  ldx ctrl_ent,y
  lda #3
  sta t0
@try:
  lda next_ent,x
  tax
  lda ealive,x
  bne @found
  dec t0
  bne @try
  rts
@found:
  txa
  sta ctrl_ent,y
  lda #SFX_MENU
  jsr play_sfx
  rts

gather_inputs:
  ldx #0
@l:
  lda ealive,x
  beq @next
  ldy team_of,x
  bne :+
  lda cpu_both
  bne @ai
  beq @human             ; blue is human
:
  lda num_players
  cmp #2
  bne @ai
@human:
  stx t7
  lda ctrl_ent,y
  cmp t7
  bne @ai
  cpy #0
  bne @usep2
  lda pad1
  and #$CF
  sta einp,x
  lda pad1_new
  and #$CF
  sta einpn,x
  jmp @next
@usep2:
  lda pad2
  and #$CF
  sta einp,x
  lda pad2_new
  and #$CF
  sta einpn,x
  jmp @next
@ai:
  cpx #2
  bcs @aw
  jsr ai_queen
  jmp @st
@aw:
  jsr ai_worker
@st:
  lda t0
  sta einp,x
  lda t1
  sta einpn,x
@next:
  inx
  cpx #6
  bne @l
  rts

; ---------------------------------------------------------------------
; movement helpers (X = entity)
move_right:              ; A = pixels  (needs ph_w/ph_h set)
  pha
  lda ex,x
  sta oldx
  lda #0
  sta pdir
  pla
  clc
  adc ex,x
  bit lv_side            ; open sides: x simply wraps mod 256
  bmi @ok
  bcs @clamp
  cmp maxx
  bcc @ok
  beq @ok
@clamp:
  lda maxx
@ok:
  sta ex,x
  lda ex,x
  clc
  adc ph_w
  sec
  sbc #1
  lsr a
  lsr a
  lsr a
  sta col
  jsr wall_rows
  bcc @nw
  lda col
  asl a
  asl a
  asl a
  sec
  sbc ph_w
  sta ex,x
  lda #1
  sta eblock,x
@nw:
  jsr plat_side
  jmp shaft_clamp

move_left:
  sta pt
  lda ex,x
  sta oldx
  lda #1
  sta pdir
  lda ex,x
  sec
  sbc pt
  bit lv_side
  bmi @ok
  bcs @ok
  lda #0
@ok:
  sta ex,x
  lsr a
  lsr a
  lsr a
  sta col
  jsr wall_rows
  bcc @nw
  lda col
  clc
  adc #1
  asl a
  asl a
  asl a
  sta ex,x
  lda #1
  sta eblock,x
@nw:
  jsr plat_side
  jmp shaft_clamp

; Platform planks (top 4 px of a platform tile) are solid from the side as
; well: a bee moving sideways into one either steps up onto it (if its feet
; are within the plank) or is stopped. Prevents sliding into a plank and
; dropping out underneath it.
plat_side:
  lda pdir
  bne @lc
  lda ex,x
  clc
  adc ph_w
  sec
  sbc #1
  jmp @c
@lc:
  lda ex,x
@c:
  lsr a
  lsr a
  lsr a
  sta col
  lda ey,x               ; planks whose 4 px overlap the body rows
  clc
  adc #4
  lsr a
  lsr a
  lsr a
  sta row
  lda ey,x
  clc
  adc ph_h
  sec
  sbc #1
  lsr a
  lsr a
  lsr a
  sta prow_hi
@l:
  lda row
  cmp prow_hi
  beq :+
  bcs @clear
: jsr is_plat
  bne @hit
  inc row
  jmp @l
@clear:
  rts
@hit:
  lda row
  asl a
  asl a
  asl a
  sta pt2                ; plank top
  lda ey,x
  clc
  adc ph_h
  sec
  sbc pt2                ; how far the feet are below the plank top
  cmp #5
  bcs @block
  lda pt2                ; small step: land on top
  sec
  sbc ph_h
  sta ey,x
  lda #0
  sta eylo,x
  sta evyh,x
  sta evyl,x
  lda #1
  sta eground,x
  rts
@block:
  lda oldx
  sta ex,x
  lda #1
  sta eblock,x
  rts

; C=1 if a wall sits directly under the platform entity X stands on
wall_below:
  lda ey,x
  clc
  adc ph_h
  lsr a
  lsr a
  lsr a
  clc
  adc #1
  sta row
  lda ex,x
  clc
  adc #2
  lsr a
  lsr a
  lsr a
  sta col
  jsr is_wall
  bne @yes
  lda ex,x
  clc
  adc ph_w
  sec
  sbc #3
  lsr a
  lsr a
  lsr a
  sta col
  jsr is_wall
  bne @yes
  clc
  rts
@yes:
  sec
  rts

; C=1 if a wall tile in column `col` overlaps entity X's body rows
wall_rows:
  lda ey,x
  lsr a
  lsr a
  lsr a
  sta row
  lda ey,x
  clc
  adc ph_h
  sec
  sbc #1
  lsr a
  lsr a
  lsr a
  sta pt2
@l:
  jsr is_wall
  bne @yes
  lda row
  cmp pt2
  bcs @no
  inc row
  jmp @l
@yes:
  sec
  rts
@no:
  clc
  rts

is_wall:                 ; Z=0 if wall at (col,row). Preserves X.
  lda row
  cmp #30
  bcs @none
  asl a
  asl a
  sta pt
  lda col
  lsr a
  lsr a
  lsr a
  clc
  adc pt
  tay
  lda walls,y
  sta pt
  lda col
  and #7
  tay
  lda bitmask,y
  and pt
  rts
@none:
  lda #0
  rts

; inside the ceiling gap or the pit, bees are boxed into the shaft columns
shaft_clamp:
  lda lv_wrap
  beq @r
  lda ey,x
  cmp #40
  bcc @in
  clc
  adc ph_h
  cmp #209
  bcc @r
@in:
  lda ex,x
  cmp lv_sx0
  bcs :+
  lda lv_sx0
  sta ex,x
: lda lv_sx1
  sec
  sbc ph_w
  cmp ex,x
  bcs @r
  sta ex,x
@r:
  rts

; ---------------------------------------------------------------------
queen_update:
  lda #240
  sta maxx
  lda #16
  sta ph_h
  sta ph_w
  lda #0
  sta eblock,x
  lda ecool,x
  beq :+
  dec ecool,x
: lda etimer,x
  beq :+
  dec etimer,x
: lda eatk,x
  beq @normal
  ; stinger dash: fast, straight line, locked direction
  dec eatk,x
  lda eface,x
  bne @dl
  lda #3
  jsr move_right
  jmp @dashv
@dl:
  lda #3
  jsr move_left
@dashv:
  lda #0
  sta evyh,x
  sta evyl,x
  inc eanim,x
  rts
@normal:
  ldy #2
  lda eground,x
  beq :+
  ldy #1
: sty speed
  lda einp,x
  and #BTN_RIGHT
  beq @nr
  lda #0
  sta eface,x
  lda speed
  jsr move_right
@nr:
  lda einp,x
  and #BTN_LEFT
  beq @nl
  lda #1
  sta eface,x
  lda speed
  jsr move_left
@nl:
  lda einpn,x
  and #BTN_B
  beq @nb
  lda ecool,x
  bne @nb
  lda #14
  sta eatk,x
  lda #34
  sta ecool,x
  lda #SFX_DASH
  jsr play_sfx
@nb:
  lda einpn,x
  and #BTN_A
  beq @na
  lda eground,x
  beq @flap
  lda einp,x
  and #BTN_DOWN
  beq @flap
  lda ey,x
  cmp #GROUND_Y_QUEEN
  bcs @flap
  jsr wall_below
  bcs @na
  lda #16                ; drop through the platform
  sta edrop,x
  lda #0
  sta eground,x
  jmp @na
@flap:
  lda #$FD               ; vy = -3.0 px/frame
  sta evyh,x
  lda #0
  sta evyl,x
  sta eground,x
  lda #SFX_FLAP
  jsr play_sfx
@na:
  lda #16
  sta ph_h
  sta ph_w
  lda #$1C
  sta ph_g
  lda #2
  sta ph_max
  jsr phys_vertical
  inc eanim,x
  rts

; ---------------------------------------------------------------------
worker_update:
  cpx snail_rider
  bne @free
  lda einpn,x
  and #(BTN_A|BTN_B)
  beq @ret
  lda #$FF               ; hop off the snail
  sta snail_rider
  lda #$FD
  sta evyh,x
  lda #0
  sta evyl,x
  sta eground,x
  lda #SFX_JUMP
  jsr play_sfx
@ret:
  rts
@free:
  lda #248
  sta maxx
  lda #8
  sta ph_w
  sta ph_h
  lda #0
  sta eblock,x
  lda einp,x
  and #BTN_RIGHT
  beq @nr
  lda #0
  sta eface,x
  lda #1
  jsr move_right
  inc eanim,x
@nr:
  lda einp,x
  and #BTN_LEFT
  beq @nl
  lda #1
  sta eface,x
  lda #1
  jsr move_left
  inc eanim,x
@nl:
  lda einpn,x
  and #BTN_A
  beq @na
  lda eground,x
  beq @na
  lda einp,x
  and #BTN_DOWN
  beq @jump
  lda ey,x
  cmp #GROUND_Y_WORKER
  bcs @jump
  jsr wall_below
  bcs @na
  lda #16
  sta edrop,x
  lda #0
  sta eground,x
  jmp @na
@jump:
  lda #$FB               ; vy = -4.75 px/frame
  sta evyh,x
  lda #$40
  sta evyl,x
  lda #0
  sta eground,x
  lda #SFX_JUMP
  jsr play_sfx
@na:
  lda ecool,x
  beq :+
  dec ecool,x
: lda espin,x
  beq :+
  dec espin,x
: lda einpn,x
  and #BTN_B
  beq @nb
  lda ewarrior,x
  beq @mount
  lda ecool,x            ; armed: B spins the yo-yo (with a cooldown)
  bne @nb
  lda #24
  sta espin,x
  lda #90
  sta ecool,x
  lda #SFX_YOYO
  jsr play_sfx
  jmp @nb
@mount:
  lda snail_rider
  cmp #$FF
  bne @nb
  jsr touching_snail
  bcc @nb
  stx snail_rider
  lda #SFX_MENU
  jsr play_sfx
  rts
@nb:
  lda #8
  sta ph_h
  sta ph_w
  lda #$30
  sta ph_g
  lda #4
  sta ph_max
  jsr phys_vertical
  jsr worker_berries
  lda espin,x
  beq :+
  jsr yoyo_hit
: rts

; armed worker X is spinning: yo-yo orbits it and kills the enemy queen
yoyo_hit:
  lda espin,x
  lsr a
  tay
  lda ex,x
  clc
  adc #4
  clc
  adc yo_dx,y
  sta eyx,x
  lda ey,x
  clc
  adc #4
  clc
  adc yo_dy,y
  sta eyy,x
  lda team_of,x
  eor #1
  tay                    ; enemy queen index = enemy team
  lda ealive,y
  beq @r
  lda etimer,y
  bne @r
  lda ex,y
  clc
  adc #8
  sec
  sbc eyx,x
  jsr absdiff
  cmp #10
  bcs @r
  lda ey,y
  clc
  adc #8
  sec
  sbc eyy,x
  bcs :+
  eor #$FF
  adc #1
: cmp #10
  bcs @r
  jsr kill_entity
@r:
  rts

;            yo-yo orbit, radius 14, 12 steps
yo_dx: .byte 14, 12, 7, 0, <-7, <-12, <-14, <-12, <-7, 0, 7, 12
yo_dy: .byte 0, 7, 12, 14, 12, 7, 0, <-7, <-12, <-14, <-12, <-7

; C=1 if worker X overlaps the snail
touching_snail:
  lda ex,x
  sec
  sbc snail_x
  clc
  adc #7
  cmp #23
  bcs @no
  lda ey,x               ; worker height within the snail's band
  sec
  sbc lv_snail_y
  clc
  adc #9
  cmp #13
  bcs @no
  sec
  rts
@no:
  clc
  rts

; ---------------------------------------------------------------------
; vertical physics with one-way platforms. X = entity,
; ph_h/ph_w = size, ph_g = gravity (1/256 px), ph_max = max fall px
phys_vertical:
  lda eground,x
  beq @air
  lda ey,x
  clc
  adc ph_h
  lsr a
  lsr a
  lsr a
  sta row
  jsr check_under
  bcc :+
  jmp @done
: lda #0
  sta eground,x
@air:
  lda evyl,x
  clc
  adc ph_g
  sta evyl,x
  lda evyh,x
  adc #0
  sta evyh,x
  bmi @nocl
  cmp ph_max
  bcc @nocl
  lda ph_max
  sta evyh,x
  lda #0
  sta evyl,x
@nocl:
  lda ey,x
  sta oldy
  lda eylo,x
  clc
  adc evyl,x
  sta eylo,x
  lda ey,x
  adc evyh,x
  sta ey,x
  lda evyh,x
  bpl @nohead
  ; rising: platforms are solid from below. Their plank is the top 4 px
  ; of the tile, so the underside is at row*8+4. Did the head cross it?
  lda oldy
  sec
  sbc #4
  lsr a
  lsr a
  lsr a
  sta row
  asl a
  asl a
  asl a
  clc
  adc #4
  sta bnd
  lda ey,x
  cmp bnd
  bcs @nohead
  jsr check_under
  bcc @nohead
  lda bnd                ; bonk
  sta ey,x
  lda #0
  sta eylo,x
  sta evyh,x
  sta evyl,x
@nohead:
  lda lv_wrap            ; ceiling gap: fully inside the shaft columns?
  beq @ceil
  lda ex,x
  cmp lv_sx0
  bcc @ceil
  clc
  adc ph_w
  cmp lv_sx1
  beq :+
  bcs @ceil
: lda ey,x
  cmp #16
  bcs @nt
  clc                    ; out the top -> up out of the pit
  adc #200
  sta ey,x
  jmp @nt
@ceil:
  lda ey,x
  cmp #40                ; ceiling under the HUD
  bcs @nt
  lda #40
  sta ey,x
  lda #0
  sta evyh,x
  sta evyl,x
@nt:
  lda lv_wrap            ; down the pit -> drop in from the top
  beq @nobot
  lda ey,x
  cmp #216
  bcc @nobot
  sec
  sbc #200
  sta ey,x
@nobot:
  lda evyh,x
  bmi @done
  lda edrop,x
  bne @done
  lda ey,x
  clc
  adc ph_h
  sta feet
  and #7
  sta pt2
  lda evyh,x
  cmp pt2
  bcc @done              ; did not cross a tile top this frame
  lda feet
  lsr a
  lsr a
  lsr a
  sta row
  jsr check_under
  bcc @done
  lda row                ; land
  asl a
  asl a
  asl a
  sec
  sbc ph_h
  sta ey,x
  lda #0
  sta eylo,x
  sta evyh,x
  sta evyl,x
  lda #1
  sta eground,x
@done:
  lda edrop,x
  beq :+
  dec edrop,x
: rts

; C=1 if a platform is under entity X at tile row `row`
check_under:
  lda ex,x
  clc
  adc #2
  lsr a
  lsr a
  lsr a
  sta col
  jsr is_plat
  bne @yes
  lda ex,x
  clc
  adc ph_w
  sec
  sbc #3
  lsr a
  lsr a
  lsr a
  sta col
  jsr is_plat
  bne @yes
  clc
  rts
@yes:
  sec
  rts

; Z=0 if tile (col,row) is a platform. Preserves X.
is_plat:
  lda row
  cmp #30
  bcs @solid
  asl a
  asl a
  sta pt
  lda col
  lsr a
  lsr a
  lsr a
  clc
  adc pt
  tay
  lda collide,y
  sta pt
  lda col
  and #7
  tay
  lda bitmask,y
  and pt
  rts
@solid:
  lda #1
  rts

bitmask: .byte $80,$40,$20,$10,$08,$04,$02,$01

; ---------------------------------------------------------------------
; berries: pickup and deposit for worker X
worker_berries:
  lda ewarrior,x
  beq :+
  rts
: lda ecarry,x
  bne @deposit
  ldy #0
@l:
  lda berry_on,y
  beq @n
  lda ex,x
  sec
  sbc berry_px,y
  clc
  adc #6
  cmp #13
  bcs @n
  lda ey,x
  sec
  sbc berry_py,y
  clc
  adc #6
  cmp #13
  bcs @n
  lda #0
  sta berry_on,y
  jsr rand
  and #63
  clc
  adc #180
  sta berry_tmr,y
  lda #1
  sta ecarry,x
  lda berry_col,y
  sta col
  lda berry_row,y
  jsr nt_addr
  lda #0
  jsr queue_tile
  lda #SFX_PICK
  jsr play_sfx
  rts
@n:
  iny
  cpy #NUM_BERRIES
  bne @l
  rts
@deposit:
  jsr try_arm
  bcc :+
  rts
: lda ey,x
  cmp #184
  bcc @r
  lda team_of,x
  bne @yel
  lda ex,x
  cmp #12
  bcs @r
  jmp @dep
@yel:
  lda ex,x
  cmp #236
  bcc @r
@dep:
  lda #0
  sta ecarry,x
  ldy team_of,x
  lda berries,y
  clc
  adc #1
  sta berries,y
  ; light up the next meter cell
  cpy #0
  bne :+
  sta col                ; blue: column = count
  jmp :++
: sta pt                 ; yellow: column = 31 - count
  lda #31
  sec
  sbc pt
  sta col
: lda #3
  jsr nt_addr
  lda #$0A
  jsr queue_tile
  lda #SFX_DEPOSIT
  jsr play_sfx
  ldy team_of,x
  lda berries,y
  cmp #6
  bne :+
  jsr music_event        ; a hive is nearly full
: lda berries,y
  cmp #ECON_GOAL
  bcc @r
  lda #WIN_ECONOMY
  sta k1
  tya
  jsr declare_win
@r:
  rts

; carrying worker X touching its team's weapon box: berry -> yo-yo
try_arm:
  lda lv_boxes
  beq @no
  ldy team_of,x
  lda ex,x
  sec
  sbc lv_boxx,y
  clc
  adc #7
  cmp #23
  bcs @no
  lda ey,x
  sec
  sbc lv_boxy
  clc
  adc #7
  cmp #23
  bcs @no
  txa                    ; teammate is X xor 1 (2<->3, 4<->5)
  eor #1
  tay
  lda ealive,y
  beq :+
  lda ewarrior,y
  bne @no                ; one armed worker per team
: lda #0
  sta ecarry,x
  sta ecool,x
  lda #1
  sta ewarrior,x
  lda #SFX_ARM
  jsr play_sfx
  jsr music_event
  sec
  rts
@no:
  clc
  rts

berry_update:
  lda frame
  and #3
  beq :+
  rts
: ldy #0
@l:
  lda berry_on,y
  bne @n
  lda berry_tmr,y
  sec
  sbc #1
  sta berry_tmr,y
  bne @n
  lda #1
  sta berry_on,y
  lda berry_col,y
  sta col
  lda berry_row,y
  jsr nt_addr
  lda #$08
  jsr queue_tile
@n:
  iny
  cpy #NUM_BERRIES
  bne @l
  rts

; ---------------------------------------------------------------------
snail_update:
  ldx snail_rider
  cpx #$FF
  beq @r
  lda ealive,x
  bne @ok
  lda #$FF
  sta snail_rider
@r:
  rts
@ok:
  inc snail_timer
  lda snail_timer
  cmp #SNAIL_STEP
  bcc @lock
  lda #0
  sta snail_timer
  inc snail_anim
  lda team_of,x
  bne @left
  inc snail_x
  lda lv_goal_r
  sec
  sbc #24
  cmp snail_x
  bne :+
  jsr music_event        ; snail closing in on yellow's end
: lda snail_x
  cmp lv_goal_r
  bcc @lock
  lda #WIN_SNAIL
  sta k1
  lda #0
  jsr declare_win
  jmp @lock
@left:
  dec snail_x
  lda lv_goal_l
  clc
  adc #24
  cmp snail_x
  bne :+
  jsr music_event
: lda lv_goal_l
  cmp snail_x
  bcc @lock
  lda #WIN_SNAIL
  sta k1
  lda #1
  jsr declare_win
@lock:
  lda snail_x
  clc
  adc #4
  sta ex,x
  lda snail_ry
  sta ey,x
  lda #0
  sta evyh,x
  sta evyl,x
  sta eylo,x
  lda #1
  sta eground,x
  rts

; A = winning team, k1 = victory type. Preserves X, Y.
declare_win:
  pha
  lda winner
  cmp #$FF
  beq :+
  pla
  rts
: pla
  sta winner
  lda k1
  sta win_type
  lda #ST_FREEZE
  sta game_state
  lda #100
  sta state_timer
  jsr play_win_music
  rts

; ---------------------------------------------------------------------
; queen stinger attacks
combat:
  ldx #0
  jsr queen_attack
  ldx #1
  jsr queen_attack
  rts

queen_attack:
  lda ealive,x
  bne :+
  rts
: lda eatk,x
  cmp #1                 ; not dashing
  bcs :+
  rts
: cmp #13                ; first 2 frames are wind-up: stinger not live yet
  bcc :+
  rts
:
  lda ex,x
  clc
  adc #8
  sta t0
  lda ey,x
  clc
  adc #8
  sta t1
  lda mul3,x
  sta t7
  lda #3
  sta t6
@loop:
  ldy t7
  lda enemies,y
  tay
  lda ealive,y
  bne :+
  jmp @next
: cpy #2
  bcs @wk
  lda etimer,y           ; invulnerable queen
  beq :+
  jmp @next
:
  lda ex,y
  clc
  adc #8
  sta t2
  lda ey,y
  clc
  adc #8
  sta t3
  lda #20
  sta t4
  lda #14
  sta t5
  jmp @test
@wk:
  lda ex,y
  clc
  adc #4
  sta t2
  lda ey,y
  clc
  adc #4
  sta t3
  lda #17
  sta t4
  lda #12
  sta t5
@test:
  ; must be in front of the stinger (small grace behind)
  bit lv_side
  bpl @linear
  lda t2                 ; open sides: signed distance across the seam
  sec
  sbc t0
  sta k0
  lda eface,x
  bne @wl
  lda k0
  clc
  adc #4
  jmi @next
  jmp @dist
@wl:
  lda #4
  sec
  sbc k0
  jmi @next
  jmp @dist
@linear:
  lda eface,x
  bne @fl
  lda t2
  clc
  adc #4
  cmp t0
  bcc @next
  jmp @dist
@fl:
  lda t0
  clc
  adc #4
  cmp t2
  bcc @next
@dist:
  lda t2
  sec
  sbc t0
  jsr absdiff
  cmp t4
  bcs @next
  lda t3
  sec
  sbc t1
  bcs :+
  eor #$FF
  adc #1
: cmp t5
  bcs @next
  cpy #2
  bcs @kill
  lda eatk,y             ; both queens stinging: clash, no damage
  beq @kill
  jsr clash
  rts
@kill:
  jsr kill_entity
@next:
  inc t7
  dec t6
  beq @r
  jmp @loop
@r:
  rts

; X, Y = the two queens
clash:
  lda #0
  sta eatk,x
  sta eatk,y
  lda #$FD
  sta evyh,x
  sta evyh,y
  lda #0
  sta evyl,x
  sta evyl,y
  sta eground,x
  sta eground,y
  lda #240
  sta maxx
  lda #16
  sta ph_w
  sta ph_h
  lda ex,x
  sta fx_x
  lda ey,x
  sta fx_y
  lda #10
  sta fx_t
  sty ksave
  lda ex,x
  cmp ex,y
  bcc @xleft
  lda #14
  jsr move_right
  ldx ksave
  lda #14
  jsr move_left
  jmp @done
@xleft:
  lda #14
  jsr move_left
  ldx ksave
  lda #14
  jsr move_right
@done:
  ldx #0                 ; restore (only called with queens 0/1)
  lda #SFX_CLANK
  jsr play_sfx
  rts

; A = a-b with C from the SBC -> |a-b|; across the seam on open-sided
; boards. Preserves X, Y.
absdiff:
  bit lv_side
  bmi @wrap
  bcs @r
  eor #$FF
  adc #1
@r:
  rts
@wrap:
  cmp #$80
  bcc @r
  eor #$FF
  clc
  adc #1
  rts

; |A| treating A as a signed difference. Preserves X, Y.
absdiff_s:
  cmp #$80
  bcc :+
  eor #$FF
  clc
  adc #1
: rts

; Y = victim. Preserves X.
kill_entity:
  stx ksave
  tya
  tax
  lda ex,x
  sta fx_x
  lda ey,x
  sta fx_y
  lda #12
  sta fx_t
  lda #SFX_HIT
  jsr play_sfx
  lda #SFX_HITP
  jsr play_sfx
  cpx #2
  bcs @worker
  ; queen loses a life
  dec lives,x
  lda lives,x
  cpx #0
  bne :+
  clc                    ; blue crowns: column 1 + lives
  adc #1
  sta col
  jmp :++
: sta pt                 ; yellow crowns: column 30 - lives
  lda #30
  sec
  sbc pt
  sta col
: lda #4
  jsr nt_addr
  lda #0
  jsr queue_tile
  lda #0
  sta ealive,x
  sta eatk,x
  lda #QUEEN_RESPAWN
  sta etimer,x
  jsr music_event
  lda lives,x
  bne @out
  lda #WIN_MILITARY
  sta k1
  txa
  eor #1
  jsr declare_win
  jmp @out
@worker:
  lda #0
  sta ealive,x
  sta ecarry,x
  lda #150
  sta etimer,x
  cpx snail_rider
  bne :+
  lda #$FF
  sta snail_rider
: ldy team_of,x          ; controlled worker died -> back to the queen
  stx k0
  lda ctrl_ent,y
  cmp k0
  bne @out
  tya
  sta ctrl_ent,y
@out:
  ldx ksave
  rts

; =====================================================================
; AI  (writes virtual buttons to t0 = held, t1 = new presses; X preserved)
; =====================================================================
hold_toward_t2:
  lda ex,x
  cmp t2
  beq @r
  bcs @ge
  lda t2
  sec
  sbc ex,x
  cmp #2
  bcc @r
  lda t0
  ora #BTN_RIGHT
  sta t0
  rts
@ge:
  sec
  sbc t2
  cmp #2
  bcc @r
  lda t0
  ora #BTN_LEFT
  sta t0
@r:
  rts

ai_worker:
  lda #0
  sta t0
  sta t1
  sta t4
  sta aib
  cpx snail_rider
  jne @free
  rts                    ; ride it home
@free:
  lda ewarrior,x
  jeq @unarmed
  ; armed: hunt the enemy queen and spin when she's close
  lda team_of,x
  eor #1
  tay
  lda ealive,y
  jeq @guard
  lda ex,y
  clc
  adc #4
  sta t2
  lda ey,y
  clc
  adc #16
  lsr a
  lsr a
  lsr a
  cmp #27
  bcc :+
  lda #26
: sta t3
  lda ecool,x
  jne @move
  lda ex,y
  clc
  adc #8
  sec
  sbc ex,x
  sec
  sbc #4
  jsr absdiff_s
  cmp #20
  jcs @move
  lda ey,y
  clc
  adc #8
  sec
  sbc ey,x
  sec
  sbc #4
  jsr absdiff_s
  cmp #20
  jcs @move
  lda #BTN_B
  sta aib
  jmp @move
@guard:
  ldy team_of,x
  lda guard_x,y
  sta t2
  lda #26
  sta t3
  jmp @move
@unarmed:
  lda ai_alt,x
  jeq @noalt
  dec ai_alt,x
  lda ai_altx,x
  sta t2
  lda #26
  sta t3
  jmp @move
@noalt:
  lda ecarry,x
  jeq @nocarry
  ldy team_of,x
  lda lv_boxes           ; weapon board: arm up if the team has no yo-yo yet
  beq @home
  txa
  eor #1
  tay
  lda ewarrior,y
  bne @home
  ldy team_of,x
  lda lv_boxx,y
  sta t2
  lda lv_boxrow
  sta t3
  jmp @move
@home:
  ldy team_of,x
  lda home_x,y
  sta t2
  lda #26
  sta t3
  jmp @move
@nocarry:
  cpx #3
  jeq @pref
  cpx #5
  jne @berry
@pref:
  lda snail_rider
  cmp #$FF
  jne @berry
@snailtgt:
  lda snail_x
  clc
  adc #4
  sta t2
  lda snail_row
  sta t3
  lda #1
  sta t4
  jmp @move
@berry:
  jsr find_berry
  jcc @nob
  lda berry_px,y
  sta t2
  lda berry_row,y
  clc
  adc #1
  sta t3
  jmp @move
@nob:
  lda snail_rider
  cmp #$FF
  jeq @snailtgt
  ldy team_of,x
  lda guard_x,y
  sta t2
  lda #26
  sta t3
@move:
  lda eground,x
  jne @onground
  lda evyh,x             ; rising: go straight up, steer after the apex
  bpl :+
  jmp @out
: lda ai_jdir,x          ; edge hop: drift onto the platform
  beq :+
  ora t0
  sta t0
  jmp @out
: jsr hold_toward_t2
  jmp @out
@onground:
  lda #0
  sta ai_jdir,x
  lda ey,x
  clc
  adc #8
  lsr a
  lsr a
  lsr a
  sta t5                 ; standing row
  lda t3
  cmp t5
  jeq @same
  jcc @up
  ; target is lower
  lda ex,x
  sec
  sbc t2
  bcs :+
  eor #$FF
  adc #1
: cmp #7
  bcc @dropit
  lda eblock,x           ; a wall is in the way: go down instead
  jeq @walk_near
@dropit:
  lda t5
  cmp #26
  jcs @walk_near
  lda #(BTN_DOWN|BTN_A)
  sta t0
  lda #BTN_A
  sta t1
  jmp @out
@walk_near:
  jmp @walk
@up:
  ; commit to one launch point while the tier and target stay the same
  lda t5
  cmp ai_lrow,x
  jne @recalc
  lda t2
  cmp ai_ltx,x
  jne @recalc
  lda ai_launch,x
  jmp @have
@recalc:
  jsr lookup_launch
  sta ai_launch,x
  lda t5
  sta ai_lrow,x
  lda t2
  sta ai_ltx,x
  lda ai_launch,x
@have:
  cmp #$FF
  jeq @walk
  sta t6
  and #$3F
  asl a
  asl a
  asl a
  sta t2                 ; launch x (exact column, so the head clears)
  lda ex,x
  sec
  sbc t2
  bcs :+
  eor #$FF
  adc #1
: cmp #2
  jcs @golaunch
  lda #BTN_RIGHT
  bit t6
  bvc :+
  lda #BTN_LEFT
: sta ai_jdir,x
  lda #BTN_A
  sta t0
  sta t1
  jmp @out
@golaunch:
  jsr hold_toward_t2
  jmp @stuck
@same:
  lda eblock,x           ; same level but a wall in the way: go down and under
  beq :+
  lda t5
  cmp #26
  bcs :+
  lda #(BTN_DOWN|BTN_A)
  sta t0
  lda #BTN_A
  sta t1
  jmp @out
: lda t4
  jeq @walk
  jsr touching_snail
  jcc @walk
  lda #BTN_B
  sta t0
  sta t1
  jmp @out
@walk:
  jsr hold_toward_t2
@stuck:
  lda ex,x
  cmp ai_lastx,x
  jne @moved
  inc ai_stuck,x
  lda ai_stuck,x
  cmp #90
  jcc @out
  lda #0
  sta ai_stuck,x
  jsr rand
  and #$7F
  clc
  adc #64
  sta ai_altx,x
  lda #70
  sta ai_alt,x
  jmp @out
@moved:
  lda #0
  sta ai_stuck,x
@out:
  lda t0
  ora aib
  sta t0
  lda t1
  ora aib
  sta t1
  lda ex,x
  sta ai_lastx,x
  rts

; nearest berry to worker X -> C=1, Y = index
find_berry:
  lda #$FF
  sta t6
  sta t7
  ldy #0
@l:
  lda berry_on,y
  beq @n
  lda berry_px,y
  sec
  sbc ex,x
  bcs :+
  eor #$FF
  adc #1
: lsr a
  sta t5
  lda berry_py,y
  sec
  sbc ey,x
  bcs :+
  eor #$FF
  adc #1
: lsr a
  clc
  adc t5
  cmp t6
  bcs @n
  sta t6
  sty t7
@n:
  iny
  cpy #NUM_BERRIES
  bne @l
  ldy t7
  cpy #$FF
  beq @none
  sec
  rts
@none:
  clc
  rts

; launch column for worker X standing on row t5 heading to x = t2
lookup_launch:
  ldy t5
  lda rowidx,y
  cmp #$FF
  beq @ret
  asl a
  asl a
  asl a
  asl a
  asl a
  sta t7
  lda ex,x
  clc
  adc #4
  lsr a
  lsr a
  lsr a
  clc
  adc t7
  tay
  lda t2
  cmp ex,x
  bcc @leftfirst
  lda launch_r,y
  cmp #$FF
  bne @ret
  lda launch_l,y
  rts
@leftfirst:
  lda launch_l,y
  cmp #$FF
  bne @ret
  lda launch_r,y
@ret:
  rts

ai_queen:
  lda #0
  sta t0
  sta t1
  stx t7
  jsr ai_react
  bcc :+
  rts
: jsr ai_avoid_yoyo
  bcc :+
  rts
:
  ; 1) enemy snail rider
  ldy snail_rider
  cpy #$FF
  beq @carriers
  lda team_of,y
  cmp t7
  beq @carriers
  jmp @tworker
@carriers:
  ; 2) armed enemy worker, but only while its yo-yo is recharging
  ldy enemy_w1,x
  jsr armed_open
  bcs @tworker2
  ldy enemy_w2,x
  jsr armed_open
  bcs @tworker2
 ; 3) enemy worker carrying a berry
  ldy enemy_w1,x
  lda ealive,y
  beq :+
  lda ecarry,y
  bne @tworker
: ldy enemy_w2,x
  lda ealive,y
  beq :+
  lda ecarry,y
  bne @tworker
: ; 3) enemy queen -- but only in "hunt" phases; otherwise guard
  lda frame
  clc
  adc hunt_phase,x
  and #$C0
  bne @guard
  txa
  eor #1
  tay
  lda ealive,y
  beq @home
  lda ex,y
  clc
  adc #8
  sta t2
  lda ey,y
  clc
  adc #8
  sta t3
  jmp @go
@tworker2:
@tworker:
  lda ex,y
  clc
  adc #4
  sta t2
  lda ey,y
  clc
  adc #4
  sta t3
  jmp @go
@home:
  lda qhome_x,x
  sta t2
  lda #120
  sta t3
  jmp @go
@guard:
  ; defend: if the enemy queen comes close, turn and fight
  txa
  eor #1
  tay
  lda ealive,y
  beq @post
  lda ex,y
  sec
  sbc ex,x
  bcs :+
  eor #$FF
  adc #1
: cmp #44
  bcs @post
  lda ey,y
  sec
  sbc ey,x
  bcs :+
  eor #$FF
  adc #1
: cmp #36
  bcs @post
  lda ex,y
  clc
  adc #8
  sta t2
  lda ey,y
  clc
  adc #8
  sta t3
  jmp @go
@post:
  ; hover above our own worker lane
  lda guard_qx,x
  sta t2
  lda #96
  sta t3
@go:
  lda ai_alt,x           ; detouring under a wall: stay low
  beq :+
  dec ai_alt,x
  lda #192
  sta t3
: lda ex,x
  clc
  adc #8
  sta t4
  lda ey,x
  clc
  adc #8
  sta t5
  lda t2
  cmp t4
  bcc @tl
  sec
  sbc t4
  cmp #14
  bcc @faceR
  lda #BTN_RIGHT
  sta t0
  jmp @vert
@faceR:
  lda eface,x
  beq @vert
  lda #BTN_RIGHT
  sta t0
  jmp @vert
@tl:
  lda t4
  sec
  sbc t2
  cmp #14
  bcc @faceL
  lda #BTN_LEFT
  sta t0
  jmp @vert
@faceL:
  lda eface,x
  bne @vert
  lda #BTN_LEFT
  sta t0
@vert:
  ; standing on a platform with the target well below: drop through
  lda eground,x
  beq @notdrop
  lda ey,x
  cmp #GROUND_Y_QUEEN
  bcs @notdrop
  lda t5
  clc
  adc #20
  cmp t3
  bcs @notdrop
  lda #(BTN_DOWN|BTN_A)
  sta t0
  lda #BTN_A
  sta t1
  rts
@notdrop:
  lda eblock,x           ; bumped a wall: climb over it
  beq :+
  lda lv_boxes           ; (on the divide board, go under it instead)
  beq @over
  lda #60
  sta ai_alt,x
  jmp :+
@over:
  lda evyh,x
  bmi :+
  lda t0
  ora #BTN_A
  sta t0
  lda #BTN_A
  sta t1
: lda t3
  clc
  adc #2
  cmp t5
  bcs @noflap
  jsr queen_overhead     ; platform above? slide toward its nearest edge
  lda evyh,x
  bmi @noflap
  lda t0
  ora #BTN_A
  sta t0
  lda #BTN_A
  sta t1
@noflap:
  lda ecool,x
  bne @out
  lda t2
  sec
  sbc t4
  bcs :+
  eor #$FF
  adc #1
: cmp #40                ; start the dash from a readable distance
  bcs @out
  lda t3
  sec
  sbc t5
  bcs :+
  eor #$FF
  adc #1
: cmp #12
  bcs @out
  lda t2
  cmp t4
  bcc @tleft
  lda eface,x
  bne @out
  jmp @atk
@tleft:
  lda eface,x
  beq @out
@atk:
  jsr rand               ; reaction delay so the CPU is beatable
  and #7
  bne @out
  lda t0
  ora #BTN_B
  sta t0
  lda t1
  ora #BTN_B
  sta t1
@out:
  rts

; Queen X wants to climb: if a platform is within 4 rows overhead, replace
; the horizontal input in t0 with a move toward the nearer open edge.
queen_overhead:
  lda #16
  sta ph_w
  lda ey,x
  lsr a
  lsr a
  lsr a
  sta row
  lda #4
  sta k1
@scan:
  jsr check_under
  bcs @blocked
  dec row
  dec k1
  bne @scan
  rts
@blocked:
  lda ex,x
  clc
  adc #2
  lsr a
  lsr a
  lsr a
  sta col
  jsr is_plat
  php
  lda ex,x
  clc
  adc #13
  lsr a
  lsr a
  lsr a
  sta col
  jsr is_plat
  beq @ronly_clear       ; right point clear
  plp
  beq @goleft            ; left clear, right blocked
  ; both blocked: scan for the nearer edge
  lda ex,x
  clc
  adc #8
  lsr a
  lsr a
  lsr a
  sta t6
  sta col
  lda #0
  sta k0
@ls:
  jsr is_plat
  beq @lsd
  inc k0
  lda col
  beq @lsinv
  dec col
  jmp @ls
@lsinv:
  lda #$FF
  sta k0
@lsd:
  lda t6
  sta col
  lda #0
  sta k1
@rs:
  jsr is_plat
  beq @rsd
  inc k1
  lda col
  cmp #31
  beq @rsinv
  inc col
  jmp @rs
@rsinv:
  lda #$FF
  sta k1
@rsd:
  lda k0
  cmp k1
  bcc @goleft
  jmp @goright
@ronly_clear:
  plp
  bne @goright           ; left blocked, right clear
  rts
@goleft:
  lda t0
  and #<~(BTN_LEFT|BTN_RIGHT)
  ora #BTN_LEFT
  sta t0
  rts
@goright:
  lda t0
  and #<~(BTN_LEFT|BTN_RIGHT)
  ora #BTN_RIGHT
  sta t0
  rts

; C=1 if worker Y is armed, alive, and its yo-yo is recharging
armed_open:
  lda ealive,y
  beq @no
  lda ewarrior,y
  beq @no
  lda espin,y
  bne @no
  lda ecool,y
  beq @no
  sec
  rts
@no:
  clc
  rts

; Keep clear of an armed enemy worker whose yo-yo is spinning or ready.
; C=1 if fleeing (t0/t1 set).
ai_avoid_yoyo:
  ldy enemy_w1,x
  jsr @one
  bcs @r
  ldy enemy_w2,x
  jsr @one
@r:
  rts
@one:
  lda ealive,y
  beq @no
  lda ewarrior,y
  beq @no
  lda espin,y
  bne @danger
  lda ecool,y
  bne @no
@danger:
  lda ex,y
  sec
  sbc ex,x
  sec
  sbc #4
  jsr absdiff_s
  cmp #40
  bcs @no
  lda ey,y
  sec
  sbc ey,x
  sec
  sbc #4
  jsr absdiff_s
  cmp #40
  bcs @no
  lda ex,y               ; move away horizontally (unless a wall is there)
  cmp ex,x
  lda #BTN_LEFT
  bcs :+
  lda #BTN_RIGHT
: ldy eblock,x
  beq :+
  eor #(BTN_LEFT|BTN_RIGHT)
: sta t0
  txa                    ; restore Y = the threat
  pha
  ldy enemy_w1,x
  lda espin,y
  ora ecool,y
  bne :+
  ldy enemy_w2,x
: pla
  tax
  lda ey,y               ; worker below us: climb; above us: drop away
  cmp ey,x
  bcc @nf
  lda evyh,x
  bmi @nf
  lda t0
  ora #BTN_A
  sta t0
  lda #BTN_A
  sta t1
@nf:
  sec
  rts
@no:
  clc
  rts

; Incoming stinger? counter-sting (clash) or flap clear. C=1 if reacted.
ai_react:
  txa
  eor #1
  tay
  lda ealive,y
  beq @no
  lda eatk,y
  beq @no
  lda ey,y
  sec
  sbc ey,x
  bcs :+
  eor #$FF
  adc #1
: cmp #20
  bcs @no
  lda ex,y               ; attacker must be heading toward us
  cmp ex,x
  bcs @fromright
  lda eface,y
  bne @no
  lda ex,x
  sec
  sbc ex,y
  cmp #52
  bcs @no
  lda #BTN_LEFT          ; face the attacker
  jmp @act
@fromright:
  lda eface,y
  beq @no
  lda ex,y
  sec
  sbc ex,x
  cmp #52
  bcs @no
  lda #BTN_RIGHT
@act:
  sta t0
  jsr rand
  and #3
  beq @no                ; 1 in 4: froze up
  cmp #1
  beq @dodge
  lda ecool,x
  bne @dodge
  lda t0
  ora #BTN_B
  sta t0
  sta t1
  sec
  rts
@dodge:
  lda #BTN_A
  sta t1
  ora t0
  sta t0
  sec
  rts
@no:
  clc
  rts

; =====================================================================
; RENDERING
; =====================================================================
put_sprite:
  ldy oam_idx
  lda sp_y
  sta $0200,y
  iny
  lda sp_t
  sta $0200,y
  iny
  lda sp_a
  sta $0200,y
  iny
  lda sp_x
  sta $0200,y
  iny
  sty oam_idx
  rts

hide_rest:
  ldy oam_idx
  beq @r
  lda #$FF
@l:
  sta $0200,y
  iny
  iny
  iny
  iny
  bne @l
@r:
  rts

; 16x16 metasprite at mx,my with tiles mbase..+3, attr mattr ($40 = flip)
draw_meta16:
  lda mattr
  sta sp_a
  lda my
  sec
  sbc #1
  sta sp_y
  lda mattr
  and #$40
  beq @nf
  ldy #1
  bne @go
@nf:
  ldy #0
@go:
  sty pt2                ; 0 normal, 1 mirrored
  lda mx
  sta sp_x
  lda mbase
  clc
  adc pt2
  sta sp_t
  jsr put_sprite
  lda mx
  clc
  adc #8
  sta sp_x
  lda mbase
  clc
  adc #1
  sec
  sbc pt2
  sta sp_t
  jsr put_sprite
  lda sp_y
  clc
  adc #8
  sta sp_y
  lda mx
  sta sp_x
  lda mbase
  clc
  adc #2
  adc pt2
  sta sp_t
  jsr put_sprite
  lda mx
  clc
  adc #8
  sta sp_x
  lda mbase
  clc
  adc #3
  sec
  sbc pt2
  sta sp_t
  jsr put_sprite
  rts

; Objects are drawn in a rotating order each frame, so if more than
; eight sprites share a scanline the dropped one changes every frame
; (flicker) instead of an object vanishing permanently.
draw_game:
  lda #0
  sta oam_idx
  lda frame
  and #7
  sta dstart
  lda #8
  sta dcount
@l:
  lda dstart
  and #7
  cmp #6
  bcc @ent
  beq @snail
  jsr draw_fx
  jmp @n
@snail:
  jsr draw_snail
  jmp @n
@ent:
  tax
  jsr draw_entity
@n:
  inc dstart
  dec dcount
  bne @l
  jsr hide_rest
  rts

draw_entity:
  lda ealive,x
  bne :+
  rts
: cpx #2
  bcc @queen
  jmp @worker
@queen:
  lda etimer,x           ; blink while invulnerable
  beq @vis
  lda frame
  and #4
  beq @vis
  rts
@vis:
  txa
  sta mattr
  lda eface,x
  beq :+
  lda mattr
  ora #$40
  sta mattr
: lda #$40
  sta mbase
  lda eground,x
  bne :+
  lda eanim,x
  and #4
  beq :+
  lda #$44
  sta mbase
: lda eatk,x
  beq :+
  lda #$44
  sta mbase
: lda ex,x
  sta mx
  lda ey,x
  sta my
  jsr draw_meta16
  lda eatk,x
  beq @r
  ; stinger spark in front
  lda #$54
  sta sp_t
  lda #3
  sta sp_a
  lda ey,x
  clc
  adc #4
  sta sp_y
  lda eface,x
  bne @sl
  lda ex,x
  cmp #232
  bcs @r
  clc
  adc #16
  sta sp_x
  jsr put_sprite
  rts
@sl:
  lda ex,x
  cmp #8
  bcc @r
  sec
  sbc #8
  sta sp_x
  jsr put_sprite
@r:
  rts
@worker:
  lda team_of,x
  sta sp_a
  lda eface,x
  beq :+
  lda sp_a
  ora #$40
  sta sp_a
: lda #$4E
  ldy eground,x
  beq @t
  lda eanim,x
  and #8
  beq :+
  lda #$4D
  jmp @t
: lda #$4C
@t:
  sta sp_t
  lda ey,x
  sec
  sbc #1
  sta sp_y
  lda ex,x
  sta sp_x
  jsr put_sprite
  lda ecarry,x
  beq @mark
  lda #$4F
  sta sp_t
  lda #3
  sta sp_a
  lda sp_y
  sec
  sbc #8
  sta sp_y
  jsr put_sprite
@mark:
  lda ewarrior,x
  beq @noyo
  lda #$57
  sta sp_t
  lda #3
  sta sp_a
  lda espin,x
  beq @held
  lda eyx,x
  sec
  sbc #4
  sta sp_x
  lda eyy,x
  sec
  sbc #5
  jmp @yput
@held:
  lda ex,x
  clc
  adc #6
  ldy eface,x
  beq :+
  sec
  sbc #12
: sta sp_x
  lda ey,x
  clc
  adc #1
@yput:
  pha
  lda sp_y
  sta k1
  pla
  sta sp_y
  jsr put_sprite
  lda k1
  sta sp_y
@noyo:
  ; arrow above a worker that a human is steering
  ldy team_of,x
  beq :+
  lda num_players
  cmp #2
  bne @r2
: stx k0
  lda ctrl_ent,y
  cmp k0
  bne @r2
  lda frame
  and #16
  beq @r2
  lda #$55
  sta sp_t
  lda #3
  sta sp_a
  lda sp_y
  sec
  sbc #9
  sta sp_y
  jsr put_sprite
@r2:
  rts

draw_snail:
  lda lv_snail_y
  sec
  sbc #1
  sta sp_y
  lda #2
  sta sp_a
  ldy snail_rider
  cpy #$FF
  beq :+
  lda team_of,y
  beq :+
  lda #$42
  sta sp_a
: lda snail_anim
  and #1
  asl a
  clc
  adc #$50
  sta mbase
  lda sp_a
  and #$40
  beq @nf
  lda snail_x
  sta sp_x
  lda mbase
  clc
  adc #1
  sta sp_t
  jsr put_sprite
  lda snail_x
  clc
  adc #8
  sta sp_x
  lda mbase
  sta sp_t
  jsr put_sprite
  rts
@nf:
  lda snail_x
  sta sp_x
  lda mbase
  sta sp_t
  jsr put_sprite
  lda snail_x
  clc
  adc #8
  sta sp_x
  lda mbase
  clc
  adc #1
  sta sp_t
  jsr put_sprite
  rts

draw_fx:
  lda fx_t
  beq @r
  lda fx_y
  clc
  adc #3
  sta sp_y
  lda fx_x
  clc
  adc #4
  sta sp_x
  lda #$54
  sta sp_t
  lda #3
  sta sp_a
  jsr put_sprite
@r:
  rts

; =====================================================================
; GAME OVER
; =====================================================================
enter_over:
  jsr ppu_off
  lda #<over_nam
  sta ptr
  lda #>over_nam
  sta ptr+1
  jsr load_nametable
  lda winner
  asl a
  tax
  lda win_strs,x
  sta ptr
  lda win_strs+1,x
  sta ptr+1
  jsr write_str
  lda win_type
  asl a
  tax
  lda type_strs,x
  sta ptr
  lda type_strs+1,x
  sta ptr+1
  jsr write_str
  lda win_type
  asl a
  tax
  lda sub_strs,x
  sta ptr
  lda sub_strs+1,x
  sta ptr+1
  jsr write_str
  jsr clear_oam
  lda #ST_OVER
  sta game_state
  lda #40
  sta state_timer
  jsr ppu_on
  rts

over_update:
  lda state_timer
  beq @input
  dec state_timer
  jmp @draw
@input:
  lda pad1_new
  ora pad2_new
  and #BTN_START
  beq :+
  jsr start_match
  rts
: lda pad1_new
  ora pad2_new
  and #BTN_SELECT
  beq @draw
  jsr enter_title
  rts
@draw:
  lda #0
  sta oam_idx
  lda #120
  sta mx
  lda frame
  lsr a
  lsr a
  and #15
  tax
  lda bob_tbl,x
  clc
  adc #44
  sta my
  lda frame
  and #8
  beq :+
  lda #4
: clc
  adc #$40
  sta mbase
  lda winner
  sta mattr
  jsr draw_meta16
  jsr hide_rest
  rts

win_strs:  .word str_blue, str_yellow
type_strs: .word str_mil, str_eco, str_snail
sub_strs:  .word str_mil2, str_eco2, str_snail2
str_blue:   .byte $21,$48,15,"BLUE TEAM WINS!"
str_yellow: .byte $21,$47,17,"YELLOW TEAM WINS!"
str_mil:    .byte $21,$A8,16,"MILITARY VICTORY"
str_eco:    .byte $21,$A8,16,"ECONOMIC VICTORY"
str_snail:  .byte $21,$A9,13,"SNAIL VICTORY"
str_mil2:   .byte $21,$E6,20,"THE ENEMY QUEEN FELL"
str_eco2:   .byte $21,$E8,16,"THE HIVE IS FULL"
str_snail2: .byte $21,$E5,22,"THE SNAIL CROSSED OVER"

; =====================================================================
; AUDIO  (pulse 1 + triangle = music, pulse 2 + noise = effects)
; =====================================================================
sound_init:
  lda #$0F
  sta $4015
  lda #$30
  sta $4000
  sta $4004
  sta $400C
  lda #$08
  sta $4001
  sta $4005
  lda #$80
  sta $4008
  lda #0
  sta mus_active
  sta mus_active+1
  sta mus_active+2
  sta sfx_p_on
  sta sfx_n_on
  sta drum_vol
  lda #$70
  sta cur_duty
  rts

NUM_SONGS = 4
song_lead_lo: .byte <mus_fun_lead, <mus_dark_lead, <mus_metal_lead, <mus_hh_lead
song_lead_hi: .byte >mus_fun_lead, >mus_dark_lead, >mus_metal_lead, >mus_hh_lead
song_bass_lo: .byte <mus_fun_bass, <mus_dark_bass, <mus_metal_bass, <mus_hh_bass
song_bass_hi: .byte >mus_fun_bass, >mus_dark_bass, >mus_metal_bass, >mus_hh_bass
song_drum_lo: .byte <mus_fun_drums,<mus_dark_drums,<mus_metal_drums,<mus_hh_drums
song_drum_hi: .byte >mus_fun_drums,>mus_dark_drums,>mus_metal_drums,>mus_hh_drums
song_duty:    .byte $70, $B0, $30, $B0     ; 25%, 50%, 12.5% (buzzy), 50%
octave_tbl:   .byte 0, 12, $F4, 0           ; lead transpose choices

; A = song id. Preserves X and Y.
start_song:
  sta cur_song
  stx ssave+1
  sty ssave+2
  tay
  lda song_duty,y
  sta cur_duty
  lda #0
  sta mus_trans
  lda song_lead_lo,y
  pha
  lda song_lead_hi,y
  tay
  pla
  ldx #0
  jsr mus_start
  ldy cur_song
  lda song_bass_lo,y
  pha
  lda song_bass_hi,y
  tay
  pla
  ldx #1
  jsr mus_start
  ldy cur_song
  lda song_drum_lo,y
  pha
  lda song_drum_hi,y
  tay
  pla
  ldx #2
  jsr mus_start
  ldx ssave+1
  ldy ssave+2
  rts

; big moment: switch to a different song (rate-limited). Preserves X, Y.
music_event:
  lda song_cool
  bne @r
  lda game_state
  cmp #ST_PLAY
  bne @r
  jsr rand
  and #(NUM_SONGS-1)
  cmp cur_song
  bne :+
  clc
  adc #1
  and #(NUM_SONGS-1)
: jsr start_song
  jsr rand               ; start the new song at a random octave
  and #3
  sty ssave+1
  tay
  lda octave_tbl,y
  sta mus_trans
  ldy ssave+1
  lda #240               ; at most one switch every 4 seconds
  sta song_cool
@r:
  rts

play_win_music:
  txa
  pha
  tya
  pha
  lda #0
  sta mus_active+2       ; drums out for the jingle
  sta drum_vol
  sta mus_trans
  lda #$B0
  sta cur_duty
  lda #<mus_win_lead
  ldy #>mus_win_lead
  ldx #0
  jsr mus_start
  lda #<mus_win_bass
  ldy #>mus_win_bass
  ldx #1
  jsr mus_start
  pla
  tay
  pla
  tax
  rts

; A/Y = stream pointer, X = channel
mus_start:
  sta mus_lo,x
  sta mus_looplo,x
  tya
  sta mus_hi,x
  sta mus_loophi,x
  lda #1
  sta mus_timer,x
  sta mus_active,x
  rts

; A = sfx id. Preserves X and Y.
play_sfx:
  sty ssave
  tay
  lda sfx_lo,y
  pha
  lda sfx_hi,y
  pha
  lda sfx_chan,y
  bne @noise
  pla
  sta sfx_p_hi
  pla
  sta sfx_p_lo
  lda #$FF
  sta sfx_lasthi
  lda #1
  sta sfx_p_on
  ldy ssave
  rts
@noise:
  pla
  sta sfx_n_hi
  pla
  sta sfx_n_lo
  lda #1
  sta sfx_n_on
  lda #$08
  sta $400F
  ldy ssave
  rts

sfx_lo:   .byte <sfx_jump,<sfx_flap,<sfx_pick,<sfx_deposit,<sfx_hitp,<sfx_menu,<sfx_dash,<sfx_hit,<sfx_clank,<sfx_arm,<sfx_yoyo
sfx_hi:   .byte >sfx_jump,>sfx_flap,>sfx_pick,>sfx_deposit,>sfx_hitp,>sfx_menu,>sfx_dash,>sfx_hit,>sfx_clank,>sfx_arm,>sfx_yoyo
sfx_chan: .byte 0,0,0,0,0,0,1,1,1,0,0

sound_update:
  ldx #0
  jsr mus_channel
  ldx #1
  jsr mus_channel
  ldx #2
  jsr mus_channel
  ; lead envelope
  lda p1_env
  beq @env0
  lda frame
  and #3
  bne @env0
  lda p1_env
  cmp #5
  bcc @env0
  dec p1_env
@env0:
  lda p1_env
  ora cur_duty
  sta $4000
  ; pulse 2 effects
  lda sfx_p_on
  beq @noise
  lda sfx_p_lo
  sta sptr
  lda sfx_p_hi
  sta sptr+1
  ldy #0
  lda (sptr),y
  beq @pend
  sta $4004
  iny
  lda (sptr),y
  sta $4006
  iny
  lda (sptr),y
  cmp sfx_lasthi
  beq :+
  sta sfx_lasthi
  ora #$08
  sta $4007
: lda sfx_p_lo
  clc
  adc #3
  sta sfx_p_lo
  bcc @noise
  inc sfx_p_hi
  jmp @noise
@pend:
  lda #0
  sta sfx_p_on
  lda #$30
  sta $4004
@noise:
  lda sfx_n_on
  beq @drums
  lda sfx_n_lo
  sta sptr
  lda sfx_n_hi
  sta sptr+1
  ldy #0
  lda (sptr),y
  beq @nend
  sta $400C
  iny
  lda (sptr),y
  sta $400E
  lda sfx_n_lo
  clc
  adc #2
  sta sfx_n_lo
  bcc @r
  inc sfx_n_hi
  rts
@nend:
  lda #0
  sta sfx_n_on
  lda #$30
  sta $400C
  rts
@drums:                  ; drums use the noise channel when no effect is
  lda drum_vol           ; playing there
  beq @r
  ora #$30
  sta $400C
  lda drum_per
  sta $400E
  lda drum_vol
  sec
  sbc drum_dec
  bcs :+
  lda #0
: sta drum_vol
  bne @r
  lda #$30
  sta $400C
@r:
  rts

; X = channel (0 lead pulse, 1 bass triangle, 2 drums)
mus_channel:
  lda mus_active,x
  bne :+
  rts
: dec mus_timer,x
  beq @read
  rts
@read:
  lda mus_lo,x
  sta sptr
  lda mus_hi,x
  sta sptr+1
  ldy #0
  lda (sptr),y
  cmp #$FF
  bne @nl
  lda mus_looplo,x
  sta mus_lo,x
  lda mus_loophi,x
  sta mus_hi,x
  cpx #0                 ; every time the lead loops, maybe shift an octave
  bne @read
  jsr rand
  and #3
  tay
  lda octave_tbl,y
  sta mus_trans
  jmp @read
@nl:
  cmp #$FE
  bne @note
  lda #0
  sta mus_active,x
  jmp silence_ch
@note:
  sta snote
  iny
  lda (sptr),y
  sta mus_timer,x
  lda mus_lo,x
  clc
  adc #2
  sta mus_lo,x
  bcc :+
  inc mus_hi,x
: lda snote
  bne @on
  cpx #2
  beq @rts
  jmp silence_ch
@on:
  cpx #2
  beq @drum
  cpx #0
  bne @idx
  clc                    ; transpose the lead, keep it in the table
  adc mus_trans
  beq @untr
  cmp #64
  bcc @idx
@untr:
  lda snote
@idx:
  asl a
  tay
  cpx #0
  bne @tri
  lda periods,y
  sta $4002
  lda periods+1,y
  ora #$08
  sta $4003
  lda #11
  sta p1_env
@rts:
  rts
@tri:
  lda #$FF
  sta $4008
  lda periods,y
  sta $400A
  lda periods+1,y
  ora #$08
  sta $400B
  rts
@drum:
  ldy snote
  lda drum_vol_t,y
  sta drum_vol
  lda drum_per_t,y
  sta drum_per
  lda drum_dec_t,y
  sta drum_dec
  lda sfx_n_on
  bne :+
  lda #$08
  sta $400F
: rts

;                 -   kick snare hat crash
drum_vol_t: .byte 0,  15,  12,   6,  10
drum_per_t: .byte 0,  13,   6, $81,   3
drum_dec_t: .byte 1,   3,   2,   3,   1

silence_ch:
  cpx #0
  bne @t
  lda #0
  sta p1_env
  rts
@t:
  cpx #2
  bne @tri
  lda #0
  sta drum_vol
  rts
@tri:
  lda #$80
  sta $4008
  lda #$08
  sta $400B
  rts

; =====================================================================
.segment "RODATA"
palettes:
  .byte $0F,$07,$17,$2A, $0F,$01,$21,$30, $0F,$17,$28,$30, $0F,$14,$25,$30
  .byte $0F,$21,$30,$0F, $0F,$28,$30,$0F, $0F,$27,$2A,$0F, $0F,$16,$30,$0F
title_nam: .incbin "build/title.nam"
over_nam:  .incbin "build/over.nam"
.include "build/gen_data.inc"

collide   = lvl_ram + LV_COLLIDE
walls     = lvl_ram + LV_WALLS
rowidx    = lvl_ram + LV_ROWIDX
launch_l  = lvl_ram + LV_LAUNCH_L
launch_r  = lvl_ram + LV_LAUNCH_R
berry_row = lvl_ram + LV_BERRY_ROW
berry_col = lvl_ram + LV_BERRY_COL
berry_px  = lvl_ram + LV_BERRY_PX
berry_py  = lvl_ram + LV_BERRY_PY
lv_snail_y     = lvl_ram + LV_PARAMS + 0
lv_snail_start = lvl_ram + LV_PARAMS + 1
lv_goal_l      = lvl_ram + LV_PARAMS + 2
lv_goal_r      = lvl_ram + LV_PARAMS + 3
lv_wrap        = lvl_ram + LV_PARAMS + 4
lv_sx0         = lvl_ram + LV_PARAMS + 5
lv_sx1         = lvl_ram + LV_PARAMS + 6
lv_side        = lvl_ram + LV_PARAMS + 7   ; $80 = sides wrap around
lv_boxes       = lvl_ram + LV_PARAMS + 8   ; weapon boxes on this board
lv_boxx        = lvl_ram + LV_PARAMS + 9   ; [team] box x
lv_boxy        = lvl_ram + LV_PARAMS + 11
lv_boxrow      = lvl_ram + LV_PARAMS + 12

.segment "VECTORS"
  .word nmi, reset, irq

.segment "CHARS"
  .incbin "build/chr.bin"
