#!/usr/bin/env python3
"""Generates every asset for KILLER BEE from human-readable source data.

Outputs (in build/):
  chr.bin      8 KB CHR ROM (shared pattern table for BG and sprites)
  arena.nam    1 KB nametable + attributes for the arena
  title.nam    1 KB title screen
  over.nam     1 KB game-over / rematch screen
  gen_data.inc assembler data: collision bitmask, AI launch tables,
               berry spots, APU period table, music and SFX streams
All art is original and drawn here as ASCII (0-3 = palette index).
"""
import os, sys, random

OUT = sys.argv[1] if len(sys.argv) > 1 else "build"
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- CHR tiles
tiles = [[[0] * 8 for _ in range(8)] for _ in range(256)]

def put(idx, rows):
    assert len(rows) == 8, (idx, rows)
    for y, r in enumerate(rows):
        assert len(r) == 8, (idx, r)
        tiles[idx][y] = [0 if c == '.' else int(c) for c in r]

def put16(idx, rows):
    """16x16 art -> 4 tiles idx (TL), idx+1 (TR), idx+2 (BL), idx+3 (BR)."""
    assert len(rows) == 16 and all(len(r) == 16 for r in rows), rows
    for q, (ox, oy) in enumerate([(0, 0), (8, 0), (0, 8), (8, 8)]):
        put(idx + q, [rows[oy + y][ox:ox + 8] for y in range(8)])

def put16x8(idx, rows):
    assert len(rows) == 8 and all(len(r) == 16 for r in rows), rows
    put(idx, [r[:8] for r in rows]); put(idx + 1, [r[8:] for r in rows])

# --- background tiles
put(0x01, ["11111111", "12111121", "11111111", "11121111",
           "11111111", "21111112", "11111111", "11112111"])        # dirt
put(0x02, ["33333333", "22222222", "21212121", "11111111",
           "........", "........", "........", "........"])        # platform
put(0x03, ["33333333", "33233323", "22122212", "11111111",
           "12111121", "11111111", "11121111", "11111111"])        # ground top
put16(0x04, ["......3333......",
             "....33222233....",
             "...3222222223...",
             "..311111111113..",
             "..322222222223..",
             ".31111111111113.",
             ".32222222222223.",
             "3111111111111113",
             "3222222..2222223",
             "311111....111113",
             "32222......22223",
             "31111......11113",
             "32222......22223",
             "31111......11113",
             "3222222222222223",
             "3333333333333333"])                                    # hive 04-07
put(0x08, ["....2...", "...2....", ".11.11..", "1311311.",
           "1111111.", ".11.11..", "..111...", "........"])        # BG berry
put(0x09, ["..2222..", ".2....2.", "2......2", "2......2",
           "2......2", ".2....2.", "..2222..", "........"])        # meter empty
put(0x0A, ["..3333..", ".322223.", "32222223", "32222223",
           "32222223", ".322223.", "..3333..", "........"])        # meter full
put(0x0B, ["........", "2..2..2.", "22.2.22.", "2222222.",
           "2323232.", "2222222.", "........", "........"])        # crown (life)
put(0x0D, ["........", "........", "...2....", "........",
           "........", "........", "........", "........"])        # pollen dot
put(0x0E, ["..2222..", ".2....2.", "2......2", "2......2",
           ".2....2.", "..2222..", "...22...", "...22..."])        # honeycomb

FONT = {
 '0': ["01110","10001","10011","10101","11001","10001","01110"],
 '1': ["00100","01100","00100","00100","00100","00100","01110"],
 '2': ["01110","10001","00001","00010","00100","01000","11111"],
 '3': ["11111","00010","00100","00010","00001","10001","01110"],
 '4': ["00010","00110","01010","10010","11111","00010","00010"],
 '5': ["11111","10000","11110","00001","00001","10001","01110"],
 '6': ["00110","01000","10000","11110","10001","10001","01110"],
 '7': ["11111","00001","00010","00100","01000","01000","01000"],
 '8': ["01110","10001","10001","01110","10001","10001","01110"],
 '9': ["01110","10001","10001","01111","00001","00010","01100"],
 'A': ["01110","10001","10001","11111","10001","10001","10001"],
 'B': ["11110","10001","10001","11110","10001","10001","11110"],
 'C': ["01110","10001","10000","10000","10000","10001","01110"],
 'D': ["11100","10010","10001","10001","10001","10010","11100"],
 'E': ["11111","10000","10000","11110","10000","10000","11111"],
 'F': ["11111","10000","10000","11110","10000","10000","10000"],
 'G': ["01110","10001","10000","10111","10001","10001","01111"],
 'H': ["10001","10001","10001","11111","10001","10001","10001"],
 'I': ["01110","00100","00100","00100","00100","00100","01110"],
 'J': ["00111","00010","00010","00010","00010","10010","01100"],
 'K': ["10001","10010","10100","11000","10100","10010","10001"],
 'L': ["10000","10000","10000","10000","10000","10000","11111"],
 'M': ["10001","11011","10101","10101","10001","10001","10001"],
 'N': ["10001","10001","11001","10101","10011","10001","10001"],
 'O': ["01110","10001","10001","10001","10001","10001","01110"],
 'P': ["11110","10001","10001","11110","10000","10000","10000"],
 'Q': ["01110","10001","10001","10001","10101","10010","01101"],
 'R': ["11110","10001","10001","11110","10100","10010","10001"],
 'S': ["01111","10000","10000","01110","00001","00001","11110"],
 'T': ["11111","00100","00100","00100","00100","00100","00100"],
 'U': ["10001","10001","10001","10001","10001","10001","01110"],
 'V': ["10001","10001","10001","10001","10001","01010","00100"],
 'W': ["10001","10001","10001","10101","10101","10101","01010"],
 'X': ["10001","10001","01010","00100","01010","10001","10001"],
 'Y': ["10001","10001","10001","01010","00100","00100","00100"],
 'Z': ["11111","00001","00010","00100","01000","10000","11111"],
 '!': ["00100","00100","00100","00100","00100","00000","00100"],
 '-': ["00000","00000","00000","11111","00000","00000","00000"],
 '.': ["00000","00000","00000","00000","00000","01100","01100"],
 ':': ["00000","01100","01100","00000","01100","01100","00000"],
 '>': ["01000","00100","00010","00001","00010","00100","01000"],
}
CHARMAP = {' ': 0}
order = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
for i, ch in enumerate(order):
    CHARMAP[ch] = 0x10 + i
for i, ch in enumerate("!-.:>"):
    CHARMAP[ch] = 0x34 + i
for ch, t in CHARMAP.items():
    if ch == ' ':
        continue
    g = FONT[ch]
    rows = []
    for y in range(8):
        if y < 7:
            rows.append('.' + ''.join('3' if b == '1' else '.' for b in g[y]) + '..')
        else:
            rows.append('........')
    put(t, rows)

# big 2x title letters (yellow face colour 2, brown drop shadow colour 1)
BIG = "KILERB"
for i, ch in enumerate(BIG):
    g = FONT[ch]
    px = [['.'] * 16 for _ in range(16)]
    for y in range(7):
        for x in range(5):
            if g[y][x] == '1':
                for dy in range(2):
                    for dx in range(2):
                        sx, sy = 3 + x * 2 + dx + 1, 1 + y * 2 + dy + 1
                        if sx < 16 and sy < 16 and px[sy][sx] == '.':
                            px[sy][sx] = '1'
    for y in range(7):
        for x in range(5):
            if g[y][x] == '1':
                for dy in range(2):
                    for dx in range(2):
                        px[1 + y * 2 + dy][3 + x * 2 + dx] = '2'
    put16(0x60 + i * 4, [''.join(r) for r in px])
BIGIDX = {ch: 0x60 + i * 4 for i, ch in enumerate(BIG)}

put(0x0C, ["........", "........", "........", "........",
           "11111111", "12121212", "22222222", "33333333"])        # ceiling beam
VINE_A = ["..3.....", ".3......", ".3.33...", ".3333...",
          "..3.....", "..3.....", ".3......", ".3......"]
VINE_B = [".3......", "..3.....", "..3.....", ".3......",
          ".3......", ".3......", "..3.....", "..3....."]
put(0x39, VINE_A); put(0x3A, VINE_B)                         # left-edge vine
put(0x3B, [r[::-1] for r in VINE_A]); put(0x3C, [r[::-1] for r in VINE_B])  # right edge
put(0x0F, ["11121112", "22222222", "21112111", "22222222",
           "11121112", "22222222", "21112111", "22222222"])        # brick wall

# --- sprite tiles (1 = team colour, 2 = white, 3 = black)
QUEEN_A = [
    ".....222........",
    "....22222.......",
    "...222222..2.2.2",
    "...2222222.22222",
    "....22222..33333",
    "..3333333.311313",
    ".311311311311113",
    "3113113113111113",
    "3113113113111133",
    "3113113113113...",
    ".311311311313...",
    "..3113113133....",
    "...33333333.....",
    "....3..3..3.....",
    "...3..3..3......",
    "................"]
QUEEN_B = ["................",
           "................",
           "...........2.2.2",
           ".22222.....22222",
           "2222222....33333"] + QUEEN_A[5:]
put16(0x40, QUEEN_A)
put16(0x44, QUEEN_B)
put(0x4C, ["..222...", ".2222...", "..33333.", ".3131133",
           "31313131", ".3131113", "..33333.", "..3..3.."])   # worker walk A
put(0x4D, ["........", ".222....", "22233333", ".3131133",
           "31313131", ".3131113", "..33333.", "...3..3."])   # worker walk B
put(0x4E, [".222....", "22222...", "..33333.", ".3131133",
           "31313131", ".3131113", "..33333.", "........"])   # worker jump
put(0x4F, ["....3...", "...3....", ".11.11..", "1211211.",
           "1111111.", ".11.11..", "..111...", "........"])   # carried berry
put16x8(0x50, ["...33333....3.3.",
               "..3111113...2.2.",
               ".311333113..222.",
               ".313113113.2222.",
               ".313333113.222..",
               ".31111113.2222..",
               "222333332222222.",
               ".222222222222..."])                              # snail A
put16x8(0x52, ["...33333...3.3..",
               "..3111113..2.2..",
               ".311333113.222..",
               ".313113113.2222.",
               ".313333113.222..",
               ".31111113.2222..",
               "222333332222222.",
               "2222222222222..."])                              # snail B
put(0x54, ["...2....", ".2.2.2..", "..222...", "2222222.",
           "..222...", ".2.2.2..", "...2....", "........"])   # hit spark
put(0x55, ["........", ".22222..", ".22222..", "..222...",
           "..222...", "...2....", "........", "........"])   # player marker
put(0x57, ["........", "..3333..", ".311113.", ".312213.",
           ".312213.", ".311113.", "..3333..", "........"])   # yo-yo
put16(0x58, ["3333333333333333",
             "3222222222222223",
             "3233333333333323",
             "3231111111111323",
             "3231113333111323",
             "3231131111311323",
             "3231311221131323",
             "3231312112131323",
             "3231312112131323",
             "3231311221131323",
             "3231131111311323",
             "3231113333111323",
             "3231111111111323",
             "3233333333333323",
             "3222222222222223",
             "3333333333333333"])                                  # weapon box 58-5B
put(0x56, [".2......", ".22.....", ".222....", ".2222...",
           ".222....", ".22.....", ".2......", "........"])   # menu cursor

chr_bytes = bytearray()
for t in tiles:
    p0 = bytearray(8); p1 = bytearray(8)
    for y in range(8):
        for x in range(8):
            v = t[y][x]
            if v & 1: p0[y] |= 0x80 >> x
            if v & 2: p1[y] |= 0x80 >> x
    chr_bytes += p0 + p1
assert len(chr_bytes) == 4096
chr_bytes += bytes(4096)            # pattern table 1 unused
open(f"{OUT}/chr.bin", "wb").write(chr_bytes)

# ------------------------------------------------------------ nametables
class Screen:
    def __init__(self):
        self.nt = [0] * 960
        self.pal = [[0] * 16 for _ in range(15)]   # 16x16-pixel cells
    def tile(self, col, row, t):
        self.nt[row * 32 + col] = t
    def text(self, col, row, s):
        for i, ch in enumerate(s):
            self.tile(col + i, row, CHARMAP[ch])
    def palbox(self, c0, r0, c1, r1, p):    # inclusive tile coords (even aligned)
        for r in range(r0 // 2, r1 // 2 + 1):
            for c in range(c0 // 2, c1 // 2 + 1):
                self.pal[r][c] = p
    def bytes(self):
        attr = bytearray(64)
        for ar in range(8):
            for ac in range(8):
                v = 0
                for q, (dx, dy) in enumerate([(0, 0), (1, 0), (0, 1), (1, 1)]):
                    r, c = ar * 2 + dy, ac * 2 + dx
                    p = self.pal[r][c] if r < 15 else 0
                    v |= p << (q * 2)
                attr[ar * 8 + ac] = v
        return bytes(self.nt) + bytes(attr)

# --- title screen
title = Screen()
for c in range(32):
    title.tile(c, 1, 0x0E); title.tile(c, 28, 0x0E)
title.palbox(0, 0, 31, 1, 1); title.palbox(0, 28, 31, 29, 1)
def big(scr, col, row, word):
    for i, ch in enumerate(word):
        b = BIGIDX[ch]
        scr.tile(col + i * 2, row, b); scr.tile(col + i * 2 + 1, row, b + 1)
        scr.tile(col + i * 2, row + 1, b + 2); scr.tile(col + i * 2 + 1, row + 1, b + 3)
big(title, 10, 6, "KILLER"); big(title, 13, 9, "BEE")
title.palbox(0, 6, 31, 11, 2)
for r in list(range(2, 6)) + list(range(12, 28)):
    title.palbox(0, r, 31, r, 3)
title.text(6, 13, "AN 8-BIT HIVE BATTLE")
title.text(10, 16, "1 PLAYER VS CPU")
title.text(10, 18, "2 PLAYERS")
title.text(10, 22, "PRESS START")
title.text(2, 24, "WIN BY QUEEN. BERRIES. SNAIL")
title.text(8, 26, "SELECT: SWITCH BEE")
open(f"{OUT}/title.nam", "wb").write(title.bytes())

# --- game over screen (winner text is written by the game code)
over = Screen()
for c in range(32):
    over.tile(c, 1, 0x0E); over.tile(c, 28, 0x0E)
over.palbox(0, 0, 31, 1, 1); over.palbox(0, 28, 31, 29, 1)
for r in range(2, 28):
    over.palbox(0, r, 31, r, 3)
over.text(5, 20, "PRESS START TO REMATCH")
over.text(8, 22, "SELECT FOR TITLE")
open(f"{OUT}/over.nam", "wb").write(over.bytes())

# ------------------------------------------------------------ levels


GROUND_ROW = 26
LEVELS = [
    dict(name="MEADOW",
         platforms={8: [(5, 11), (20, 26)],
                    14: [(0, 6), (13, 18), (25, 31)],
                    20: [(3, 9), (12, 19), (22, 28)]},
         berries=[(7, 7), (7, 24), (13, 2), (13, 29), (13, 14), (13, 17),
                  (19, 5), (19, 26), (25, 9), (25, 22)],
         walls=[], shaft=None,
         snail=dict(y=200, start=120, goal_l=16, goal_r=224)),
    dict(name="WRAP HIVE",
         platforms={10: [(3, 9), (13, 18), (22, 28)],
                    16: [(2, 7), (11, 20), (24, 29)],      # trench roof, gaps 8-10 / 21-23
                    20: [(4, 27)],                         # trench floor
                    21: [(0, 1), (30, 31)]},               # ledges over the hives
         berries=[(9, 5), (9, 26), (9, 14), (9, 17), (15, 5), (15, 26),
                  (15, 13), (15, 18), (25, 7), (25, 24)],
         walls=[(4, r) for r in (17, 18, 19)] + [(27, r) for r in (17, 18, 19)],
         shaft=(14, 17),                                   # ceiling gap + floor pit columns
         snail=dict(y=152, start=120, goal_l=40, goal_r=200)),
]
LEVELS.append(dict(
    name="DIVIDE",
    platforms={8: [(4, 27)],                                  # top bridge over the wall
               14: [(0, 6), (10, 14), (17, 21), (25, 31)],
               20: [(3, 9), (22, 28)]},
    berries=[(7, 7), (7, 24), (7, 12), (7, 19), (13, 12), (13, 19),
             (19, 5), (19, 26), (25, 6), (25, 25)],
    walls=[(c, r) for c in (15, 16) for r in range(9, 22)],    # middle wall
    bumps=[(15, 21), (16, 21)],          # its underside stops bees from below
    shaft=None,
    boxes=dict(row=14, cols=(28, 2)),    # team 0's box on yellow's side, team 1's on blue's
    snail=dict(y=200, start=120, goal_l=16, goal_r=224)))

# the same two boards again with open sides (walk/fly off one edge, come
# in from the other). Solid-sided boards get a vine border instead.
LEVELS[0]["name"] = "MEADOW"; LEVELS[1]["name"] = "WRAP HIVE"
for base in (0, 1):
    L = dict(LEVELS[base]); L["side_wrap"] = True; L["name"] += " WARP"
    LEVELS.insert(2 + base, L)          # order: meadow, wrap hive, their warps, divide
BLOB_SIZE = 768
LV = dict(COLLIDE=0, WALLS=120, ROWIDX=240, LAUNCH_L=270, LAUNCH_R=430,
          BERRY_ROW=590, BERRY_COL=600, BERRY_PX=610, BERRY_PY=620, PARAMS=630)

def build_level(L):
    P, shaft = L["platforms"], L["shaft"]
    wallset = set(L["walls"])
    bumps = set(L.get("bumps", []))
    def ground_solid(c):
        return not (shaft and shaft[0] <= c <= shaft[1])
    def solid(c, r):
        if not (0 <= c < 32):
            return False
        if (c, r) in bumps:
            return True
        if r >= GROUND_ROW:
            return r < 30 and ground_solid(c)
        return any(a <= c <= b for a, b in P.get(r, []))
    def plat(c, r):
        return 0 <= r < GROUND_ROW and solid(c, r)
    def wall(c, r):
        return (c, r) in wallset

    # ---- nametable
    scr = Screen()
    rnd = random.Random(7 + len(P))
    for _ in range(26):
        c, r = rnd.randrange(32), rnd.randrange(6, 25)
        scr.tile(c, r, 0x0D)
    for row, segs in P.items():
        for a, b in segs:
            for c in range(a, b + 1):
                scr.tile(c, row, 0x02)
    for c in range(32):
        if ground_solid(c):
            scr.tile(c, GROUND_ROW, 0x03)
            for r in range(GROUND_ROW + 1, 30):
                scr.tile(c, r, 0x01)
        else:
            for r in range(GROUND_ROW, 30):
                scr.tile(c, r, 0x00)
    for c, r in wallset:
        scr.tile(c, r, 0x0F)
    bx = L.get("boxes")
    if bx:
        for team, c in enumerate(bx["cols"]):
            r = bx["row"] - 2
            scr.tile(c, r, 0x58); scr.tile(c + 1, r, 0x59)
            scr.tile(c, r + 1, 0x5A); scr.tile(c + 1, r + 1, 0x5B)
            scr.palbox(c, r, c + 1, r + 1, 1 + team)     # box shows its team's colour
    for col, p in ((0, 1), (30, 2)):
        scr.tile(col, 24, 0x04); scr.tile(col + 1, 24, 0x05)
        scr.tile(col, 25, 0x06); scr.tile(col + 1, 25, 0x07)
        scr.palbox(col, 24, col + 1, 25, p)
    for r, c in L["berries"]:
        assert r % 2 == 1 and solid(c, r + 1), (L["name"], r, c)
        scr.tile(c, r, 0x08)
        scr.palbox(c, r, c, r, 3)
    scr.text(1, 2, "BLUE"); scr.text(25, 2, "YELLOW"); scr.text(11, 2, "KILLER BEE")
    for i in range(8):
        scr.tile(1 + i, 3, 0x09); scr.tile(30 - i, 3, 0x09)
    for i in range(3):
        scr.tile(1 + i, 4, 0x0B); scr.tile(30 - i, 4, 0x0B)
    scr.palbox(0, 2, 9, 5, 1); scr.palbox(10, 2, 21, 5, 3); scr.palbox(22, 2, 31, 5, 2)
    side = L.get("side_wrap", False)
    if not side:                    # vines mark the solid side walls
        for r in range(6, 24):
            for c, (ta, tb) in ((0, (0x39, 0x3A)), (31, (0x3B, 0x3C))):
                if scr.nt[r * 32 + c] in (0, 0x0D):
                    scr.tile(c, r, ta if r % 2 == 0 else tb)
        scr.palbox(0, 6, 1, 23, 0); scr.palbox(30, 6, 31, 23, 0)
    if shaft:                       # visible ceiling with a gap over the pit
        for c in range(4, 28):
            if not (shaft[0] <= c <= shaft[1]):
                scr.tile(c, 4, 0x0C)
        scr.palbox(4, 4, 27, 5, 0)

    # ---- collision bitmasks
    def mask(fn):
        out = []
        for r in range(30):
            for b in range(4):
                v = 0
                for i in range(8):
                    if fn(b * 8 + i, r):
                        v |= 0x80 >> i
                out.append(v)
        return out
    collide = mask(solid)
    walls = mask(wall)

    # ---- AI launch tables (edge hops; platforms are solid from below)
    stand = sorted({GROUND_ROW} | set(P), reverse=True)
    def wall_under(c, s_):
        return wall(c, s_ + 1)
    assert len(stand) <= 5
    rowidx = [0xFF] * 30
    for i, s_ in enumerate(stand):
        rowidx[s_] = i
    def segments(s_):
        segs, c = [], 0
        while c < 32:
            if solid(c, s_):
                a = c
                while c < 32 and solid(c, s_):
                    c += 1
                segs.append((a, c - 1))
            else:
                c += 1
        return segs
    def segment_of(c, s_):
        for a, b in segments(s_):
            if a <= c <= b:
                return (a, b)
    def launch_val(c, s_):
        if any(plat(c, r) or wall(c, r) for r in range(s_ - 8, s_)):
            return None
        for d, flag in ((1, 0), (-1, 0x40)):
            n = c + d
            for r in range(s_ - 6, s_):
                if plat(n, r) and not any(wall(n, rr) for rr in range(r - 3, r)):
                    return c | flag
        return None
    LL, LR = [], []
    for i in range(5):
        s_ = stand[i] if i < len(stand) else None
        for c in range(32):
            seg = segment_of(c, s_) if s_ is not None else None
            l = r_ = 0xFF
            if seg:
                # heading left: prefer the nearest hop that drifts left
                left = [launch_val(cc, s_) for cc in range(c, seg[0] - 1, -1)]
                left = [v for v in left if v is not None]
                l = next((v for v in left if v & 0x40), left[0] if left else 0xFF)
                right = [launch_val(cc, s_) for cc in range(c, seg[1] + 1)]
                right = [v for v in right if v is not None]
                r_ = next((v for v in right if not v & 0x40), right[0] if right else 0xFF)
            LL.append(l); LR.append(r_)

    # ---- reachability proof (launch hops, walking off edges, dropping
    # through platforms, and the pit/ceiling wrap)
    def land_below(c, s_):
        for r in range(s_ + 1, 30):
            if solid(c, r):
                return r
        for r in range(5, 30):              # fell into the pit: wrap to the top
            if solid(c, r):
                return r
    surfaces = {(s_, seg) for s_ in stand for seg in segments(s_)}
    start = (GROUND_ROW, segment_of(0, GROUND_ROW))
    reach, frontier = {start}, [start]
    while frontier:
        s_, (a, b) = frontier.pop()
        nxt = []
        for c in range(a, b + 1):
            v = launch_val(c, s_)
            if v is not None:
                n = (v & 0x3F) + (-1 if v & 0x40 else 1)
                for r in range(s_ - 6, s_):
                    if plat(n, r):
                        nxt.append((r, segment_of(n, r)))
            if s_ != GROUND_ROW and not wall_under(c, s_):   # drop through
                r = land_below(c, s_)
                nxt.append((r, segment_of(c, r)))
        for n, side in ((a - 1, a), (b + 1, b)):  # walk off an edge
            if 0 <= n < 32 and not wall(n, s_ - 1) and not wall(side, s_ - 1):
                r = land_below(n, s_ if s_ != GROUND_ROW else GROUND_ROW - 1)
                if r is not None:
                    nxt.append((r, segment_of(n, r)))
        for t in nxt:
            if t not in reach:
                reach.add(t); frontier.append(t)
    assert reach == surfaces, (L["name"], "unreachable", surfaces - reach)

    # ---- pack the per-level RAM blob
    sn = L["snail"]
    sx = shaft or (0, 0)
    params = [sn["y"], sn["start"], sn["goal_l"], sn["goal_r"],
              1 if shaft else 0, sx[0] * 8, (sx[1] + 1) * 8,
              0x80 if L.get("side_wrap") else 0]
    if bx:
        params += [1, bx["cols"][0] * 8, bx["cols"][1] * 8, (bx["row"] - 2) * 8, bx["row"]]
    else:
        params += [0, 0, 0, 0, 0]
    br = L["berries"]
    blob = (collide + walls + rowidx + LL + LR + [r for r, c in br] + [c for r, c in br]
            + [c * 8 for r, c in br] + [r * 8 for r, c in br] + params)
    assert len(blob) <= BLOB_SIZE
    blob += [0] * (BLOB_SIZE - len(blob))
    return scr.bytes(), blob

inc = []
inc.append("; ---- generated by tools/gen_assets.py, do not edit ----")
inc.append(f"NUM_LEVELS = {len(LEVELS)}")
inc.append(f"LEVEL_BLOB_PAGES = {BLOB_SIZE // 256}")
for k, v in LV.items():
    inc.append(f"LV_{k} = {v}")
inc.append("NUM_BERRIES = 10")
def emit(name, data, per=16):
    inc.append(f"{name}:")
    for i in range(0, len(data), per):
        inc.append("  .byte " + ",".join(f"${v:02X}" for v in data[i:i + per]))
for i, L in enumerate(LEVELS):
    nam, blob = build_level(L)
    open(f"{OUT}/level{i}.nam", "wb").write(nam)
    emit(f"level{i}_blob", blob)
inc.append("level_blobs: .word " + ",".join(f"level{i}_blob" for i in range(len(LEVELS))))
inc.append("level_nams:  .word " + ",".join(f"level{i}_nam" for i in range(len(LEVELS))))
for i in range(len(LEVELS)):
    inc.append(f'level{i}_nam: .incbin "build/level{i}.nam"')

# ---------------------------------------------------------- audio data
CPU = 1789773
NOTE_NAMES = {'C': 0, 'C#': 1, 'D': 2, 'D#': 3, 'E': 4, 'F': 5, 'F#': 6,
              'G': 7, 'G#': 8, 'A': 9, 'A#': 10, 'B': 11}
def midi(n):
    name, octv = n[:-1], int(n[-1])
    return 12 * (octv + 1) + NOTE_NAMES[name]
BASE = 35                                # note index 1 = MIDI 36 (C2)
periods = [0]
for idx in range(1, 64):
    f = 440.0 * 2 ** ((BASE + idx - 69) / 12)
    p = min(0x7FF, round(CPU / (16 * f)) - 1)
    periods.append(p)
inc.append("periods:")
for p in periods:
    inc.append(f"  .byte ${p & 0xFF:02X},${p >> 8:02X}")
def note_idx(n):
    if n == 'R':
        return 0
    i = midi(n) - BASE
    assert 1 <= i < 64, n
    return i
def stream(name, seq, end):
    out = []
    for n, d in seq:
        while d > 255:
            out += [note_idx(n), 255]; d -= 255
        out += [note_idx(n), d]
    out.append(end)
    emit(name, out)

# Four original songs. Lead = pulse 1, bass = triangle (sounds an octave
# down), drums = noise (1 kick, 2 snare, 3 hat, 4 crash, R rest).
def drums(name, pattern, bars):
    out = []
    for _ in range(bars):
        for d, n in pattern:
            out += [d, n]
    out.append(0xFF)
    emit(name, out)
def bar_bass(root_fifth_list, pattern):
    seq = []
    for r, f in root_fifth_list:
        for which, d in pattern:
            seq.append(({'r': r, 'f': f, 'R': 'R'}[which], d))
    return seq
def check_len(name, *streams):
    lens = [sum(d for _, d in st) for st in streams]
    assert len(set(lens)) == 1, (name, lens)
    return lens[0]

# 1) FUN - bouncy A minor (the original theme)
E = 8
fun_lead = [
 ('A4',E),('C5',E),('E5',E),('A5',E),('G5',E),('E5',E),('C5',E),('D5',E),
 ('E5',16),('D5',E),('C5',E),('B4',16),('G4',16),
 ('A4',E),('C5',E),('E5',E),('A5',E),('B5',E),('A5',E),('G5',E),('E5',E),
 ('F5',16),('E5',E),('D5',E),('E5',32),
 ('F5',E),('A5',E),('F5',E),('C5',E),('E5',E),('G5',E),('E5',E),('C5',E),
 ('D5',E),('F5',E),('D5',E),('B4',E),('C5',16),('E5',16),
 ('A4',E),('B4',E),('C5',E),('D5',E),('E5',E),('G5',E),('A5',16),
 ('G5',E),('E5',E),('C5',E),('B4',E),('A4',32)]
bars = [['A3','E4','A3','E4'], ['G3','D4','G3','D4'], ['A3','E4','A3','E4'],
        ['F3','C4','E3','B3'], ['F3','C4','F3','C4'], ['G3','D4','C4','G3'],
        ['A3','E4','A3','C4'], ['G3','B3','A3','A3']]
fun_bass = [(n, 16) for b in bars for n in b]
check_len("fun", fun_lead, fun_bass)
stream("mus_fun_lead", fun_lead, 0xFF); stream("mus_fun_bass", fun_bass, 0xFF)
drums("mus_fun_drums", [(1,8),(3,8),(2,8),(3,8),(1,8),(1,8),(2,8),(3,8)], 8)

# 2) DARK - slow D minor with a creeping chromatic line
dark_lead = [
 ('D4',20),('F4',20),('A4',20),('G#4',20),
 ('A4',40),('F4',20),('E4',20),
 ('D4',20),('F4',20),('A#4',20),('A4',20),
 ('G4',30),('F4',10),('E4',20),('C#4',20),
 ('D5',20),('C5',20),('A#4',20),('A4',20),
 ('G4',20),('A#4',20),('A4',40),
 ('F4',20),('E4',20),('D4',20),('C#4',20),
 ('D4',60),('R',20)]
dark_bass = [('D3',80),('D3',40),('A2',40),('A#2',80),('A2',80),
             ('A#2',40),('F2',40),('G2',40),('C3',40),('A2',80),('D3',80)]
check_len("dark", dark_lead, dark_bass)
stream("mus_dark_lead", dark_lead, 0xFF); stream("mus_dark_bass", dark_bass, 0xFF)
drums("mus_dark_drums", [(1,10),(1,30),(2,30),(3,10)], 8)

# 3) METAL - fast E minor gallop riff, double-kick drums
metal_lead = [
 ('E4',4),('E4',4),('E4',8),('G4',8),('E4',4),('E4',4),('A4',8),('G4',8),('F#4',8),('E4',8),
 ('E4',4),('E4',4),('E4',8),('G4',8),('E4',4),('E4',4),('B4',8),('A4',8),('G4',8),('F#4',8),
 ('E5',8),('D5',8),('B4',8),('D5',8),('C5',8),('B4',8),('A4',8),('B4',8),
 ('G4',8),('A4',8),('B4',16),('E5',16),('D#5',16),
 ('B4',4),('B4',4),('B4',8),('D5',8),('B4',4),('B4',4),('E5',8),('D5',8),('C5',8),('B4',8),
 ('A4',4),('A4',4),('A4',8),('C5',8),('A4',4),('A4',4),('D5',8),('C5',8),('B4',8),('A4',8),
 ('G4',8),('F#4',8),('G4',8),('A4',8),('B4',8),('C5',8),('B4',8),('A4',8),
 ('E5',32),('B4',16),('E4',16)]
chug = lambda n, k: [(n, 6), ('R', 2)] * k
metal_bass = (chug('E2',8) + chug('E2',8) + chug('C3',4) + chug('D3',4) + chug('G2',4) + chug('B2',4)
              + chug('B2',8) + chug('A2',8) + chug('G2',4) + chug('A2',4) + chug('E2',8))
check_len("metal", metal_lead, metal_bass)
stream("mus_metal_lead", metal_lead, 0xFF); stream("mus_metal_bass", metal_bass, 0xFF)
drums("mus_metal_drums", [(1,4),(1,4),(2,4),(1,4)] * 3 + [(1,4),(2,4),(4,4),(2,4)], 8)

# 4) HIP HOP - swung boom-bap in C minor, sparse pentatonic hook
hh_lead = [
 ('R',16),('G4',9),('A#4',7),('C5',16),('R',16),
 ('D#5',9),('C5',7),('A#4',9),('G4',7),('R',32),
 ('R',16),('G#4',9),('C5',7),('D#5',16),('F5',16),
 ('G5',16),('F5',9),('D#5',7),('C5',32),
 ('R',16),('G4',9),('A#4',7),('C5',16),('R',16),
 ('D#5',9),('F5',7),('G5',9),('A#5',7),('G5',32),
 ('R',16),('G#4',9),('C5',7),('D#5',16),('F5',16),
 ('G5',9),('F5',7),('D#5',9),('C5',7),('C5',16),('R',16)]
hh_pat = [('r',9),('R',7),('r',9),('f',7),('R',9),('f',7),('r',16)]
hh_bass = bar_bass([('C3','G2'),('C3','G2'),('G#2','D#2'),('G2','D2')] * 2, hh_pat)
check_len("hiphop", hh_lead, hh_bass)
stream("mus_hh_lead", hh_lead, 0xFF); stream("mus_hh_bass", hh_bass, 0xFF)
drums("mus_hh_drums", [(1,9),(3,7),(2,9),(3,7),(3,9),(1,7),(2,9),(3,7)], 8)

win_lead = [('C5',6),('E5',6),('G5',6),('C6',24),('G5',6),('C6',30),('R',4)]
win_bass = [('C4',24),('G3',12),('C4',36),('R',6)]
stream("mus_win_lead", win_lead, 0xFE)
stream("mus_win_bass", win_bass, 0xFE)

def pulse_sfx(name, frames):          # (duty 0-3, vol 0-15, freq Hz)
    out = []
    for duty, vol, f in frames:
        p = min(0x7FF, round(CPU / (16 * f)) - 1)
        out += [(duty << 6) | 0x30 | vol, p & 0xFF, p >> 8]
    out.append(0)
    emit(name, out)
def noise_sfx(name, frames):          # (vol, period index 0-15)
    out = []
    for vol, per in frames:
        out += [0x30 | vol, per]
    out.append(0)
    emit(name, out)
pulse_sfx("sfx_jump",    [(2, 9 - i // 2, 350 + i * 60) for i in range(8)])
pulse_sfx("sfx_flap",    [(1, 6, 700 + i * 120) for i in range(4)])
pulse_sfx("sfx_pick",    [(2, 10, 1319)] * 4 + [(2, 9, 1760)] * 6)
pulse_sfx("sfx_deposit", [(2, 10, f) for f in (1047, 1047, 1047, 1319, 1319, 1319,
                                              1568, 1568, 1568, 2093, 2093, 2093, 2093)])
pulse_sfx("sfx_hitp",    [(0, 12 - i // 2, 500 - i * 20) for i in range(20)])
pulse_sfx("sfx_menu",    [(2, 8, 988)] * 3)
pulse_sfx("sfx_arm",     [(2, 10, f) for f in (523, 659, 784, 1047, 784, 1047, 1319, 1568, 1568, 2093)])
pulse_sfx("sfx_yoyo",    [(1, 8, 300 + 120 * (i % 6)) for i in range(18)])
noise_sfx("sfx_dash",    [(10 - i, 3) for i in range(9)])
noise_sfx("sfx_hit",     [(15 - i, 12) for i in range(15)])
noise_sfx("sfx_clank",   [(12, 1), (11, 1), (9, 2), (7, 2), (5, 2), (3, 2)])

cm = ["; generated ASCII -> tile map for .byte \"strings\""]
for ch, t in sorted(CHARMAP.items()):
    cm.append(f".charmap ${ord(ch):02X}, ${t:02X}   ; '{ch}'")
open(f"{OUT}/charmap.inc", "w").write("\n".join(cm) + "\n")
open(f"{OUT}/gen_data.inc", "w").write("\n".join(inc) + "\n")
print("assets written to", OUT)
