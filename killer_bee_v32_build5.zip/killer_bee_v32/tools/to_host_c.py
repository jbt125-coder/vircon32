#!/usr/bin/env python3
"""Convert the Vircon32 C dialect used by the game core into standard C so the
same gameplay code can be compiled with gcc for automated tests.
  int[4] name   -> int name[4]
  struct X {..};  -> typedef struct X {..} X;"""
import re, sys
src = open(sys.argv[1]).read()
src = re.sub(r'\b((?:const\s+)?[A-Za-z_]\w*)((?:\[[^\]\n]*\])+)\s+([A-Za-z_]\w*)', r'\1 \3\2', src)
src = re.sub(r'struct\s+(\w+)\s*\{(.*?)\};', r'typedef struct \1 {\2} \1;', src, flags=re.S)
open(sys.argv[2], 'w').write(src)
