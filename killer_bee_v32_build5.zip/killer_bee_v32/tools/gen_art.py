#!/usr/bin/env python3
"""KILLER BEE (Vircon32) - art generator.
Everything is original and drawn procedurally with PIL at 4x resolution, then
downsampled for smooth anti-aliased edges ("hand-drawn" look, no visible
pixels). Boards are rendered from the same level data as the game logic.
Outputs: assets/*.png (for png2vircon) and src/art.h (texture/region table).
The text font is rendered from DejaVu Sans Bold (free licence)."""
import os, sys, math, random
from PIL import Image, ImageDraw, ImageFilter, ImageFont
sys.path.insert(0, os.path.dirname(__file__))
import gen_levels as GL
import art_grunge as AG
import art_nes as AN

OUT = sys.argv[1] if len(sys.argv) > 1 else "assets"
SRC = sys.argv[2] if len(sys.argv) > 2 else "src"
os.makedirs(OUT, exist_ok=True)
SS = 4
CW, CH = 20, 12
FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

BLUE = (60, 130, 255); BLUE_D = (25, 60, 150); BLUE_L = (150, 195, 255)
YEL = (255, 205, 40); YEL_D = (175, 115, 10); YEL_L = (255, 240, 150)
INK = (28, 22, 30)
TEAM = [(BLUE, BLUE_D, BLUE_L), (YEL, YEL_D, YEL_L)]

def canvas(w, h, bg=(0, 0, 0, 0)):
    im = Image.new("RGBA", (w * SS, h * SS), bg)
    return im, ImageDraw.Draw(im)

def down(im):
    return im.resize((im.width // SS, im.height // SS), Image.LANCZOS)

def S(*v):
    return [int(round(a * SS)) for a in v]

def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(len(a)))

def grad_ellipse(d, box, top, bot, outline=INK, ow=1.2):
    x0, y0, x1, y1 = box
    n = 24
    for i in range(n):
        t = i / (n - 1)
        inset = t * (y1 - y0) * 0.0
        yy0 = y0 + (y1 - y0) * t * 0.5
        col = lerp(top, bot, t)
        d.ellipse(S(x0 + t * 0.6, yy0, x1 - t * 0.6, y1), fill=col)
    d.ellipse(S(x0, y0, x1, y1), outline=outline, width=int(ow * SS))

# ---------------------------------------------------------------- bees
def draw_wing(d, cx, cy, ang, length, width, alpha=170):
    pts = []
    for k in range(24):
        a = 2 * math.pi * k / 24
        x = math.cos(a) * length / 2; y = math.sin(a) * width / 2
        x += length / 2
        ca, sa = math.cos(ang), math.sin(ang)
        pts.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    d.polygon([tuple(S(*p)) for p in pts], fill=(235, 248, 255, alpha), outline=(90, 110, 140, 230))

def bee(team, queen, wing, pose="fly", walk=0):
    """One bee frame, facing right. queen: 40x40 frame, worker 24x24."""
    col, dark, light = TEAM[team]
    W = 40 if queen else 24
    im, d = canvas(W, W)
    c = W / 2
    if queen:
        bx0, by0, bx1, by1 = c - 13, c - 6, c + 10, c + 10      # abdomen
        hx, hy, hr = c + 11, c - 4, 6.0                          # head
    else:
        bx0, by0, bx1, by1 = c - 8, c - 3, c + 6, c + 7
        hx, hy, hr = c + 6.5, c - 1.5, 4.0
    dash = pose == "dash"
    # wings behind body
    wa = [-2.2, -1.75, -1.3, -1.75][wing % 4]
    if dash: wa = -2.6
    wl = 15 if queen else 9
    draw_wing(d, c - (2 if queen else 1), by0 + 1, wa, wl, wl * 0.48, 150)
    # legs (workers walk)
    if not queen or pose == "stand":
        ph = [0, 1, 0, -1][walk % 4]
        for k, lx in enumerate((-4, 0, 4) if not queen else (-6, 0, 6)):
            off = ph * (1 if k % 2 == 0 else -1) * 1.5
            d.line(S(c + lx * 0.8, by1 - 1, c + lx + off, by1 + (3 if not queen else 4)), fill=INK, width=int(1.3 * SS))
    # stinger
    sx = bx0 - (5 if queen else 3) - (3 if dash else 0)
    d.polygon([tuple(S(bx0 + 1, (by0 + by1) / 2 - 2)), tuple(S(bx0 + 1, (by0 + by1) / 2 + 2)), tuple(S(sx, (by0 + by1) / 2 + 1))],
              fill=(60, 50, 60), outline=INK)
    # abdomen with gradient and stripes
    grad_ellipse(d, (bx0, by0, bx1, by1), light, col)
    mask = Image.new("L", im.size, 0); md = ImageDraw.Draw(mask)
    md.ellipse(S(bx0 + 0.6, by0 + 0.6, bx1 - 0.6, by1 - 0.6), fill=255)
    stripes = Image.new("RGBA", im.size, (0, 0, 0, 0)); sd = ImageDraw.Draw(stripes)
    span = bx1 - bx0
    for k in range(3 if queen else 2):
        x = bx0 + span * (0.22 + 0.24 * k)
        sd.polygon([tuple(S(x, by0 - 2)), tuple(S(x + span * 0.11, by0 - 2)), tuple(S(x + span * 0.08, by1 + 2)), tuple(S(x - span * 0.03, by1 + 2))], fill=INK + (235,))
    im.paste(stripes, (0, 0), Image.composite(stripes, Image.new("RGBA", im.size, (0, 0, 0, 0)), mask))
    d = ImageDraw.Draw(im)
    d.ellipse(S(bx0, by0, bx1, by1), outline=INK, width=int(1.2 * SS))
    # shine
    d.ellipse(S(bx0 + span * 0.45, by0 + 1.2, bx0 + span * 0.75, by0 + 3.2), fill=(255, 255, 255, 150))
    # front wing
    draw_wing(d, c - (1 if queen else 0.5), by0 + 2, wa + 0.35, wl * 0.9, wl * 0.42, 190)
    # head
    d.ellipse(S(hx - hr, hy - hr, hx + hr, hy + hr), fill=(45, 38, 48), outline=INK, width=int(SS))
    d.ellipse(S(hx + hr * 0.15, hy - hr * 0.45, hx + hr * 0.75, hy + hr * 0.25), fill=(255, 255, 255))
    d.ellipse(S(hx + hr * 0.38, hy - hr * 0.25, hx + hr * 0.7, hy + hr * 0.1), fill=INK)
    # antennae
    d.line(S(hx - 1, hy - hr + 1, hx - 3, hy - hr - 4), fill=INK, width=int(1.1 * SS))
    d.line(S(hx + 1, hy - hr + 1, hx + 2, hy - hr - 4.5), fill=INK, width=int(1.1 * SS))
    d.ellipse(S(hx - 4, hy - hr - 5, hx - 2, hy - hr - 3), fill=col, outline=INK)
    d.ellipse(S(hx + 1, hy - hr - 5.5, hx + 3, hy - hr - 3.5), fill=col, outline=INK)
    if queen:
        # crown
        cx0, cy0 = hx - 5, hy - hr - 2
        pts = [(cx0, cy0 + 4), (cx0 + 1, cy0), (cx0 + 3, cy0 + 2.5), (cx0 + 5, cy0 - 1), (cx0 + 7, cy0 + 2.5), (cx0 + 9, cy0), (cx0 + 10, cy0 + 4)]
        d.polygon([tuple(S(*p)) for p in pts], fill=(255, 215, 60), outline=INK)
        d.ellipse(S(cx0 + 4.2, cy0 + 1.6, cx0 + 5.8, cy0 + 3.2), fill=(230, 40, 80))
    return down(im)

def snail(frame):
    im, d = canvas(36, 26)
    sq = [0, 1][frame % 2]
    # body
    d.rounded_rectangle(S(2, 16 - sq * 0.5, 34 + sq, 24), radius=4 * SS, fill=(150, 205, 120), outline=INK, width=int(1.2 * SS))
    d.ellipse(S(26 + sq, 9, 34 + sq, 21), fill=(150, 205, 120), outline=INK, width=int(1.2 * SS))
    for k, (ax, ay) in enumerate(((29, 9), (32, 8))):
        d.line(S(ax + sq, ay + 2, ax + 2 + sq, ay - 5), fill=INK, width=int(1.2 * SS))
        d.ellipse(S(ax + 1 + sq, ay - 7, ax + 4 + sq, ay - 4), fill=(255, 255, 255), outline=INK)
    d.ellipse(S(30 + sq, 12.5, 32 + sq, 14.5), fill=INK)
    # shell with spiral
    grad_ellipse(d, (5, 2, 26, 21), (230, 160, 90), (160, 85, 40))
    pts = []
    for k in range(60):
        a = k * 0.32; r = 9 * (1 - k / 66)
        pts.append(tuple(S(15.5 + math.cos(a) * r, 11.5 + math.sin(a) * r)))
    d.line(pts, fill=(95, 50, 25), width=int(1.3 * SS))
    d.ellipse(S(10, 4, 16, 8), fill=(255, 235, 200, 140))
    return down(im)

def berry():
    im, d = canvas(16, 16)
    d.line(S(8, 4, 9.5, 0.5), fill=(70, 120, 40), width=int(1.4 * SS))
    d.ellipse(S(9, 0, 14, 3.5), fill=(110, 190, 70), outline=INK)
    for (x, y) in ((5, 7), (11, 7), (8, 10.5), (5, 12), (11, 12), (8, 6)):
        grad_ellipse(d, (x - 3.2, y - 3.2, x + 3.2, y + 3.2), (230, 90, 150), (130, 20, 80), ow=0.9)
        d.ellipse(S(x - 1.6, y - 2, x, y - 0.6), fill=(255, 220, 240, 200))
    return down(im)

def yoyo():
    im, d = canvas(14, 14)
    grad_ellipse(d, (1, 1, 13, 13), (255, 120, 120), (190, 30, 50))
    d.ellipse(S(4.5, 4.5, 9.5, 9.5), fill=(255, 245, 230), outline=INK)
    return down(im)

def spark(k):
    im, d = canvas(40, 40)
    r = 6 + k * 5
    for a in range(10):
        ang = a * math.pi / 5 + k * 0.3
        rr = r if a % 2 == 0 else r * 0.55
        d.line(S(20, 20, 20 + math.cos(ang) * rr, 20 + math.sin(ang) * rr), fill=(255, 250, 200, 255 - k * 50), width=int((3 - k * 0.6) * SS))
    d.ellipse(S(20 - r * 0.35, 20 - r * 0.35, 20 + r * 0.35, 20 + r * 0.35), fill=(255, 255, 255, 230 - k * 60))
    return down(im)

def crown(on):
    im, d = canvas(18, 14)
    pts = [(1, 12), (2, 3), (5.5, 7), (9, 1), (12.5, 7), (16, 3), (17, 12)]
    if on:
        d.polygon([tuple(S(*p)) for p in pts], fill=(255, 210, 50), outline=INK)
        d.ellipse(S(7.5, 7, 10.5, 10), fill=(230, 40, 80))
    else:
        d.polygon([tuple(S(*p)) for p in pts], fill=(70, 60, 70, 160), outline=(40, 30, 40, 200))
    return down(im)

def meter(on):
    im, d = canvas(16, 18)
    pts = [(8, 1), (15, 5), (15, 13), (8, 17), (1, 13), (1, 5)]
    if on:
        d.polygon([tuple(S(*p)) for p in pts], fill=(255, 190, 40), outline=INK)
        d.polygon([tuple(S(*p)) for p in [(8, 4), (12, 6.5), (12, 9), (8, 7)]], fill=(255, 240, 170))
    else:
        d.polygon([tuple(S(*p)) for p in pts], fill=(60, 45, 30, 170), outline=(150, 110, 60))
    return down(im)

def shield():
    im, d = canvas(44, 44)
    d.ellipse(S(2, 2, 42, 42), outline=(170, 230, 255, 220), width=int(2 * SS), fill=(170, 230, 255, 45))
    d.arc(S(7, 6, 30, 26), 200, 280, fill=(255, 255, 255, 230), width=int(2 * SS))
    return down(im)

def marker(color, label):
    im, d = canvas(26, 22)
    d.polygon([tuple(S(*p)) for p in [(8, 14), (18, 14), (13, 21)]], fill=color, outline=INK)
    d.rounded_rectangle(S(1, 0, 25, 14), radius=4 * SS, fill=color, outline=INK, width=int(SS))
    f = ImageFont.truetype(FONT_PATH, 11 * SS)
    tw = d.textlength(label, font=f)
    d.text(((26 * SS - tw) / 2, 0.3 * SS), label, font=f, fill=(255, 255, 255), stroke_width=int(0.8 * SS), stroke_fill=INK)
    return down(im)

P_COLORS = [(235, 70, 70), (60, 200, 90), (170, 90, 230), (250, 140, 30)]

# ---------------------------------------------------------------- boards
def sky(d, w, h, top, bot):
    for y in range(h * SS):
        d.line([(0, y), (w * SS, y)], fill=lerp(top, bot, y / (h * SS)))

def hills(d, rnd, w, base, col, amp):
    pts = [(0, 360 * SS)]
    ph = rnd.random() * 6
    for x in range(0, w + 8, 8):
        y = base + math.sin(x / 70 + ph) * amp + math.sin(x / 23 + ph * 2) * amp * 0.25
        pts.append((x * SS, y * SS))
    pts.append((w * SS, 360 * SS))
    d.polygon(pts, fill=col)

def cloud(d, x, y, s):
    for (dx, dy, r) in ((0, 0, 1), (0.9, -0.35, 1.2), (1.9, 0, 0.9), (1.0, 0.25, 1.0)):
        rr = r * s
        d.ellipse(S(x + dx * s - rr, y + dy * s - rr, x + dx * s + rr, y + dy * s + rr), fill=(255, 255, 255, 200))

def plank(d, x0, x1, row, style):
    y = row * CH
    top, mid, bot = style
    d.rounded_rectangle(S(x0 + 0.5, y + 0.5, x1 - 0.5, y + PLANK + 1.5), radius=int(3 * SS), fill=mid, outline=INK, width=int(1.2 * SS))
    d.rounded_rectangle(S(x0 + 1.5, y + 0.8, x1 - 1.5, y + 3), radius=int(1.5 * SS), fill=top)
    for x in range(int(x0) + 14, int(x1) - 6, 22):
        d.line(S(x, y + 3.5, x + 3, y + PLANK), fill=bot, width=int(SS))
    # little grass tufts hanging
    for x in range(int(x0) + 6, int(x1) - 4, 9):
        d.line(S(x, y + PLANK + 1, x + 1, y + PLANK + 4), fill=(90, 150, 60), width=int(1.2 * SS))

PLANK = 6

def brick(d, c, r):
    x, y = c * CW, r * CH
    d.rectangle(S(x, y, x + CW, y + CH), fill=(150, 80, 60))
    for k in range(2):
        yy = y + k * 6
        off = 0 if (r * 2 + k) % 2 == 0 else 10
        for xx in range(x - 10 + off, x + CW, 20):
            d.rounded_rectangle(S(max(x, xx) + 0.5, yy + 0.5, min(x + CW, xx + 20) - 0.5, yy + 5.5), radius=int(1.2 * SS), fill=(190, 105, 75), outline=(110, 55, 40))

def hive(d, x, team):
    col, dark, light = TEAM[team]
    gy = 26 * CH
    cx = x + 20
    for k in range(5):
        w = 22 - abs(k - 2.4) * 3.2
        y0 = gy - 40 + k * 8
        d.rounded_rectangle(S(cx - w, y0, cx + w, y0 + 9), radius=int(4 * SS), fill=lerp((250, 205, 110), (200, 140, 50), k / 4), outline=INK, width=int(SS))
    d.ellipse(S(cx - 6, gy - 13, cx + 6, gy - 1), fill=(40, 25, 15), outline=INK)
    d.rounded_rectangle(S(cx - 11, gy - 45, cx + 11, gy - 37), radius=int(3 * SS), fill=col, outline=INK, width=int(SS))

def weapon_box(d, x, y, team):
    col, dark, light = TEAM[team]
    d.rounded_rectangle(S(x + 3, y + 1, x + 37, y + 23), radius=int(3 * SS), fill=col, outline=INK, width=int(1.4 * SS))
    d.rectangle(S(x + 6, y + 4, x + 34, y + 20), outline=dark, width=int(1.2 * SS))
    d.ellipse(S(x + 13, y + 5, x + 27, y + 19), fill=(255, 120, 120), outline=INK, width=int(SS))
    d.ellipse(S(x + 17.5, y + 9.5, x + 22.5, y + 14.5), fill=(255, 245, 230), outline=INK)

def vine(d, side, rnd):
    x = 7 if side == 0 else 633
    pts = []
    for y in range(72, 312, 4):
        pts.append(tuple(S(x + math.sin(y / 17) * 3, y)))
    d.line(pts, fill=(60, 120, 50), width=int(2.2 * SS))
    for y in range(80, 305, 22):
        xx = x + math.sin(y / 17) * 3
        sgn = 1 if (y // 22) % 2 else -1
        if side == 1: sgn = -sgn
        d.ellipse(S(xx + sgn * 2 - 3, y - 2.5, xx + sgn * 2 + 4, y + 2.5), fill=(110, 185, 80), outline=(45, 90, 35))

def board(idx, L, quiet=False):
    grid, rowidx, LL, LR, br, p = GL.build(L)[:6]
    rnd = random.Random(11 + idx)
    im, d = canvas(640, 360)
    warp = bool(L.get("side_wrap")); wrap = bool(L["shaft"]); divide = "boxes" in L
    if divide: skytop, skybot = (120, 150, 210), (235, 200, 170)
    elif wrap: skytop, skybot = (60, 70, 130), (170, 150, 200)
    else: skytop, skybot = (110, 180, 245), (215, 240, 255)
    sky(d, 640, 360, skytop, skybot)
    for k in range(6):
        cloud(d, rnd.randrange(20, 600), rnd.randrange(85, 190), rnd.randrange(7, 13))
    hills(d, rnd, 640, 255, lerp(skybot, (90, 150, 110), 0.45), 18)
    hills(d, rnd, 640, 285, lerp(skybot, (70, 130, 80), 0.7), 12)
    if quiet:      # readability: push the scenery back so bees and platforms pop
        im = AG.quiet_layer(im); d = ImageDraw.Draw(im)
    if warp:   # open sides: soft glowing seam markers
        for x in (0, 636):
            for y in range(80, 310, 14):
                d.ellipse(S(x + 1, y, x + 3, y + 3), fill=(255, 255, 255, 120))
    # ground
    shaft = L["shaft"]
    gy = 26 * CH
    for c in range(32):
        if shaft and shaft[0] <= c <= shaft[1]:
            d.rectangle(S(c * CW, gy, c * CW + CW, 360), fill=(25, 18, 30))
            continue
        d.rectangle(S(c * CW, gy, c * CW + CW, 360), fill=(120, 80, 45))
        for k in range(3):
            xx = c * CW + rnd.random() * CW; yy = gy + 12 + rnd.random() * 30
            d.ellipse(S(xx, yy, xx + 3, yy + 2), fill=(95, 60, 35))
        d.rectangle(S(c * CW, gy, c * CW + CW, gy + 5), fill=(95, 175, 70))
        for k in range(4):
            xx = c * CW + k * 5 + 1
            d.line(S(xx, gy + 5, xx + 1.5, gy + 8), fill=(70, 140, 55), width=int(1.3 * SS))
    if shaft:
        x0, x1 = shaft[0] * CW, (shaft[1] + 1) * CW
        d.line(S(x0, gy, x0, 360), fill=INK, width=int(1.5 * SS)); d.line(S(x1, gy, x1, 360), fill=INK, width=int(1.5 * SS))
        # ceiling beam with a gap over the pit
        for (a, b) in ((4 * CW, x0), (x1, 28 * CW)):
            d.rounded_rectangle(S(a, 50, b, 60), radius=int(3 * SS), fill=(130, 90, 55), outline=INK, width=int(1.2 * SS))
            d.rectangle(S(a + 2, 51, b - 2, 53), fill=(175, 130, 80))
    # platforms
    P = L["platforms"]
    styles = [((140, 215, 90), (160, 110, 60), (110, 70, 40)), ((150, 220, 100), (150, 100, 55), (100, 65, 35))]
    for row, segs in P.items():
        for a, b in segs:
            plank(d, a * CW, (b + 1) * CW, row, styles[row % 2])
    for (c, r) in L["walls"]:
        brick(d, c, r)
    for (c, r) in L.get("bumps", []):
        brick(d, c, r)
    if divide:
        for team, c in enumerate(L["boxes"]["cols"]):
            weapon_box(d, c * CW, (L["boxes"]["row"] - 2) * CH, team)
    if not L.get("bonus"):
        hive(d, 0, 0); hive(d, 600, 1)
    else:
        for (col, top, bot) in [(9, 8, 10), (22, 8, 10), (13, 8, 10), (18, 8, 10), (7, 14, 16), (24, 14, 16), (11, 14, 16), (20, 14, 16)]:
            x = col * CW + 10
            pts = [tuple(S(x + math.sin(y / 5) * 1.5, y)) for y in range(top * CH + 6, bot * CH + 2)]
            d.line(pts, fill=(60, 130, 50), width=int(2 * SS))
            for y in range(top * CH + 9, bot * CH, 6):
                d.ellipse(S(x + 1, y - 1.5, x + 5, y + 1.5), fill=(110, 185, 80))
    if not warp:
        vine(d, 0, rnd); vine(d, 1, rnd)
    # HUD banner
    d.rectangle(S(0, 0, 640, 46), fill=(45, 32, 28, 235))
    d.line(S(0, 46, 640, 46), fill=(220, 170, 70), width=int(2 * SS))
    return down(im)

def honeycomb_bg(seed, top, bot):
    im, d = canvas(640, 360)
    sky(d, 640, 360, top, bot)
    r = 22
    for row in range(-1, 12):
        for col in range(-1, 18):
            cx = col * r * 1.73 + (row % 2) * r * 0.866
            cy = row * r * 1.5
            pts = [tuple(S(cx + math.cos(math.pi / 3 * k + math.pi / 6) * (r - 2), cy + math.sin(math.pi / 3 * k + math.pi / 6) * (r - 2))) for k in range(6)]
            d.polygon(pts, outline=(255, 210, 90, 60), width=int(2 * SS))
    return down(im)

# ---------------------------------------------------------------- atlas packing
class Atlas:
    def __init__(self, size=1024):
        self.im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        self.x = self.y = 2; self.rowh = 0; self.size = size
        self.regions = []      # (name, x0, y0, x1, y1, hx, hy)
    def add(self, name, img, hot="center"):
        w, h = img.size
        if self.x + w + 2 > self.size: self.x = 2; self.y += self.rowh + 2; self.rowh = 0
        assert self.y + h < self.size, "atlas full"
        self.im.paste(img, (self.x, self.y))
        if hot == "center": hx, hy = self.x + w // 2, self.y + h // 2
        else: hx, hy = self.x, self.y
        self.regions.append((name, self.x, self.y, self.x + w - 1, self.y + h - 1, hx, hy))
        self.x += w + 2; self.rowh = max(self.rowh, h)


def honeycomb(style):
    """40x100 honeycomb with 2 x 5 hexagonal holes (hole k centre: 10+20*(k%2), 10+20*(k//2))."""
    im, d = canvas(40, 100)
    if style == "clean":
        d.rounded_rectangle(S(1, 1, 39, 99), radius=6 * SS, fill=(250, 200, 90), outline=INK, width=int(1.4 * SS))
        hole, rim = (120, 70, 25), (210, 150, 60)
    else:
        d.rounded_rectangle(S(1, 1, 39, 99), radius=4 * SS, fill=(55, 50, 58), outline=(255, 60, 160), width=int(1.4 * SS))
        hole, rim = (12, 10, 14), (120, 110, 125)
    for k in range(10):
        cx, cy = 10 + 20 * (k % 2), 10 + 20 * (k // 2)
        pts = [tuple(S(cx + 8 * math.cos(math.pi / 3 * a + math.pi / 6), cy + 8 * math.sin(math.pi / 3 * a + math.pi / 6))) for a in range(6)]
        d.polygon(pts, fill=hole, outline=rim)
    return down(im)

def hole_berry(style):
    return (AG.g_berry() if style == "grunge" else berry())

def build_sprites(style):
    A = Atlas()
    for team in (0, 1):
        tn = "BLUE" if team == 0 else "YEL"
        # wasp-like queens (curled stinger when attacking), 52x52
        for k in range(4): A.add(f"Q_{tn}_FLY{k}", AG.queen2(team, k, "fly", style))
        A.add(f"Q_{tn}_DASH", AG.queen2(team, 0, "dash", style))
        A.add(f"Q_{tn}_STAND", AG.queen2(team, 2, "stand", style))
        A.add(f"Q_{tn}_DIVE", AG.queen2(team, 1, "dive", style))
        A.add(f"Q_{tn}_STUN", AG.queen2(team, 2, "stun", style))
        for k in range(4): A.add(f"W_{tn}_WALK{k}", AG.bee(team, False, 2, "walk", k, style))
        for k in range(2): A.add(f"W_{tn}_JUMP{k}", AG.bee(team, False, k * 2, "jump", 0, style))
    g = style == "grunge"
    for k in range(2): A.add(f"SNAIL{k}", AG.g_snail(k) if g else snail(k))
    A.add("BERRY", AG.g_berry() if g else berry()); A.add("YOYO", AG.g_yoyo() if g else yoyo())
    for k in range(3): A.add(f"SPARK{k}", AG.g_spark(k) if g else spark(k))
    A.add("CROWN_ON", AG.g_crown(True) if g else crown(True)); A.add("CROWN_OFF", AG.g_crown(False) if g else crown(False))
    A.add("METER_ON", AG.g_meter(True) if g else meter(True)); A.add("METER_OFF", AG.g_meter(False) if g else meter(False))
    A.add("SHIELD", AG.g_shield() if g else shield())
    A.add("WHITE", Image.new("RGBA", (8, 8), (255, 255, 255, 255)), hot="topleft")
    A.add("HONEYCOMB", honeycomb(style), hot="topleft")
    A.add("HOLE", hole_berry(style))
    for p in range(4): A.add(f"MARK{p}", AG.g_marker(P_COLORS[p], f"P{p + 1}", FONT_PATH) if g else marker(P_COLORS[p], f"P{p + 1}"))
    for fname, size, stroke in (("SMALL", 15, 1.6), ("BIG", 40, 3.2)):
        f = ImageFont.truetype(FONT_PATH, size * SS)
        asc, desc = f.getmetrics()
        for code in range(32, 96):
            ch = chr(code)
            w = int(f.getlength(ch) / SS) + int(stroke * 2) + 2
            h = int((asc + desc) / SS) + int(stroke * 2) + 1
            im = Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
            d.text((stroke * SS + SS, stroke * SS), ch, font=f, fill=(255, 255, 255), stroke_width=int(stroke * SS), stroke_fill=INK)
            glyph = down(im)
            if g: glyph = AG.distress(glyph, code * 7 + size)
            A.add(f"F{fname}_{code}", glyph, hot="topleft")
    return A

def build_nes_sprites(clean):
    """NES CLASSIC: the original NES art at 2x, each centred in the clean set's cell
    so all three art sets share one region table."""
    A = Atlas()
    sizes = {r[0]: (r[3] - r[1] + 1, r[4] - r[2] + 1) for r in clean.regions}
    def put(name, img, hot="center"): A.add(name, AN.fit(img, sizes[name]), hot)
    for team in (0, 1):
        tn = "BLUE" if team == 0 else "YEL"
        for k in range(4): put(f"Q_{tn}_FLY{k}", AN.queen_pose(team, "fly", k))
        put(f"Q_{tn}_DASH", AN.queen_pose(team, "dash", 0)); put(f"Q_{tn}_STAND", AN.queen_pose(team, "stand", 0))
        put(f"Q_{tn}_DIVE", AN.queen_pose(team, "dive", 0)); put(f"Q_{tn}_STUN", AN.queen_pose(team, "stun", 0))
        for k in range(4): put(f"W_{tn}_WALK{k}", AN.worker(team, "walk", k))
        for k in range(2): put(f"W_{tn}_JUMP{k}", AN.worker(team, "jump", k))
    for k in range(2): put(f"SNAIL{k}", AN.snail(k))
    put("BERRY", AN.berry()); put("YOYO", AN.yoyo())
    for k in range(3): put(f"SPARK{k}", AN.spark(k))
    put("CROWN_ON", AN.crown(True)); put("CROWN_OFF", AN.crown(False))
    put("METER_ON", AN.meter(True)); put("METER_OFF", AN.meter(False))
    by_name = {r[0]: r for r in clean.regions}
    def copy(name, hot="center"):
        n, x0, y0, x1, y1, hx, hy = by_name[name]
        A.add(name, clean.im.crop((x0, y0, x1 + 1, y1 + 1)), hot)
    copy("SHIELD"); copy("WHITE", "topleft")
    put("HONEYCOMB", AN.honeycomb_frame(), "topleft"); put("HOLE", AN.berry())
    for p_ in range(4): copy(f"MARK{p_}")
    for r in clean.regions:
        if r[0].startswith("F"): copy(r[0], "topleft")
    return A

def main():
    spr = build_sprites("clean")
    gspr = build_sprites("grunge")
    nspr = build_nes_sprites(spr)
    assert [r[1:] for r in spr.regions] == [r[1:] for r in gspr.regions], "art sets must pack identically"
    assert [r[1:] for r in spr.regions] == [r[1:] for r in nspr.regions], "NES set must pack identically"
    nspr.im.save(os.path.join(OUT, "sprites_nes.png"))
    spr.im.save(os.path.join(OUT, "sprites.png"))
    gspr.im.save(os.path.join(OUT, "sprites_grunge.png"))

    def save_bgs(bgs, prefix):
        for t in range((len(bgs) + 1) // 2):
            tex = Image.new("RGBA", (1024, 1024), (0, 0, 0, 0))
            for k in range(2):
                i = t * 2 + k
                if i < len(bgs): tex.paste(bgs[i], (0, k * 360))
            tex.save(os.path.join(OUT, f"{prefix}{t}.png"))
        for i, b in enumerate(bgs): b.save(os.path.join(OUT, f"preview_{prefix}{i}.png"))

    # backgrounds per set: 5 match boards, title, team select, HOOPS bonus board (index 7)
    MATCH = [L for L in GL.LEVELS if not L.get("bonus")]
    HOOPS = [L for L in GL.LEVELS if L.get("bonus")][0]
    bgs = [board(i, L) for i, L in enumerate(MATCH)]
    bgs.append(honeycomb_bg(1, (70, 40, 20), (30, 18, 12)))
    bgs.append(honeycomb_bg(2, (35, 30, 60), (15, 12, 25)))
    bgs.append(board(5, HOOPS))
    save_bgs(bgs, "bg")
    gbgs = [AG.g_board(L, GL.build, i, CW, CH) for i, L in enumerate(MATCH)]
    gbgs.append(AG.g_menu_bg(1)); gbgs.append(AG.g_menu_bg(2))
    gbgs.append(AG.g_board(HOOPS, GL.build, 5, CW, CH))
    save_bgs(gbgs, "gbg")
    nbgs = [AN.board(L, GL.build) for L in MATCH]
    nbgs.append(AN.menu_bg()); nbgs.append(AN.menu_bg())
    nbgs.append(AN.board(HOOPS, GL.build))
    save_bgs(nbgs, "nbg")
    NBT = (len(bgs) + 1) // 2

    h = ["// generated by tools/gen_art.py - do not edit", "#ifndef ART_H", "#define ART_H",
         "// textures: art set 0 (clean) = 0..4, art set 1 (grunge) = 5..9",
         "#define TEX_PER_SET " + str(1 + NBT), f"#define NUM_BG_TEXTURES {NBT}",
         "#define BG_TITLE 5", "#define BG_SETUP 6", "#define BG_HOOPS 7", "#define ART_SET_COUNT 3", ""]
    for i, (name, *_r) in enumerate(spr.regions):
        if not name.startswith("F"): h.append(f"#define R_{name} {i}")
    small0 = [i for i, r in enumerate(spr.regions) if r[0] == "FSMALL_32"][0]
    big0 = [i for i, r in enumerate(spr.regions) if r[0] == "FBIG_32"][0]
    h.append(f"#define R_FONT_SMALL {small0}")
    h.append(f"#define R_FONT_BIG {big0}")
    adv_s = [spr.regions[small0 + k][3] - spr.regions[small0 + k][1] + 1 for k in range(64)]
    adv_b = [spr.regions[big0 + k][3] - spr.regions[big0 + k][1] + 1 for k in range(64)]
    h.append(f"int[64] font_small_w = {{ {', '.join(str(v - 3) for v in adv_s)} }};")
    h.append(f"int[64] font_big_w = {{ {', '.join(str(v - 6) for v in adv_b)} }};")
    h.append("void define_regions_for_set(int base)\n{")
    h.append("    select_texture(base);")
    for i, (name, x0, y0, x1, y1, hx, hy) in enumerate(spr.regions):
        h.append(f"    select_region({i}); define_region({x0}, {y0}, {x1}, {y1}, {hx}, {hy});")
    h.append("    int t;")
    h.append(f"    for (t = 1; t <= {NBT}; t++)\n    {{")
    h.append("        select_texture(base + t);")
    h.append("        select_region(0); define_region(0, 0, 639, 359, 0, 0);")
    h.append("        select_region(1); define_region(0, 360, 639, 719, 0, 360);")
    h.append("    }\n}")
    h.append("void define_all_regions() { define_regions_for_set(0); define_regions_for_set(TEX_PER_SET); define_regions_for_set(2 * TEX_PER_SET); }")
    h.append("#endif")
    open(os.path.join(SRC, "art.h"), "w").write("\n".join(h) + "\n")
    print("art: 2 sets x", len(spr.regions), "sprite regions;", len(bgs), "backgrounds per set")


if __name__ == "__main__":
    main()
