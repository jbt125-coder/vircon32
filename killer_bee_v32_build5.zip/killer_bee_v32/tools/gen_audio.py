#!/usr/bin/env python3
"""KILLER BEE (Vircon32) - audio generator.
All instruments, drums and sound effects are synthesized here (numpy), so the
sound is fully original and rebuilt identically every time.
The four songs keep the NES melodies (fun, dark, metal, hip hop) and add new
layers: a harmony line, sustained chords, an arpeggio and fuller drum parts.
Outputs: assets/snd_*.wav (44.1 kHz 16-bit stereo) and src/music.h."""
import os, sys, wave, math
import numpy as np

OUT = sys.argv[1] if len(sys.argv) > 1 else "assets"
SRC = sys.argv[2] if len(sys.argv) > 2 else "src"
os.makedirs(OUT, exist_ok=True)
SR = 44100
rng = np.random.default_rng(1234)

def t_(sec): return np.arange(int(SR * sec)) / SR
def hz(midi): return 440.0 * 2 ** ((midi - 69) / 12)
def env(n, a, d_rate, sustain=0.0):
    t = np.arange(n) / SR
    e = np.minimum(1.0, t / max(a, 1e-4))
    return e * (sustain + (1 - sustain) * np.exp(-t * d_rate))
def lowpass(x, cut):
    a = math.exp(-2 * math.pi * cut / SR)
    y = np.zeros_like(x); acc = 0.0
    for i in range(len(x)):
        acc = (1 - a) * x[i] + a * acc; y[i] = acc
    return y
def fade_out(x, sec=0.03):
    n = int(SR * sec); x[-n:] *= np.linspace(1, 0, n); return x
def save(name, x, gain=0.9):
    x = np.asarray(x, dtype=np.float64)
    peak = np.max(np.abs(x)) or 1.0
    x = x / peak * gain
    s = (x * 32767).astype(np.int16)
    st = np.stack([s, s], axis=1).ravel()
    with wave.open(os.path.join(OUT, f"snd_{name}.wav"), "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(st.tobytes())
def saw(f, t): return 2 * ((t * f) % 1.0) - 1
def tri(f, t): return 2 * np.abs(2 * ((t * f) % 1.0) - 1) - 1

BASE = 60            # melodic samples are recorded at middle C
BASS_BASE = 36       # bass samples at C2
f0, fb = hz(BASE), hz(BASS_BASE)

INSTR = {}
def inst(name, x, base):
    INSTR[name] = (len(INSTR), base); save(name, fade_out(x))

t = t_(1.3); inst("pluck", (sum(np.sin(2 * np.pi * f0 * k * t) / k ** 1.3 for k in range(1, 9)) * env(len(t), 0.003, 4.5)), BASE)
t = t_(0.9); inst("marimba", (np.sin(2 * np.pi * f0 * t) + 0.35 * np.sin(2 * np.pi * f0 * 4 * t) * np.exp(-t * 18)) * env(len(t), 0.002, 6), BASE)
t = t_(2.2); inst("epiano", ((np.sin(2 * np.pi * f0 * t) + 0.25 * np.sin(2 * np.pi * f0 * 2 * t) + 0.18 * np.sin(2 * np.pi * f0 * 7.1 * t) * np.exp(-t * 9))
                            * (1 + 0.15 * np.sin(2 * np.pi * 5 * t)) * env(len(t), 0.004, 1.6, 0.1)), BASE)
t = t_(3.0)
pad = sum(saw(f0 * dt, t) for dt in (1.0, 1.006, 0.994, 2.003))
inst("pad", lowpass(pad, 1600) * env(len(t), 0.35, 0.4, 0.55), BASE)
t = t_(2.0); inst("bell", sum(a * np.sin(2 * np.pi * f0 * r * t) * np.exp(-t * dcy) for r, a, dcy in ((1, 1, 2.2), (2.76, 0.5, 3.5), (5.4, 0.25, 6), (2.0, 0.3, 2.8))), BASE)
t = t_(2.0)
g = saw(f0, t) + 0.6 * saw(f0 * 1.004, t) + 0.4 * saw(f0 * 2, t)
g = np.tanh(lowpass(g, 3500) * 6) * env(len(t), 0.004, 0.6, 0.55)
inst("guitar", lowpass(g, 4200), BASE)
t = t_(0.35)
ch = saw(fb * 2, t) + 0.7 * saw(fb * 2 * 1.5, t) + 0.6 * saw(fb, t)
inst("chug", np.tanh(lowpass(ch, 1300) * 8) * env(len(t), 0.002, 14), BASS_BASE)
t = t_(1.4); inst("roundbass", (tri(fb, t) + 0.4 * np.sin(2 * np.pi * fb * 2 * t)) * env(len(t), 0.005, 2.0, 0.25), BASS_BASE)
t = t_(2.5); inst("subbass", (np.sin(2 * np.pi * fb * t) + 0.25 * np.sin(2 * np.pi * fb * 2 * t)) * env(len(t), 0.02, 0.5, 0.5), BASS_BASE)
t = t_(1.6)
ph = 2 * np.pi * np.cumsum(fb * (1 + 0.5 * np.exp(-t * 30))) / SR
inst("808", np.tanh(np.sin(ph) * 1.6) * env(len(t), 0.002, 1.6), BASS_BASE)
t = t_(1.6); inst("rhodes", ((np.sin(2 * np.pi * f0 * t) + 0.3 * np.sin(2 * np.pi * f0 * 3 * t) * np.exp(-t * 6))
                            * (1 + 0.2 * np.sin(2 * np.pi * 4 * t)) * env(len(t), 0.006, 2.2, 0.15)), BASE)

DRUM = {}
def drum(name, x):
    DRUM[name] = len(INSTR) + len(DRUM); save(name, fade_out(x))
t = t_(0.45); drum("kick", np.sin(2 * np.pi * np.cumsum(50 + 110 * np.exp(-t * 28)) / SR) * env(len(t), 0.001, 9))
t = t_(0.3); drum("snare", (0.7 * lowpass(rng.uniform(-1, 1, len(t)), 6000) + 0.5 * np.sin(2 * np.pi * 190 * t)) * env(len(t), 0.001, 16))
t = t_(0.08); n = rng.uniform(-1, 1, len(t)); drum("hat", (n - lowpass(n, 7000)) * env(len(t), 0.0005, 55))
t = t_(1.4); n = rng.uniform(-1, 1, len(t)); drum("crash", (n - lowpass(n, 3000)) * env(len(t), 0.001, 2.6))
t = t_(0.5); drum("tom", np.sin(2 * np.pi * np.cumsum(90 + 60 * np.exp(-t * 15)) / SR) * env(len(t), 0.001, 7))
t = t_(0.35); n = rng.uniform(-1, 1, len(t)); drum("boomsnare", (0.8 * lowpass(n, 3000) + 0.6 * np.sin(2 * np.pi * 160 * t)) * env(len(t), 0.002, 10))

SFX = {}
def sfx(name, x):
    SFX[name] = len(INSTR) + len(DRUM) + len(SFX); save(name, fade_out(x, 0.01), 0.8)
def cenv(parts, a, d):
    x = np.concatenate(parts); return x * env(len(x), a, d)
def sweep(f_a, f_b, sec, shape="sq", dec=6.0):
    t = t_(sec); f = np.linspace(f_a, f_b, len(t)); ph = 2 * np.pi * np.cumsum(f) / SR
    w = np.sign(np.sin(ph)) * 0.6 + 0.4 * np.sin(ph) if shape == "sq" else np.sin(ph)
    return lowpass(w, 5000) * env(len(t), 0.002, dec)
sfx("jump", sweep(300, 700, 0.16, "sq", 9))
sfx("flap", lowpass(rng.uniform(-1, 1, int(SR * 0.09)), 2500) * env(int(SR * 0.09), 0.002, 30) + 0.4 * sweep(500, 800, 0.09, "sine", 20))
sfx("pick", cenv([np.sin(2 * np.pi * 1319 * t_(0.07)), np.sin(2 * np.pi * 1760 * t_(0.15))], 0.002, 9))
sfx("deposit", cenv([np.sin(2 * np.pi * hz(m) * t_(0.07)) * 0.8 + 0.2 * saw(hz(m), t_(0.07)) for m in (72, 76, 79, 84, 84)], 0.002, 3))
sfx("hitq", sweep(520, 120, 0.5, "sq", 4))
sfx("menu", np.sin(2 * np.pi * 988 * t_(0.06)) * env(int(SR * 0.06), 0.001, 30))
t = t_(0.18); n = rng.uniform(-1, 1, len(t)); sfx("dash", lowpass(n, 4000) * env(len(t), 0.003, 12) + 0.4 * sweep(200, 900, 0.18, "sine", 10))
t = t_(0.3); n = rng.uniform(-1, 1, len(t)); sfx("hit", lowpass(n, 2500) * env(len(t), 0.001, 12) + 0.6 * np.sin(2 * np.pi * np.cumsum(180 * np.exp(-t * 8)) / SR) * env(len(t), 0.001, 10))
t = t_(0.4); sfx("clank", sum(np.sin(2 * np.pi * f * t) * np.exp(-t * d) for f, d in ((1250, 9), (1870, 11), (2650, 14), (3400, 18))))
sfx("arm", cenv([np.sin(2 * np.pi * hz(m) * t_(0.06)) for m in (60, 64, 67, 72, 67, 72, 76, 79, 84)], 0.002, 2.5))
t = t_(0.4); sfx("yoyo", np.sin(2 * np.pi * np.cumsum(380 + 160 * np.sin(2 * np.pi * 9 * t)) / SR) * env(len(t), 0.005, 4))
sfx("ride", sweep(200, 140, 0.25, "sine", 5) + 0.3 * sweep(400, 280, 0.25, "sq", 8))
sfx("lock", cenv([np.sin(2 * np.pi * 880 * t_(0.05)), np.sin(2 * np.pi * 1320 * t_(0.09))], 0.001, 12))
sfx("bump", sweep(400, 200, 0.2, "sq", 10))
t = t_(0.18); n = rng.uniform(-1, 1, len(t)); sfx("throw", lowpass(n, 3000) * env(len(t), 0.005, 14) * 0.7 + 0.5 * sweep(300, 700, 0.18, "sine", 12))
sfx("feed", cenv([np.sin(2 * np.pi * f * t_(0.06)) * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 30 * t_(0.06)))) for f in (330, 262, 392, 523)], 0.002, 5))
t = t_(0.3); n = rng.uniform(-1, 1, len(t)); sfx("dive", lowpass(n, 2500) * env(len(t), 0.01, 5) + 0.7 * sweep(1200, 250, 0.3, "sine", 4))
t = t_(0.5); sfx("stun", 0.9 * np.sin(2 * np.pi * np.cumsum(120 * np.exp(-t * 6)) / SR) * env(len(t), 0.001, 8) + 0.35 * np.sin(2 * np.pi * 1800 * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 14 * t)) * env(len(t), 0.05, 5))

# ---------------------------------------------------------------- songs
NOTE = {'C': 0, 'C#': 1, 'D': 2, 'D#': 3, 'E': 4, 'F': 5, 'F#': 6, 'G': 7, 'G#': 8, 'A': 9, 'A#': 10, 'B': 11}
def m(n):
    if n == 'R': return 0
    return 12 * (int(n[-1]) + 1) + NOTE[n[:-1]]

E = 8
fun_lead = [('A4',E),('C5',E),('E5',E),('A5',E),('G5',E),('E5',E),('C5',E),('D5',E),('E5',16),('D5',E),('C5',E),('B4',16),('G4',16),
 ('A4',E),('C5',E),('E5',E),('A5',E),('B5',E),('A5',E),('G5',E),('E5',E),('F5',16),('E5',E),('D5',E),('E5',32),
 ('F5',E),('A5',E),('F5',E),('C5',E),('E5',E),('G5',E),('E5',E),('C5',E),('D5',E),('F5',E),('D5',E),('B4',E),('C5',16),('E5',16),
 ('A4',E),('B4',E),('C5',E),('D5',E),('E5',E),('G5',E),('A5',16),('G5',E),('E5',E),('C5',E),('B4',E),('A4',32)]
bars = [['A3','E4','A3','E4'], ['G3','D4','G3','D4'], ['A3','E4','A3','E4'], ['F3','C4','E3','B3'], ['F3','C4','F3','C4'], ['G3','D4','C4','G3'], ['A3','E4','A3','C4'], ['G3','B3','A3','A3']]
fun_bass = [(n, 16) for b in bars for n in b]
dark_lead = [('D4',20),('F4',20),('A4',20),('G#4',20),('A4',40),('F4',20),('E4',20),('D4',20),('F4',20),('A#4',20),('A4',20),('G4',30),('F4',10),('E4',20),('C#4',20),
 ('D5',20),('C5',20),('A#4',20),('A4',20),('G4',20),('A#4',20),('A4',40),('F4',20),('E4',20),('D4',20),('C#4',20),('D4',60),('R',20)]
dark_bass = [('D3',80),('D3',40),('A2',40),('A#2',80),('A2',80),('A#2',40),('F2',40),('G2',40),('C3',40),('A2',80),('D3',80)]
metal_lead = [('E4',4),('E4',4),('E4',8),('G4',8),('E4',4),('E4',4),('A4',8),('G4',8),('F#4',8),('E4',8),
 ('E4',4),('E4',4),('E4',8),('G4',8),('E4',4),('E4',4),('B4',8),('A4',8),('G4',8),('F#4',8),
 ('E5',8),('D5',8),('B4',8),('D5',8),('C5',8),('B4',8),('A4',8),('B4',8),('G4',8),('A4',8),('B4',16),('E5',16),('D#5',16),
 ('B4',4),('B4',4),('B4',8),('D5',8),('B4',4),('B4',4),('E5',8),('D5',8),('C5',8),('B4',8),
 ('A4',4),('A4',4),('A4',8),('C5',8),('A4',4),('A4',4),('D5',8),('C5',8),('B4',8),('A4',8),
 ('G4',8),('F#4',8),('G4',8),('A4',8),('B4',8),('C5',8),('B4',8),('A4',8),('E5',32),('B4',16),('E4',16)]
chug = lambda n, k: [(n, 6), ('R', 2)] * k
metal_bass = chug('E2',8) + chug('E2',8) + chug('C3',4) + chug('D3',4) + chug('G2',4) + chug('B2',4) + chug('B2',8) + chug('A2',8) + chug('G2',4) + chug('A2',4) + chug('E2',8)
hh_lead = [('R',16),('G4',9),('A#4',7),('C5',16),('R',16),('D#5',9),('C5',7),('A#4',9),('G4',7),('R',32),('R',16),('G#4',9),('C5',7),('D#5',16),('F5',16),
 ('G5',16),('F5',9),('D#5',7),('C5',32),('R',16),('G4',9),('A#4',7),('C5',16),('R',16),('D#5',9),('F5',7),('G5',9),('A#5',7),('G5',32),
 ('R',16),('G#4',9),('C5',7),('D#5',16),('F5',16),('G5',9),('F5',7),('D#5',9),('C5',7),('C5',16),('R',16)]
hh_pat = [('r',9),('R',7),('r',9),('f',7),('R',9),('f',7),('r',16)]
hh_bass = []
for r_, f_ in [('C3','G2'),('C3','G2'),('G#2','D#2'),('G2','D2')] * 2:
    for w, d in hh_pat: hh_bass.append(({'r': r_, 'f': f_, 'R': 'R'}[w], d))
win_lead = [('C5',6),('E5',6),('G5',6),('C6',24),('G5',6),('C6',30),('R',4)]
win_bass = [('C4',24),('G3',12),('C4',36),('R',6)]

SCALES = {'Am': (9, [0, 2, 3, 5, 7, 8, 10]), 'Dm': (2, [0, 2, 3, 5, 7, 8, 10]), 'Em': (4, [0, 2, 3, 5, 7, 8, 10]), 'Cm': (0, [0, 2, 3, 5, 7, 8, 10])}
def diatonic(note, steps, key):
    """move `note` by `steps` scale degrees within the key (chromatic notes snap)."""
    root, sc = SCALES[key]
    pcs = [(root + s) % 12 for s in sc]
    octv, pc = divmod(note, 12)
    idx = min(range(7), key=lambda i: min((pc - pcs[i]) % 12, (pcs[i] - pc) % 12))
    j = idx + steps
    o2 = octv + j // 7
    p2 = pcs[j % 7]
    n2 = o2 * 12 + p2
    # keep the octave relation sensible
    while steps < 0 and n2 >= note: n2 -= 12
    while steps > 0 and n2 <= note: n2 += 12
    return n2

def total(seq): return sum(d for _, d in seq)
def mseq(seq): return [(m(n), d) for n, d in seq]
def harmony(lead, key, steps=-2):
    return [(diatonic(n, steps, key) if n else 0, d) for n, d in lead]
def bar_roots(bass, bar):
    """first bass note of every bar."""
    out = []; pos = 0; tl = total(bass)
    for b in range(tl // bar):
        acc = 0; root = None
        for n, d in bass:
            if acc <= b * bar < acc + d and n: root = n; break
            acc += d
        if root is None:
            for n, d in bass:
                if n: root = n; break
        out.append(root)
    return out
def chords(bass, bar, key, voice):
    roots = bar_roots(bass, bar)
    tracks = [[], [], []]
    for r in roots:
        base = r
        while base < 55: base += 12
        tones = [base, diatonic(base, 2, key), diatonic(base, 4, key)]
        for k in range(3): tracks[k].append((tones[k], bar))
    return tracks
def arpeggio(bass, bar, key, step):
    roots = bar_roots(bass, bar); out = []
    for r in roots:
        base = r
        while base < 67: base += 12
        tones = [base, diatonic(base, 2, key), diatonic(base, 4, key), base + 12]
        pat = [0, 1, 2, 3, 2, 1, 2, 1]
        for k in range(bar // step): out.append((tones[pat[k % 8]], step))
        rem = bar - (bar // step) * step
        if rem: out.append((0, rem))
    return out
def drums_seq(pattern, bars_, fill=None):
    out = []
    for b in range(bars_):
        p = fill if (fill and b == bars_ - 1) else pattern
        out += p
    return out

K, S_, H, C, T, B = DRUM["kick"], DRUM["snare"], DRUM["hat"], DRUM["crash"], DRUM["tom"], DRUM["boomsnare"]
SONGS = []
def song(name, key, bar, lead, bass, lead_i, harm_i, chord_i, bass_i, arp_i, drums_main, drums_hat, harm_vol=0.45, chord_vol=0.22, arp_vol=0.18, harm_steps=-2):
    L = mseq(lead); Bs = mseq(bass)
    tl = total(L); assert tl == total(Bs), (name, tl, total(Bs)); assert tl % bar == 0, (name, tl, bar)
    tracks = []
    tracks.append(("lead", INSTR[lead_i][0], INSTR[lead_i][1], 0.75, L, 1))
    if harm_i: tracks.append(("harm", INSTR[harm_i][0], INSTR[harm_i][1], harm_vol, harmony(L, key, harm_steps), 1))
    if chord_i:
        for k, ct in enumerate(chords(Bs, bar, key, chord_i)):
            tracks.append((f"chord{k}", INSTR[chord_i][0], INSTR[chord_i][1], chord_vol, ct, 0))
    tracks.append(("bass", INSTR[bass_i][0], INSTR[bass_i][1], 0.8, Bs, 0))
    if arp_i: tracks.append(("arp", INSTR[arp_i][0], INSTR[arp_i][1], arp_vol, arpeggio(Bs, bar, key, 8), 0))
    for dname, dseq, vol in (("drums", drums_main, 0.8), ("hats", drums_hat, 0.35)):
        assert total(dseq) == tl, (name, dname, total(dseq), tl)
        tracks.append((dname, -1, 0, vol, dseq, 0))
    SONGS.append((name, tracks))

# 1) FUN - bouncy A minor: pluck lead, marimba harmony, e-piano chords, round bass, arpeggio
song("fun", 'Am', 64, fun_lead, fun_bass, "pluck", "marimba", "epiano", "roundbass", "marimba",
     drums_seq([(K,8),(0,8),(S_,8),(0,8),(K,8),(K,8),(S_,8),(0,8)], 8, [(K,8),(0,8),(S_,8),(0,8),(T,8),(T,8),(S_,4),(S_,4),(C,8)]),
     drums_seq([(H,4)] * 16, 8), arp_vol=0.14)
# 2) DARK - slow D minor: bell lead, pad chords, sub bass, low toms
song("dark", 'Dm', 80, dark_lead, dark_bass, "bell", "pad", "pad", "subbass", None,
     drums_seq([(K,10),(K,30),(S_,30),(H,10)], 8, [(K,10),(K,30),(T,10),(T,10),(T,10),(C,10)]),
     drums_seq([(0,20),(H,20),(0,20),(H,20)], 8), harm_vol=0.2, chord_vol=0.2, harm_steps=-4)
# 3) METAL - E minor gallop: twin distorted guitars, chugging rhythm guitar, double kick + crashes
song("metal", 'Em', 64, metal_lead, metal_bass, "guitar", "guitar", None, "chug", None,
     drums_seq([(K,4),(K,4),(S_,4),(K,4)] * 3 + [(K,4),(S_,4),(C,4),(S_,4)], 8, [(K,4),(K,4),(S_,4),(K,4),(T,4),(T,4),(T,4),(T,4),(S_,4),(S_,4),(S_,4),(S_,4),(C,16)]),
     drums_seq([(C,16)] + [(H,8)] * 6, 8), harm_vol=0.4)
# 4) HIP HOP - swung C minor boom-bap: rhodes lead, e-piano chords, 808 bass, vinyl-dusty kit
song("hiphop", 'Cm', 64, hh_lead, hh_bass, "rhodes", None, "epiano", "808", None,
     drums_seq([(K,9),(0,7),(B,9),(0,7),(0,9),(K,7),(B,9),(0,7)], 8),
     drums_seq([(H,9),(H,7)] * 4, 8), chord_vol=0.2)
WIN = [("lead", INSTR["pluck"][0], BASE, 0.8, mseq(win_lead), 0), ("bass", INSTR["roundbass"][0], BASS_BASE, 0.8, mseq(win_bass), 0)]

# ---------------------------------------------------------------- music.h
data = []; tracks_tbl = []; song_tbl = []
def add_track(inst_id, base, vol, seq, transposable):
    off = len(data)
    for n, d in seq:
        data.extend([n, d])
    data.extend([-1, -1])
    tracks_tbl.extend([off, inst_id, base, int(vol * 100), transposable])
for name, tr in SONGS:
    first = len(tracks_tbl) // 5
    for (_, i, b, v, seq, tp) in tr: add_track(i, b, v, seq, tp)
    song_tbl.extend([first, len(tr)])
first = len(tracks_tbl) // 5
for (_, i, b, v, seq, tp) in WIN: add_track(i, b, v, seq, tp)
song_tbl.extend([first, len(WIN)])
h = ["// generated by tools/gen_audio.py - do not edit", "#ifndef MUSIC_H", "#define MUSIC_H",
     f"#define NUM_SONGS {len(SONGS)}", f"#define SONG_WIN {len(SONGS)}", "#define MAX_TRACKS 9"]
for k, v in SFX.items(): h.append(f"#define SND_{k.upper()} {v}")
h.append(f"#define NUM_SOUNDS {len(INSTR) + len(DRUM) + len(SFX)}")
def arr(name, a, per=24):
    s = f"int[{len(a)}] {name} =\n{{\n"
    for i in range(0, len(a), per): s += "    " + ", ".join(str(v) for v in a[i:i + per]) + ",\n"
    return s.rstrip(",\n") + "\n};"
h.append(arr("mus_data", data)); h.append(arr("mus_tracks", tracks_tbl, 5)); h.append(arr("mus_songs", song_tbl, 2))
h.append("#endif")
open(os.path.join(SRC, "music.h"), "w").write("\n".join(h) + "\n")
order = sorted(list(INSTR.items()) , key=lambda kv: kv[1][0])
names = [k for k, _ in order] + list(DRUM.keys()) + list(SFX.keys())
open(os.path.join(OUT, "sounds.txt"), "w").write("\n".join(names) + "\n")
print("audio:", len(names), "sounds,", len(SONGS), "songs +", "win jingle;", len(data), "music data words")
