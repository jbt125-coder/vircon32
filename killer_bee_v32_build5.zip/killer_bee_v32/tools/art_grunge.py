"""KILLER BEE (Vircon32) - bee skeleton shared by both art sets, and the GRUNGE
art set (punk/skate meets creepy-realistic). Every image here has exactly the
same size as its CLEAN counterpart so both atlases share one region table."""
import math, random
from PIL import Image, ImageDraw, ImageFont, ImageFilter

SS = 4
INK = (28, 22, 30)

def quiet_layer(im, sat=0.45, bright=0.62, contrast=0.72):
    """darker, greyer, flatter scenery (alpha kept)."""
    from PIL import ImageEnhance
    a = im.split()[3]
    rgb = im.convert("RGB")
    rgb = ImageEnhance.Color(rgb).enhance(sat)
    rgb = ImageEnhance.Contrast(rgb).enhance(contrast)
    rgb = ImageEnhance.Brightness(rgb).enhance(bright)
    out = rgb.convert("RGBA"); out.putalpha(a)
    return out

def outline(img, color=(10, 8, 12), thick=1):
    """bold dark outline around the sprite's silhouette (for hard-edged PS1 sprites)."""
    a = img.split()[3].point(lambda v: 255 if v >= 110 else 0)
    grown = a
    for _ in range(thick): grown = grown.filter(ImageFilter.MaxFilter(3))
    base = Image.new("RGBA", img.size, color + (0,)); base.putalpha(grown)
    base.alpha_composite(img)
    return base

def S(*v): return [int(round(a * SS)) for a in v]
def lerp(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(len(a)))
def canvas(w, h, bg=(0, 0, 0, 0)):
    im = Image.new("RGBA", (w * SS, h * SS), bg); return im, ImageDraw.Draw(im)
def down(im): return im.resize((im.width // SS, im.height // SS), Image.LANCZOS)

NEON = [((40, 170, 255), (10, 60, 140), (150, 230, 255)), ((215, 255, 40), (90, 120, 10), (245, 255, 170))]
CLEAN = [((60, 130, 255), (25, 60, 150), (150, 195, 255)), ((255, 205, 40), (175, 115, 10), (255, 240, 150))]

# ---------------------------------------------------------------- shared bee skeleton
def wing(d, cx, cy, ang, length, width, style, alpha=170):
    pts = []
    for k in range(28):
        a = 2 * math.pi * k / 28
        x = math.cos(a) * length / 2 + length / 2; y = math.sin(a) * width / 2
        ca, sa = math.cos(ang), math.sin(ang)
        pts.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    if style == "clean":
        d.polygon([tuple(S(*p)) for p in pts], fill=(235, 248, 255, alpha), outline=(90, 110, 140, 230))
    else:
        d.polygon([tuple(S(*p)) for p in pts], fill=(170, 175, 185, alpha - 40), outline=(20, 20, 24, 240))
        ca, sa = math.cos(ang), math.sin(ang)
        for k in (0.25, 0.5, 0.75):      # veins
            x1, y1 = length * k, -width * 0.35
            x2, y2 = length * (k + 0.15), width * 0.35
            d.line([tuple(S(cx + x1 * ca - y1 * sa, cy + x1 * sa + y1 * ca)), tuple(S(cx + x2 * ca - y2 * sa, cy + x2 * sa + y2 * ca))], fill=(30, 30, 36, 200), width=max(1, SS // 2))
        d.line([tuple(S(cx, cy)), tuple(S(cx + length * ca, cy + length * sa))], fill=(30, 30, 36, 220), width=max(1, SS // 2))

def abdomen_layer(W, pivot, length, height, team, style, queen, stinger_len):
    """abdomen drawn pointing LEFT from the pivot (the waist)."""
    col, dark, light = (CLEAN if style == "clean" else NEON)[team]
    im, d = canvas(W, W)
    px_, py_ = pivot
    x0, x1 = px_ - length, px_ + 1
    y0, y1 = py_ - height / 2, py_ + height / 2
    sx = x0 - stinger_len
    d.polygon([tuple(S(x0 + 1.5, py_ - 1.6)), tuple(S(x0 + 1.5, py_ + 1.6)), tuple(S(sx, py_ + 0.3))], fill=(50, 40, 50) if style == "clean" else (210, 210, 220), outline=INK)
    if style == "clean":
        for i in range(20):
            t = i / 19
            d.ellipse(S(x0 + t * 0.6, y0 + (y1 - y0) * t * 0.5, x1 - t * 0.6, y1), fill=lerp(light, col, t))
    else:
        for i in range(20):
            t = i / 19
            d.ellipse(S(x0 + t * 0.6, y0 + (y1 - y0) * t * 0.5, x1 - t * 0.6, y1), fill=lerp((70, 55, 45), (25, 18, 16), t))
    mask = Image.new("L", im.size, 0); ImageDraw.Draw(mask).ellipse(S(x0 + 0.6, y0 + 0.6, x1 - 0.6, y1 - 0.6), fill=255)
    st = Image.new("RGBA", im.size, (0, 0, 0, 0)); sd = ImageDraw.Draw(st)
    n = 3 if queen else 2
    for k in range(n):
        x = x0 + length * (0.22 + 0.24 * k)
        if style == "clean":
            sd.polygon([tuple(S(x, y0 - 2)), tuple(S(x + length * 0.11, y0 - 2)), tuple(S(x + length * 0.08, y1 + 2)), tuple(S(x - length * 0.03, y1 + 2))], fill=INK + (235,))
        else:
            sd.polygon([tuple(S(x, y0 - 2)), tuple(S(x + length * 0.1, y0 - 2)), tuple(S(x + length * 0.07, y1 + 2)), tuple(S(x - length * 0.03, y1 + 2))], fill=col + (255,))
            sd.line([tuple(S(x + length * 0.13, y0 - 1)), tuple(S(x + length * 0.1, y1 + 1))], fill=(10, 8, 8, 255), width=max(1, SS // 2))
    if style != "clean":
        rnd = random.Random(team * 7 + int(length))
        for k in range(int(length * height * 0.5)):          # hairs / grime
            hx = rnd.uniform(x0, x1); hy = rnd.uniform(y0, y1)
            sd.point(tuple(S(hx, hy)), fill=(150, 130, 110, 140))
    im.paste(st, (0, 0), Image.composite(st, Image.new("RGBA", im.size, (0, 0, 0, 0)), mask))
    d = ImageDraw.Draw(im)
    d.ellipse(S(x0, y0, x1, y1), outline=INK, width=int(1.2 * SS))
    if style == "clean":
        d.ellipse(S(x0 + length * 0.45, y0 + 1.2, x0 + length * 0.75, y0 + 3.2), fill=(255, 255, 255, 150))
    else:
        d.arc(S(x0 + 1, y0 + 0.5, x1 - 1, y1 - 0.5), 200, 300, fill=col + (200,), width=max(1, SS // 2))
    return im

def bee(team, queen, wing_k, pose="fly", walk=0, style="clean", out=None, accent_only=False):
    """One bee frame facing right. Queen 40x40, worker 24x24.
    pose: fly, stand, walk, jump, dash (abdomen curled forward, stinger leading),
    dive (stinger pointing straight down), stun (dazed, tilted)."""
    col, dark, light = (CLEAN if style == "clean" else NEON)[team]
    W = 40 if queen else 24
    c = W / 2
    k = 1.0 if queen else 0.62
    pivot = (c - 1 * k, c + 1 * k)
    alen, ahei = 22 * k, 16 * k
    hx, hy, hr = c + 9 * k, c - 4 * k, 6.0 * k
    ang = 0
    if pose == "dash": ang = 140
    if pose == "dive": ang = 90
    im, d = canvas(W, W)
    # wings (behind)
    wa = [-2.2, -1.75, -1.3, -1.75][wing_k % 4]
    if pose == "dash": wa = -2.7
    if pose == "dive": wa = -2.0
    if pose == "stun": wa = -2.4
    wl = 15 * k
    wing(d, c - 1 * k, c - 4 * k, wa, wl, wl * 0.48, style, 150)
    # legs
    legc = INK if style == "clean" else (20, 16, 16)
    ph = [0, 1, 0, -1][walk % 4]
    for i, lx in enumerate((-4, 0, 4)):
        off = ph * (1 if i % 2 == 0 else -1) * 1.5
        bx = c + lx * k * 0.9
        by = c + 5 * k
        if style == "clean":
            d.line(S(bx, by, bx + off, by + 4 * k), fill=legc, width=int(1.2 * SS))
        else:   # jointed, spiky
            kx, ky = bx + 1.5 * k + off * 0.5, by + 2.5 * k
            d.line([tuple(S(bx, by)), tuple(S(kx, ky)), tuple(S(bx - 0.5 * k + off, by + 5 * k))], fill=legc, width=int(1.0 * SS))
            d.line(S(kx, ky, kx + 1.2 * k, ky - 0.6 * k), fill=legc, width=max(1, SS // 2))
    # abdomen (rotated for dash / dive)
    ab = abdomen_layer(W, pivot, alen, ahei, team, style, queen, (6 if queen else 3.5) + (4 if pose in ("dash", "dive") else 0))
    if ang:
        ab = ab.rotate(ang, resample=Image.BICUBIC, center=(pivot[0] * SS, pivot[1] * SS))
    im.alpha_composite(ab)
    d = ImageDraw.Draw(im)
    # thorax
    tr = 5.2 * k
    tx, ty = c + 3 * k, c - 1 * k
    if style == "clean":
        d.ellipse(S(tx - tr, ty - tr, tx + tr, ty + tr), fill=lerp(dark, INK, 0.3), outline=INK, width=int(SS))
    else:
        d.ellipse(S(tx - tr, ty - tr, tx + tr, ty + tr), fill=(85, 62, 40), outline=INK, width=int(SS))
        rnd = random.Random(int(W * 3 + team))
        for i in range(40):
            a = rnd.uniform(0, 2 * math.pi); r = tr * rnd.uniform(0.5, 1.05)
            d.line(S(tx + math.cos(a) * r, ty + math.sin(a) * r, tx + math.cos(a) * (r + 1.2 * k), ty + math.sin(a) * (r + 1.2 * k)), fill=(140, 110, 70), width=max(1, SS // 2))
    # front wing
    wing(d, c, c - 3 * k, wa + 0.35, wl * 0.9, wl * 0.42, style, 190)
    # head
    if pose == "stun":
        hy += 1.5 * k
    if style == "clean":
        d.ellipse(S(hx - hr, hy - hr, hx + hr, hy + hr), fill=(45, 38, 48), outline=INK, width=int(SS))
        if pose == "stun":
            for ex in (0.15, 0.55):
                d.line(S(hx + hr * ex, hy - hr * 0.4, hx + hr * (ex + 0.35), hy + hr * 0.1), fill=(255, 255, 255), width=int(SS))
                d.line(S(hx + hr * ex, hy + hr * 0.1, hx + hr * (ex + 0.35), hy - hr * 0.4), fill=(255, 255, 255), width=int(SS))
        else:
            d.ellipse(S(hx + hr * 0.15, hy - hr * 0.45, hx + hr * 0.75, hy + hr * 0.25), fill=(255, 255, 255))
            d.ellipse(S(hx + hr * 0.38, hy - hr * 0.25, hx + hr * 0.7, hy + hr * 0.1), fill=INK)
    else:
        d.ellipse(S(hx - hr, hy - hr * 0.95, hx + hr, hy + hr), fill=(30, 24, 22), outline=INK, width=int(SS))
        # compound eye: big, faceted, glossy
        ex0, ey0, ex1, ey1 = hx - hr * 0.1, hy - hr * 0.8, hx + hr * 0.95, hy + hr * 0.55
        d.ellipse(S(ex0, ey0, ex1, ey1), fill=(120, 15, 25), outline=(10, 0, 0), width=max(1, SS // 2))
        step = 1.1 * k
        yy = ey0 + step
        row = 0
        while yy < ey1 - step * 0.5:
            xx = ex0 + step * (0.5 if row % 2 else 1.0)
            while xx < ex1 - step * 0.5:
                if ((xx - (ex0 + ex1) / 2) / ((ex1 - ex0) / 2)) ** 2 + ((yy - (ey0 + ey1) / 2) / ((ey1 - ey0) / 2)) ** 2 < 0.8:
                    d.ellipse(S(xx - 0.3 * k, yy - 0.3 * k, xx + 0.3 * k, yy + 0.3 * k), fill=(200, 40, 50))
                xx += step
            yy += step * 0.85; row += 1
        if pose == "stun":
            d.line(S(ex0 + 1, ey0 + 1, ex1 - 1, ey1 - 1), fill=(255, 255, 255), width=max(1, SS // 2))
            d.line(S(ex0 + 1, ey1 - 1, ex1 - 1, ey0 + 1), fill=(255, 255, 255), width=max(1, SS // 2))
        d.ellipse(S(ex0 + hr * 0.25, ey0 + hr * 0.15, ex0 + hr * 0.55, ey0 + hr * 0.4), fill=(255, 220, 220, 220))
        # mandibles
        d.line(S(hx + hr * 0.6, hy + hr * 0.7, hx + hr * 1.15, hy + hr * 1.05), fill=(15, 10, 10), width=int(SS))
        d.line(S(hx + hr * 0.3, hy + hr * 0.9, hx + hr * 0.85, hy + hr * 1.25), fill=(15, 10, 10), width=int(SS))
    # antennae
    acol = INK if style == "clean" else (15, 12, 12)
    d.line(S(hx - 1 * k, hy - hr + 1, hx - 3.5 * k, hy - hr - 4 * k), fill=acol, width=int(1.1 * SS))
    d.line(S(hx + 1 * k, hy - hr + 1, hx + 2.5 * k, hy - hr - 4.5 * k), fill=acol, width=int(1.1 * SS))
    if style == "clean":
        d.ellipse(S(hx - 4.5 * k, hy - hr - 5 * k, hx - 2.5 * k, hy - hr - 3 * k), fill=col, outline=INK)
        d.ellipse(S(hx + 1.5 * k, hy - hr - 5.5 * k, hx + 3.5 * k, hy - hr - 3.5 * k), fill=col, outline=INK)
    else:
        d.line(S(hx - 3.5 * k, hy - hr - 4 * k, hx - 5 * k, hy - hr - 3 * k), fill=acol, width=int(SS))
        d.line(S(hx + 2.5 * k, hy - hr - 4.5 * k, hx + 4.5 * k, hy - hr - 4 * k), fill=acol, width=int(SS))
    if queen:
        cx0, cy0 = hx - 5, hy - hr - 2
        if style == "clean":
            pts = [(cx0, cy0 + 4), (cx0 + 1, cy0), (cx0 + 3, cy0 + 2.5), (cx0 + 5, cy0 - 1), (cx0 + 7, cy0 + 2.5), (cx0 + 9, cy0), (cx0 + 10, cy0 + 4)]
            d.polygon([tuple(S(*p)) for p in pts], fill=(255, 215, 60), outline=INK)
            d.ellipse(S(cx0 + 4.2, cy0 + 1.6, cx0 + 5.8, cy0 + 3.2), fill=(230, 40, 80))
        else:   # spiked iron crown with a neon gem
            pts = [(cx0, cy0 + 4), (cx0 + 0.5, cy0 - 1.5), (cx0 + 2.5, cy0 + 2), (cx0 + 5, cy0 - 3), (cx0 + 7.5, cy0 + 2), (cx0 + 9.5, cy0 - 1.5), (cx0 + 10, cy0 + 4)]
            d.polygon([tuple(S(*p)) for p in pts], fill=(120, 120, 130), outline=(10, 10, 12))
            for rx in (1.5, 5, 8.5): d.ellipse(S(cx0 + rx - 0.4, cy0 + 2.6, cx0 + rx + 0.4, cy0 + 3.4), fill=(220, 220, 230))
            d.ellipse(S(cx0 + 4.1, cy0 + 0.5, cx0 + 5.9, cy0 + 2.3), fill=col, outline=(10, 10, 12))
    if accent_only:
        # per-player accent: antenna tips + a collar ring, white, tinted at draw time
        im, d = canvas(W, W)
        if pose == "stun": hy -= 1.5 * k
        for (ax, ay) in ((hx - 3.5 * k, hy - hr - 4 * k), (hx + 2.5 * k, hy - hr - 4.5 * k)):
            d.ellipse(S(ax - 1.6 * k, ay - 1.6 * k, ax + 1.6 * k, ay + 1.6 * k), fill=(255, 255, 255))
        d.ellipse(S(tx - tr - 0.2, ty - tr - 0.2, tx + tr + 0.2, ty + tr + 0.2), outline=(255, 255, 255), width=int(1.6 * k * SS))
        if out: return im.resize((out, out), Image.LANCZOS)
        return down(im)
    if pose == "stun":
        for i, (sx, sy) in enumerate(((hx - 6 * k, hy - hr - 6 * k), (hx + 3 * k, hy - hr - 8 * k), (hx - 1 * k, hy - hr - 10 * k))):
            star = [(sx + math.cos(a * math.pi / 5) * (2 if a % 2 == 0 else 0.9) * k, sy + math.sin(a * math.pi / 5) * (2 if a % 2 == 0 else 0.9) * k) for a in range(10)]
            d.polygon([tuple(S(*p)) for p in star], fill=(255, 240, 120) if style == "clean" else (230, 255, 60), outline=INK)
    final = out
    out = down(im) if not final else im.resize((final, final), Image.LANCZOS)
    if style != "clean":    # scratchy ink edge
        edge = out.split()[3].filter(ImageFilter.FIND_EDGES)
        dark_l = Image.new("RGBA", out.size, (8, 6, 8, 255))
        out = Image.composite(dark_l, out, edge.point(lambda v: 90 if v > 60 else 0))
    return out

# ---------------------------------------------------------------- grunge items
def g_snail(frame):
    im, d = canvas(36, 26)
    sq = frame % 2
    d.rounded_rectangle(S(2, 16 - sq * 0.5, 34 + sq, 24), radius=4 * SS, fill=(90, 110, 80), outline=(10, 12, 10), width=int(1.2 * SS))
    d.ellipse(S(26 + sq, 9, 34 + sq, 21), fill=(90, 110, 80), outline=(10, 12, 10), width=int(1.2 * SS))
    for (ax, ay) in ((29, 9), (32, 8)):
        d.line(S(ax + sq, ay + 2, ax + 2 + sq, ay - 5), fill=(10, 12, 10), width=int(1.2 * SS))
        d.ellipse(S(ax + 1 + sq, ay - 7, ax + 4 + sq, ay - 4), fill=(230, 40, 60), outline=(10, 0, 0))
    for x in range(4, 32, 4):     # slime drips
        d.line(S(x, 24, x + 0.5, 25.5), fill=(160, 255, 90, 200), width=int(SS))
    d.ellipse(S(5, 2, 26, 21), fill=(60, 55, 60), outline=(10, 10, 12), width=int(1.4 * SS))
    pts = [tuple(S(15.5 + math.cos(k * 0.32) * 9 * (1 - k / 66), 11.5 + math.sin(k * 0.32) * 9 * (1 - k / 66))) for k in range(60)]
    d.line(pts, fill=(255, 60, 160), width=int(1.3 * SS))
    for a in range(0, 360, 45):   # studs
        x, y = 15.5 + math.cos(math.radians(a)) * 8.5, 11.5 + math.sin(math.radians(a)) * 8.5
        d.ellipse(S(x - 0.9, y - 0.9, x + 0.9, y + 0.9), fill=(210, 210, 220), outline=(20, 20, 20))
    return down(im)

def g_berry():
    im, d = canvas(16, 16)
    d.line(S(8, 4, 9.5, 0.5), fill=(40, 60, 30), width=int(1.4 * SS))
    for (x, y) in ((5, 7), (11, 7), (8, 10.5), (5, 12), (11, 12), (8, 6)):
        d.ellipse(S(x - 3.2, y - 3.2, x + 3.2, y + 3.2), fill=(70, 10, 50), outline=(10, 0, 8))
        d.ellipse(S(x - 1.6, y - 2, x, y - 0.6), fill=(255, 60, 200, 230))
    d.line(S(8, 14, 8.3, 15.8), fill=(255, 60, 200), width=int(SS))
    return down(im)

def g_yoyo():
    im, d = canvas(14, 14)
    for a in range(0, 360, 45):
        d.line(S(7, 7, 7 + math.cos(math.radians(a)) * 6.8, 7 + math.sin(math.radians(a)) * 6.8), fill=(200, 200, 210), width=int(1.2 * SS))
    d.ellipse(S(2, 2, 12, 12), fill=(30, 30, 34), outline=(255, 60, 160), width=int(SS))
    d.ellipse(S(5, 5, 9, 9), fill=(255, 60, 160))
    return down(im)

def g_spark(k):
    im, d = canvas(40, 40)
    r = 6 + k * 5
    for a in range(12):
        ang = a * math.pi / 6 + k * 0.4
        rr = r if a % 2 == 0 else r * 0.5
        d.line(S(20, 20, 20 + math.cos(ang) * rr, 20 + math.sin(ang) * rr), fill=(255, 60, 160, 255 - k * 50) if a % 3 else (210, 255, 40, 255 - k * 50), width=int((3 - k * 0.6) * SS))
    return down(im)

def g_crown(on):
    im, d = canvas(18, 14)
    pts = [(1, 12), (1.5, 2), (5, 7), (9, 0.5), (13, 7), (16.5, 2), (17, 12)]
    if on:
        d.polygon([tuple(S(*p)) for p in pts], fill=(150, 150, 160), outline=(10, 10, 12))
        d.ellipse(S(7.5, 7, 10.5, 10), fill=(255, 60, 160))
    else:
        d.polygon([tuple(S(*p)) for p in pts], fill=(40, 40, 44, 150), outline=(90, 90, 100, 180))
        d.line(S(2, 3, 16, 11), fill=(255, 60, 60, 200), width=int(1.2 * SS))
    return down(im)

def g_meter(on, team_col=(215, 255, 40)):
    im, d = canvas(16, 18)
    pts = [(8, 1), (15, 5), (15, 13), (8, 17), (1, 13), (1, 5)]
    if on:
        d.polygon([tuple(S(*p)) for p in pts], fill=(255, 140, 20), outline=(10, 8, 6))
        d.line(S(5, 6, 6, 14), fill=(255, 220, 120), width=int(SS))
    else:
        d.polygon([tuple(S(*p)) for p in pts], fill=(25, 22, 22, 200), outline=(110, 100, 90))
    return down(im)

def g_shield():
    im, d = canvas(44, 44)
    for k in range(8):
        a0 = k * 45 + 8
        d.arc(S(2, 2, 42, 42), a0, a0 + 30, fill=(40, 230, 255, 230), width=int(2 * SS))
    d.ellipse(S(4, 4, 40, 40), fill=(40, 230, 255, 30))
    return down(im)

def g_marker(color, label, font_path):
    im, d = canvas(26, 22)
    d.polygon([tuple(S(*p)) for p in [(8, 14), (18, 14), (13, 21)]], fill=color, outline=(10, 10, 10))
    d.polygon([tuple(S(*p)) for p in [(1, 1), (25, 0), (24.5, 14), (1.5, 13.5)]], fill=(235, 230, 215), outline=(10, 10, 10))
    d.line(S(2, 13.5, 24, 13.8), fill=color, width=int(2 * SS))
    f = ImageFont.truetype(font_path, 11 * SS)
    tw = d.textlength(label, font=f)
    d.text(((26 * SS - tw) / 2, 0.3 * SS), label, font=f, fill=(15, 12, 12))
    return down(im)

def distress(img, seed):
    """scratch holes into a white glyph (keeps its size)."""
    rnd = random.Random(seed)
    a = img.split()[3]
    dr = ImageDraw.Draw(a)
    w, h = img.size
    for k in range(max(1, w * h // 60)):
        x, y = rnd.uniform(0, w), rnd.uniform(0, h)
        dr.line([(x, y), (x + rnd.uniform(-3, 3), y + rnd.uniform(-1, 1))], fill=0, width=1)
    out = img.copy(); out.putalpha(a)
    return out

# ---------------------------------------------------------------- grunge boards
def tag(d, rnd, x, y, col, size):
    pts = []
    for k in range(rnd.randint(5, 9)):
        pts.append(tuple(S(x + k * size * 0.45 + rnd.uniform(-2, 2), y + rnd.uniform(-size * 0.5, size * 0.5))))
    d.line(pts, fill=col, width=int(rnd.uniform(1.5, 3) * SS), joint="curve")
    for k in range(rnd.randint(1, 3)):          # drips
        px_, py_ = pts[rnd.randrange(len(pts))]
        L = rnd.uniform(4, 14)
        d.line([(px_, py_), (px_, py_ + L * SS)], fill=col, width=int(1.2 * SS))
        d.ellipse([px_ - 1.2 * SS, py_ + L * SS - 1 * SS, px_ + 1.2 * SS, py_ + L * SS + 1.5 * SS], fill=col)

def poster(d, rnd, x, y, w, h):
    col = lerp(rnd.choice([(230, 220, 200), (255, 60, 160), (210, 255, 40), (60, 200, 255)]), (30, 20, 30), 0.55)
    pts = []
    for k in range(9):
        pts.append((x + w * k / 8 + rnd.uniform(-1, 1), y + rnd.uniform(-2, 2)))
    for k in range(9):
        pts.append((x + w - rnd.uniform(0, 3), y + h * k / 8))
    for k in range(9):
        pts.append((x + w - w * k / 8 + rnd.uniform(-1, 1), y + h + rnd.uniform(-3, 3)))
    for k in range(9):
        pts.append((x + rnd.uniform(0, 3), y + h - h * k / 8))
    d.polygon([tuple(S(*p)) for p in pts], fill=col + (110,), outline=(10, 10, 10, 120))
    for k in range(3):
        yy = y + 4 + k * h / 4
        d.line(S(x + 3, yy, x + w - 4 - rnd.uniform(0, w / 3), yy), fill=(10, 10, 10, 110), width=int(1.4 * SS))

def g_board(L, build, idx, CW, CH, team_neon=NEON, quiet=False):
    grid, rowidx, LL, LR, br, p = build(L)[:6]
    rnd = random.Random(500 + idx)
    im, d = canvas(640, 360)
    warp = bool(L.get("side_wrap")); wrap = bool(L["shaft"]); divide = "boxes" in L
    top = (35, 12, 45) if not divide else (45, 10, 20)
    for y in range(360 * SS):
        d.line([(0, y), (640 * SS, y)], fill=lerp(top, (12, 10, 14), y / (360 * SS)))
    # brick wall texture, faint
    for row in range(5, 26):
        yy = row * 12
        off = 10 if row % 2 else 0
        for xx in range(-off, 640, 24):
            d.rectangle(S(xx + 1, yy + 1, xx + 23, yy + 11), outline=(60, 45, 60, 70), width=max(1, SS // 2))
    # chain-link fence, lower half
    for x in range(-200, 640, 14):
        d.line(S(x, 190, x + 120, 312), fill=(120, 120, 140, 45), width=max(1, SS // 2))
        d.line(S(x + 120, 190, x, 312), fill=(120, 120, 140, 45), width=max(1, SS // 2))
    for k in range(5): poster(d, rnd, rnd.uniform(30, 560), rnd.uniform(70, 230), rnd.uniform(40, 70), rnd.uniform(30, 55))
    neon = [(255, 60, 160), (210, 255, 40), (60, 220, 255), (255, 140, 30), (180, 90, 255)]
    for k in range(14): tag(d, rnd, rnd.uniform(10, 580), rnd.uniform(80, 290), rnd.choice(neon) + (150,), rnd.uniform(6, 14))
    if quiet:
        im = quiet_layer(im, sat=0.55, bright=0.55, contrast=0.6); d = ImageDraw.Draw(im)
    if warp:
        for x in (1, 637):
            for y in range(80, 310, 10):
                d.rectangle(S(x, y, x + 2, y + 5), fill=(255, 60, 160, 200))
    shaft = L["shaft"]
    gy = 26 * CH
    # asphalt ground
    for c in range(32):
        if shaft and shaft[0] <= c <= shaft[1]:
            d.rectangle(S(c * CW, gy, c * CW + CW, 360), fill=(5, 5, 8))
            continue
        d.rectangle(S(c * CW, gy, c * CW + CW, 360), fill=(48, 46, 50))
        for k in range(5):
            xx = c * CW + rnd.random() * CW; yy = gy + 6 + rnd.random() * 40
            d.ellipse(S(xx, yy, xx + 1.5, yy + 1.2), fill=(80, 78, 84))
        d.rectangle(S(c * CW, gy, c * CW + CW, gy + 3), fill=(90, 88, 95))
        if c % 3 == 0:
            d.line(S(c * CW + rnd.uniform(0, 10), gy + 3, c * CW + rnd.uniform(5, 18), gy + 20), fill=(20, 20, 22), width=int(SS))
    d.line(S(0, gy + 24, 640, gy + 24), fill=(230, 200, 40, 160), width=int(2 * SS))
    if shaft:
        x0, x1 = shaft[0] * CW, (shaft[1] + 1) * CW
        for x in range(int(x0), int(x1), 10):
            d.polygon([tuple(S(x, gy)), tuple(S(x + 5, gy)), tuple(S(x + 10, gy + 5)), tuple(S(x + 5, gy + 5))], fill=(230, 200, 40))
        for (a, b) in ((4 * CW, x0), (x1, 28 * CW)):      # rusty girder ceiling
            d.rectangle(S(a, 50, b, 60), fill=(110, 60, 35), outline=(15, 10, 8), width=int(1.2 * SS))
            for x in range(int(a) + 6, int(b) - 3, 16):
                d.ellipse(S(x - 1.2, 53.8, x + 1.2, 56.2), fill=(170, 140, 120))
    # skate-deck platforms: grip tape, neon underside, wheels
    for row, segs in L["platforms"].items():
        for a, b in segs:
            x0, x1, y = a * CW, (b + 1) * CW, row * CH
            ncol = neon[(row + a) % len(neon)]
            d.rounded_rectangle(S(x0 - 0.5, y + 4, x1 + 0.5, y + 9), radius=int(3 * SS), fill=ncol + (60,))      # neon glow
            d.rounded_rectangle(S(x0 + 0.5, y + 0.5, x1 - 0.5, y + 6.5), radius=int(3.2 * SS), fill=ncol, outline=(8, 8, 8), width=int(1.2 * SS))
            d.rounded_rectangle(S(x0 + 1.2, y + 0.7, x1 - 1.2, y + 3.6), radius=int(2 * SS), fill=(78, 78, 86))
            d.line(S(x0 + 3, y + 0.9, x1 - 3, y + 0.9), fill=(170, 170, 180), width=max(1, SS // 2))
            for k in range(int((x1 - x0) * 0.8)):
                gx = rnd.uniform(x0 + 2, x1 - 2)
                d.point(tuple(S(gx, rnd.uniform(y + 1.2, y + 3.2))), fill=(40, 40, 46))
            for wx in (x0 + 8, x1 - 8):
                d.ellipse(S(wx - 2.2, y + 6.5, wx + 2.2, y + 10.5), fill=(235, 230, 210), outline=(10, 10, 10))
    for (c, r) in L["walls"] + L.get("bumps", []):          # cinderblocks
        x, y = c * CW, r * CH
        d.rectangle(S(x, y, x + CW, y + CH), fill=(95, 95, 100), outline=(30, 30, 34), width=int(SS))
        d.rectangle(S(x + 4, y + 3, x + 8, y + 9), fill=(55, 55, 60)); d.rectangle(S(x + 12, y + 3, x + 16, y + 9), fill=(55, 55, 60))
    if L["walls"]:
        xs = [c for c, r in L["walls"]]; ys = [r for c, r in L["walls"]]
        tag(d, rnd, min(xs) * CW + 4, (min(ys) + max(ys)) / 2 * CH, (255, 60, 160), 8)
    if divide:
        for team, c in enumerate(L["boxes"]["cols"]):
            x, y = c * CW, (L["boxes"]["row"] - 2) * CH
            col = team_neon[team][0]
            d.rectangle(S(x + 3, y + 1, x + 37, y + 23), fill=(70, 50, 35), outline=(10, 8, 6), width=int(1.4 * SS))
            d.line(S(x + 3, y + 1, x + 37, y + 23), fill=(45, 30, 20), width=int(1.4 * SS))
            d.line(S(x + 37, y + 1, x + 3, y + 23), fill=(45, 30, 20), width=int(1.4 * SS))
            d.ellipse(S(x + 13, y + 5, x + 27, y + 19), fill=(30, 30, 34), outline=col, width=int(1.5 * SS))
            d.ellipse(S(x + 18, y + 10, x + 22, y + 14), fill=col)
    if L.get("bonus"):
        for (col, top, bot) in [(9, 8, 10), (22, 8, 10), (13, 8, 10), (18, 8, 10), (7, 14, 16), (24, 14, 16), (11, 14, 16), (20, 14, 16)]:
            x = col * CW + 10
            d.line([tuple(S(x + math.sin(y / 4) * 1.5, y)) for y in range(top * CH + 6, bot * CH + 2)], fill=(25, 35, 25), width=int(2.4 * SS))
            for y in range(top * CH + 9, bot * CH, 7):
                d.ellipse(S(x + 1, y - 1.5, x + 5, y + 1.5), fill=(150, 255, 60))
    # oil-drum hives
    for team, hx in ((0, 0), (1, 600)):
        if L.get("bonus"): break
        col = team_neon[team][0]
        cx = hx + 20
        d.rounded_rectangle(S(cx - 17, gy - 40, cx + 17, gy), radius=int(3 * SS), fill=(90, 50, 30), outline=(10, 8, 6), width=int(1.4 * SS))
        for yy in (gy - 30, gy - 12):
            d.line(S(cx - 17, yy, cx + 17, yy), fill=(50, 28, 18), width=int(1.6 * SS))
        tag(d, rnd, cx - 13, gy - 21, col, 5)
        d.ellipse(S(cx - 6, gy - 12, cx + 6, gy - 2), fill=(5, 5, 5), outline=(10, 8, 6))
        d.rectangle(S(cx - 14, gy - 45, cx + 14, gy - 39), fill=col, outline=(10, 10, 10))
    # thorny vines with barbed wire on solid-sided boards
    if not warp:
        for side in (0, 1):
            x = 7 if side == 0 else 633
            pts = [tuple(S(x + math.sin(y / 13) * 3, y)) for y in range(72, 312, 3)]
            d.line(pts, fill=(25, 35, 25), width=int(2.6 * SS))
            for y in range(76, 308, 9):
                xx = x + math.sin(y / 13) * 3
                sgn = 1 if (y // 9) % 2 else -1
                d.line(S(xx, y, xx + sgn * 3, y - 2), fill=(15, 15, 15), width=int(SS))
            for y in range(84, 305, 26):
                xx = x + math.sin(y / 13) * 3
                sgn = (1 if (y // 26) % 2 else -1) * (1 if side == 0 else -1)
                d.ellipse(S(xx + sgn * 2 - 3, y - 2, xx + sgn * 2 + 3, y + 2), fill=(150, 255, 60), outline=(20, 40, 15))
            for y in range(90, 300, 18):
                d.line(S(x - 3, y, x + 3, y + 3), fill=(170, 170, 180), width=max(1, SS // 2))
                d.line(S(x + 3, y, x - 3, y + 3), fill=(170, 170, 180), width=max(1, SS // 2))
    # duct-tape HUD strip
    d.polygon([tuple(S(*p)) for p in [(0, 0), (640, 0), (640, 45), (600, 47), (420, 44), (200, 47), (0, 45)]], fill=(18, 18, 20, 245))
    for k in range(40):
        x = rnd.uniform(0, 640)
        d.line(S(x, 1, x + rnd.uniform(5, 20), 1 + rnd.uniform(0, 2)), fill=(45, 45, 50), width=max(1, SS // 2))
    d.line(S(0, 46, 640, 46), fill=(255, 60, 160), width=int(2 * SS))
    return down(im)

def g_menu_bg(seed):
    rnd = random.Random(seed)
    im, d = canvas(640, 360)
    for y in range(360 * SS):
        d.line([(0, y), (640 * SS, y)], fill=lerp((22, 10, 28), (6, 6, 8), y / (360 * SS)))
    for row in range(0, 30):
        yy = row * 12; off = 10 if row % 2 else 0
        for xx in range(-off, 640, 24):
            d.rectangle(S(xx + 1, yy + 1, xx + 23, yy + 11), outline=(55, 40, 55, 80), width=max(1, SS // 2))
    neon = [(255, 60, 160), (210, 255, 40), (60, 220, 255), (255, 140, 30), (180, 90, 255)]
    for k in range(6): poster(d, rnd, rnd.uniform(10, 580), rnd.uniform(10, 300), rnd.uniform(40, 80), rnd.uniform(30, 60))
    for k in range(26): tag(d, rnd, rnd.uniform(0, 600), rnd.uniform(10, 340), rnd.choice(neon) + (110,), rnd.uniform(6, 16))
    return down(im)


# ---------------------------------------------------------------- wasp-like queen (v2)
QW2 = 52   # queen frame size (longer body needs more room than the 40px original)

def _wasp_abdomen(W, P, L, H, team, style, stinger, sting_w, glint):
    """long tapered abdomen pointing LEFT from the waist P, stinger at the tip."""
    col, dark, light = (CLEAN if style == "clean" else NEON)[team]
    im, d = canvas(W, W)
    px_, py_ = P
    x_front = px_ - 2.5                      # after the narrow petiole
    # petiole (thin waist)
    d.rounded_rectangle(S(x_front - 0.5, py_ - 1.3, px_ + 0.5, py_ + 1.3), radius=SS, fill=(40, 32, 40) if style == "clean" else (25, 20, 18), outline=INK)
    top, bot = [], []
    N = 28
    for i in range(N + 1):
        t = i / N
        h = H / 2 * (math.sin(math.pi * min(1, 0.12 + t * 0.95)) ** 0.85)
        x = x_front - t * L
        top.append((x, py_ - h)); bot.append((x, py_ + h))
    poly = top + bot[::-1]
    tip_x = x_front - L
    # stinger (behind the body outline so it reads as attached)
    sx = tip_x - stinger
    d.polygon([tuple(S(tip_x + 2.0, py_ - sting_w / 2)), tuple(S(tip_x + 2.0, py_ + sting_w / 2)), tuple(S(sx, py_ + 0.2))],
              fill=(225, 225, 235) if glint else ((50, 40, 50) if style == "clean" else (200, 200, 210)), outline=INK, width=int((1.2 if glint else 0.8) * SS))
    if glint:
        d.line(S(tip_x + 1, py_ - sting_w * 0.2, sx + 2, py_), fill=(255, 255, 255), width=max(1, int(0.8 * SS)))
    # body with shading
    mask = Image.new("L", im.size, 0); ImageDraw.Draw(mask).polygon([tuple(S(*p)) for p in poly], fill=255)
    body = Image.new("RGBA", im.size, (0, 0, 0, 0)); bd = ImageDraw.Draw(body)
    for i in range(24):
        t = i / 23
        c0 = lerp(light, col, t) if style == "clean" else lerp((75, 58, 46), (22, 16, 14), t)
        y0 = py_ - H / 2 + H * t
        bd.rectangle(S(tip_x - 1, y0, x_front + 1, y0 + H / 23 + 0.5), fill=c0)
    for k in range(4):                        # stripes / neon bands
        x = x_front - L * (0.16 + 0.2 * k)
        w_ = L * 0.075
        bd.polygon([tuple(S(x, py_ - H)), tuple(S(x - w_, py_ - H)), tuple(S(x - w_ * 1.3, py_ + H)), tuple(S(x - w_ * 0.3, py_ + H))],
                   fill=(INK + (235,)) if style == "clean" else (col + (255,)))
    if style != "clean":
        rnd = random.Random(team * 11 + 5)
        for k in range(160):
            bd.point(tuple(S(rnd.uniform(tip_x, x_front), rnd.uniform(py_ - H / 2, py_ + H / 2))), fill=(150, 130, 110, 140))
    im.paste(body, (0, 0), Image.composite(body, Image.new("RGBA", im.size, (0, 0, 0, 0)), mask))
    d = ImageDraw.Draw(im)
    d.line([tuple(S(*p)) for p in poly + [poly[0]]], fill=INK, width=int(1.2 * SS))
    if style == "clean":
        d.line([tuple(S(x, y + 1.2)) for (x, y) in top[3:N - 6]], fill=(255, 255, 255, 150), width=int(0.9 * SS))
    return im

def queen2(team, wing_k, pose="fly", style="clean", out=None, accent_only=False):
    """Wasp-like queen, facing right, 52x52. Poses: fly, stand, dash (abdomen
    curled under, big stinger pointing forward), dive (stinger straight down),
    stun."""
    col, dark, light = (CLEAN if style == "clean" else NEON)[team]
    W = QW2
    oy = -6 if pose == "dive" else 0
    ox = -4 if pose == "dash" else 0          # make room for the forward stinger
    P = (25 + ox, 27 + oy)                    # waist
    tx, ty, tr = 30.5 + ox, 24.5 + oy, 5.4    # thorax
    hx, hy, hr = 38.8 + ox, 21 + oy, 6.2      # head
    if pose == "stun": hy += 1.5
    if accent_only:
        im, d = canvas(W, W)
        for (ax, ay) in ((hx - 3.5, hy - hr - 4), (hx + 2.5, hy - hr - 4.5)):
            d.ellipse(S(ax - 1.6, ay - 1.6, ax + 1.6, ay + 1.6), fill=(255, 255, 255))
        d.ellipse(S(tx - tr - 0.2, ty - tr - 0.2, tx + tr + 0.2, ty + tr + 0.2), outline=(255, 255, 255), width=int(1.6 * SS))
        return im.resize((out, out), Image.LANCZOS) if out else down(im)
    im, d = canvas(W, W)
    # wings: long and narrow, swept back over the abdomen
    wa = [-2.45, -2.05, -1.7, -2.05][wing_k % 4]
    if pose == "dash": wa = -2.75
    if pose == "dive": wa = -1.9
    if pose == "stun": wa = -2.6
    wing(d, tx - 1, ty - 4, wa, 19, 6.5, style, 150)
    # legs (thin, wasp-like, dangling)
    legc = INK if style == "clean" else (20, 16, 16)
    for i, lx in enumerate((-3, 0, 3)):
        bx, by = tx + lx, ty + tr - 1
        d.line([tuple(S(bx, by)), tuple(S(bx + 1.5 + i * 0.5, by + 3)), tuple(S(bx - 0.5 + i, by + 6.5))], fill=legc, width=int(1.0 * SS))
    # abdomen: normal (pointing back), dash (curled under, stinger forward), dive (down)
    attack = pose in ("dash", "dive")
    # draw on a double-size canvas so the stinger is never clipped before rotating
    m = W // 2
    PP = (P[0] + m, P[1] + m)
    if attack: big = _wasp_abdomen(W * 2, PP, 17.5, 13.5, team, style, 13.0, 4.6, True)
    else: big = _wasp_abdomen(W * 2, PP, 21, 13.5, team, style, 4.5, 2.4, False)
    ang = {"dash": 152, "dive": 90}.get(pose, 0)
    if ang: big = big.rotate(ang, resample=Image.BICUBIC, center=(PP[0] * SS, PP[1] * SS))
    ab = big.crop((m * SS, m * SS, (m + W) * SS, (m + W) * SS))
    im.alpha_composite(ab); d = ImageDraw.Draw(im)
    # thorax
    if style == "clean":
        d.ellipse(S(tx - tr, ty - tr, tx + tr, ty + tr), fill=lerp(dark, INK, 0.3), outline=INK, width=int(SS))
        d.arc(S(tx - tr + 1, ty - tr + 1, tx + tr - 1, ty + tr - 1), 200, 280, fill=col, width=int(1.1 * SS))
    else:
        d.ellipse(S(tx - tr, ty - tr, tx + tr, ty + tr), fill=(85, 62, 40), outline=INK, width=int(SS))
        rnd = random.Random(77 + team)
        for i in range(40):
            a = rnd.uniform(0, 2 * math.pi); r = tr * rnd.uniform(0.5, 1.05)
            d.line(S(tx + math.cos(a) * r, ty + math.sin(a) * r, tx + math.cos(a) * (r + 1.2), ty + math.sin(a) * (r + 1.2)), fill=(140, 110, 70), width=max(1, SS // 2))
    # front wing
    wing(d, tx, ty - 3, wa + 0.3, 17, 5.8, style, 190)
    # head (slightly elongated, wasp-like) with eyes per style
    d.ellipse(S(hx - hr, hy - hr * 0.95, hx + hr * 1.05, hy + hr), fill=(45, 38, 48) if style == "clean" else (30, 24, 22), outline=INK, width=int(SS))
    if style == "clean":
        if pose == "stun":
            for ex in (0.15, 0.55):
                d.line(S(hx + hr * ex, hy - hr * 0.4, hx + hr * (ex + 0.35), hy + hr * 0.1), fill=(255, 255, 255), width=int(SS))
                d.line(S(hx + hr * ex, hy + hr * 0.1, hx + hr * (ex + 0.35), hy - hr * 0.4), fill=(255, 255, 255), width=int(SS))
        else:
            d.ellipse(S(hx + hr * 0.1, hy - hr * 0.5, hx + hr * 0.8, hy + hr * 0.25), fill=(255, 255, 255))
            d.ellipse(S(hx + hr * 0.38, hy - hr * 0.3, hx + hr * 0.74, hy + hr * 0.08), fill=INK)
            d.line(S(hx + hr * 0.05, hy - hr * 0.62, hx + hr * 0.85, hy - hr * 0.42), fill=INK, width=int(1.1 * SS))   # stern brow
    else:
        ex0, ey0, ex1, ey1 = hx - hr * 0.1, hy - hr * 0.8, hx + hr * 0.95, hy + hr * 0.55
        d.ellipse(S(ex0, ey0, ex1, ey1), fill=(120, 15, 25), outline=(10, 0, 0), width=max(1, SS // 2))
        yy = ey0 + 1.1; row = 0
        while yy < ey1 - 0.6:
            xx = ex0 + 1.1 * (0.5 if row % 2 else 1.0)
            while xx < ex1 - 0.6:
                if ((xx - (ex0 + ex1) / 2) / ((ex1 - ex0) / 2)) ** 2 + ((yy - (ey0 + ey1) / 2) / ((ey1 - ey0) / 2)) ** 2 < 0.8:
                    d.ellipse(S(xx - 0.3, yy - 0.3, xx + 0.3, yy + 0.3), fill=(200, 40, 50))
                xx += 1.1
            yy += 0.95; row += 1
        if pose == "stun":
            d.line(S(ex0 + 1, ey0 + 1, ex1 - 1, ey1 - 1), fill=(255, 255, 255), width=max(1, SS // 2))
            d.line(S(ex0 + 1, ey1 - 1, ex1 - 1, ey0 + 1), fill=(255, 255, 255), width=max(1, SS // 2))
        d.ellipse(S(ex0 + hr * 0.25, ey0 + hr * 0.15, ex0 + hr * 0.55, ey0 + hr * 0.4), fill=(255, 220, 220, 220))
    # mandibles
    d.line(S(hx + hr * 0.65, hy + hr * 0.7, hx + hr * 1.25, hy + hr * 1.05), fill=(15, 10, 10), width=int(SS))
    # antennae
    acol = INK if style == "clean" else (15, 12, 12)
    d.line(S(hx - 1, hy - hr + 1, hx - 3.5, hy - hr - 4), fill=acol, width=int(1.1 * SS))
    d.line(S(hx + 1, hy - hr + 1, hx + 2.5, hy - hr - 4.5), fill=acol, width=int(1.1 * SS))
    if style == "clean":
        d.ellipse(S(hx - 4.5, hy - hr - 5, hx - 2.5, hy - hr - 3), fill=col, outline=INK)
        d.ellipse(S(hx + 1.5, hy - hr - 5.5, hx + 3.5, hy - hr - 3.5), fill=col, outline=INK)
    # crown
    cx0, cy0 = hx - 5.5, hy - hr - 2.5
    if style == "clean":
        pts = [(cx0, cy0 + 4), (cx0 + 1, cy0 - 0.5), (cx0 + 3, cy0 + 2.5), (cx0 + 5.5, cy0 - 1.5), (cx0 + 8, cy0 + 2.5), (cx0 + 10, cy0 - 0.5), (cx0 + 11, cy0 + 4)]
        d.polygon([tuple(S(*p)) for p in pts], fill=(255, 215, 60), outline=INK)
        d.ellipse(S(cx0 + 4.6, cy0 + 1.4, cx0 + 6.4, cy0 + 3.2), fill=(230, 40, 80))
    else:
        pts = [(cx0, cy0 + 4), (cx0 + 0.5, cy0 - 2), (cx0 + 2.7, cy0 + 2), (cx0 + 5.5, cy0 - 3.5), (cx0 + 8.3, cy0 + 2), (cx0 + 10.5, cy0 - 2), (cx0 + 11, cy0 + 4)]
        d.polygon([tuple(S(*p)) for p in pts], fill=(120, 120, 130), outline=(10, 10, 12))
        d.ellipse(S(cx0 + 4.6, cy0 + 0.4, cx0 + 6.4, cy0 + 2.2), fill=col, outline=(10, 10, 12))
    if pose == "stun":
        for (sx, sy) in ((hx - 7, hy - hr - 6), (hx + 3, hy - hr - 9), (hx - 2, hy - hr - 11)):
            star = [(sx + math.cos(a * math.pi / 5) * (2 if a % 2 == 0 else 0.9), sy + math.sin(a * math.pi / 5) * (2 if a % 2 == 0 else 0.9)) for a in range(10)]
            d.polygon([tuple(S(*p)) for p in star], fill=(255, 240, 120) if style == "clean" else (230, 255, 60), outline=INK)
    o = im.resize((out, out), Image.LANCZOS) if out else down(im)
    if style != "clean":
        edge = o.split()[3].filter(ImageFilter.FIND_EDGES)
        o = Image.composite(Image.new("RGBA", o.size, (8, 6, 8, 255)), o, edge.point(lambda v: 90 if v > 60 else 0))
    return o
