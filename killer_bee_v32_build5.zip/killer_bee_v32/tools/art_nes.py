"""KILLER BEE (Vircon32) - NES CLASSIC art set.
Uses the original NES game's own tile art (tools/nes_original/gen_assets.py,
the 8x8 ASCII tiles) and palettes (tools/nes_original/main.s), drawn at exactly
2x so every NES pixel is a crisp 2x2 square. Boards are built from the NES
tiles; their repeating patterns tile across the wider Vircon32 board."""
import os, sys, tempfile
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------- load the NES tiles
def _load_tiles():
    src = open(os.path.join(HERE, "nes_original", "gen_assets.py")).read()
    src = src[:src.index("\nchr_bytes = bytearray()")]      # tile definitions only
    ns = {"__name__": "nes_tiles"}
    argv = sys.argv; sys.argv = ["x", tempfile.mkdtemp()]
    try: exec(compile(src, "nes_gen_assets", "exec"), ns)
    finally: sys.argv = argv
    return ns["tiles"], ns
TILES, NS = _load_tiles()

# standard NES palette (2C02, as used by common emulators)
NESPAL = [0x7C7C7C,0x0000FC,0x0000BC,0x4428BC,0x940084,0xA80020,0xA81000,0x881400,0x503000,0x007800,0x006800,0x005800,0x004058,0x000000,0x000000,0x000000,
          0xBCBCBC,0x0078F8,0x0058F8,0x6844FC,0xD800CC,0xE40058,0xF83800,0xE45C10,0xAC7C00,0x00B800,0x00A800,0x00A844,0x008888,0x000000,0x000000,0x000000,
          0xF8F8F8,0x3CBCFC,0x6888FC,0x9878F8,0xF878F8,0xF85898,0xF87858,0xFCA044,0xF8B800,0xB8F818,0x58D854,0x58F898,0x00E8D8,0x787878,0x000000,0x000000,
          0xFCFCFC,0xA4E4FC,0xB8B8F8,0xD8B8F8,0xF8B8F8,0xF8A4C0,0xF0D0B0,0xFCE0A8,0xF8D878,0xD8F878,0xB8F8B8,0xB8F8D8,0x00FCFC,0xF8D8F8,0x000000,0x000000]
def rgb(i): v = NESPAL[i]; return ((v >> 16) & 255, (v >> 8) & 255, v & 255)
# the NES game's palettes (main.s "palettes:")
BG = [[0x0F, 0x07, 0x17, 0x2A], [0x0F, 0x01, 0x21, 0x30], [0x0F, 0x17, 0x28, 0x30], [0x0F, 0x14, 0x25, 0x30]]
SP = [[0x0F, 0x21, 0x30, 0x0F], [0x0F, 0x28, 0x30, 0x0F], [0x0F, 0x27, 0x2A, 0x0F], [0x0F, 0x16, 0x30, 0x0F]]
TEAM_SP = (SP[0], SP[1])
BLACK = rgb(0x0F)

def tile_img(idx, pal, transparent=True, flip=False):
    im = Image.new("RGBA", (8, 8), (0, 0, 0, 0)); p = im.load()
    for y in range(8):
        for x in range(8):
            v = TILES[idx][y][x]
            if v == 0 and transparent: continue
            p[x, y] = rgb(pal[v]) + (255,)
    if flip: im = im.transpose(Image.FLIP_LEFT_RIGHT)
    return im

def art_img(rows, pal):
    """ASCII art (0-3 digits / '.') -> image."""
    h = len(rows); w = len(rows[0])
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); p = im.load()
    for y, r in enumerate(rows):
        for x, c in enumerate(r):
            if c != '.': p[x, y] = rgb(pal[int(c)]) + (255,)
    return im

def block(tl, w, h, pal):
    """w x h tiles starting at tile index tl (row-major, as put16 stores 16x16)."""
    im = Image.new("RGBA", (w * 8, h * 8), (0, 0, 0, 0))
    k = 0
    for ty in range(h):
        for tx in range(w):
            im.alpha_composite(tile_img(tl + k, pal), (tx * 8, ty * 8)); k += 1
    return im

def x2(im): return im.resize((im.width * 2, im.height * 2), Image.NEAREST)

def fit(im, size):
    """center a (2x) NES image in a cell of the CLEAN set's size (shared region table)."""
    cell = Image.new("RGBA", size, (0, 0, 0, 0))
    cell.alpha_composite(im, ((size[0] - im.width) // 2, (size[1] - im.height) // 2))
    return cell

# ---------------------------------------------------------------- sprites
def queen(team, frame):
    rows = NS["QUEEN_A"] if frame % 2 == 0 else NS["QUEEN_B"]
    return x2(art_img(rows, TEAM_SP[team]))
def queen_pose(team, pose, wing):
    q = queen(team, wing)
    if pose == "dive": q = q.rotate(90, expand=True)          # stinger (tail) down
    if pose == "stun": q = queen(team, 1)
    return q
def worker(team, pose, k):
    if pose == "walk": t = 0x4C if k % 2 == 0 else 0x4D
    else: t = 0x4E
    return x2(tile_img(t, TEAM_SP[team]))
def snail(k):
    return x2(block(0x50 if k % 2 == 0 else 0x52, 2, 1, SP[2]))
def berry(): return x2(tile_img(0x08, BG[3]))
def yoyo(): return x2(tile_img(0x57, SP[3]))
def spark(k): return x2(tile_img(0x54, SP[3]))
def crown(on):
    im = x2(tile_img(0x0B, BG[2]))
    if not on:
        a = im.split()[3].point(lambda v: v * 40 // 100); im.putalpha(a)
    return im
def meter(on): return x2(tile_img(0x0A if on else 0x09, BG[2]))
def honeycomb_frame():
    """40x100: NES honeycomb tiles (0x0E) at 2x on the same hole grid as the other sets."""
    im = Image.new("RGBA", (40, 100), (0, 0, 0, 0))
    cell = x2(tile_img(0x0E, BG[2]))
    for k in range(10):
        im.alpha_composite(cell, (2 + 20 * (k % 2), 2 + 20 * (k // 2)))
    return im

# ---------------------------------------------------------------- boards
def tiled(idx, pal, w, h, flip=False, ox=0, oy=0):
    """fill a w x h area with a 2x NES tile, pattern continuing across cells."""
    t = x2(tile_img(idx, pal, transparent=False, flip=flip))
    out = Image.new("RGBA", (w, h))
    for yy in range(-((oy) % 16), h, 16):
        for xx in range(-((ox) % 16), w, 16):
            out.paste(t, (xx, yy))
    return out

def board(L, build, CW=20, CH=12):
    grid, rowidx, LL, LR, br, p = build(L)[:6]
    im = Image.new("RGBA", (640, 360), BLACK + (255,))
    shaft = L["shaft"]; side = bool(L.get("side_wrap"))
    gy = 26 * CH
    # ground: the NES ground-top tile, dirt below (black pit for Wrap Hive)
    ground = Image.new("RGBA", (640, 360 - gy))
    ground.alpha_composite(tiled(0x01, BG[0], 640, 360 - gy))
    ground.alpha_composite(tiled(0x03, BG[0], 640, 16))
    im.alpha_composite(ground, (0, gy))
    if shaft:
        x0, x1 = shaft[0] * CW, (shaft[1] + 1) * CW
        im.paste(BLACK + (255,), (x0, gy, x1, 360))
        beam = tiled(0x0C, BG[0], 640, 16)
        for (a, b) in ((4 * CW, x0), (x1, 28 * CW)):
            im.alpha_composite(beam.crop((a, 0, b, 16)), (a, 46))
    # platforms: the NES platform tile (art in its top rows) along every plank
    plank = x2(tile_img(0x02, BG[0]))
    for row, segs in L["platforms"].items():
        for a, b in segs:
            for x in range(a * CW, (b + 1) * CW, 16):
                w = min(16, (b + 1) * CW - x)
                im.alpha_composite(plank.crop((0, 0, w, 16)), (x, row * CH))
    for (c, r) in L["walls"] + L.get("bumps", []):
        im.alpha_composite(tiled(0x0F, BG[0], CW, CH, ox=c * CW, oy=r * CH), (c * CW, r * CH))
    if "boxes" in L:
        for team, c in enumerate(L["boxes"]["cols"]):
            box = x2(block(0x58, 2, 2, BG[1 + team]))
            im.alpha_composite(box, (c * CW + 4, (L["boxes"]["row"] - 2) * CH - 8))
    if not L.get("bonus"):
        for team, hx in ((0, 4), (1, 604)):
            hive = x2(block(0x04, 2, 2, BG[1 + team]))
            im.alpha_composite(hive, (hx, gy - 32))
    if not side:      # the NES vine borders on solid-sided boards
        va, vb = x2(tile_img(0x39, BG[0])), x2(tile_img(0x3A, BG[0]))
        ra, rb = x2(tile_img(0x3B, BG[0])), x2(tile_img(0x3C, BG[0]))
        for k, y in enumerate(range(72, gy - 8, 16)):
            im.alpha_composite(va if k % 2 == 0 else vb, (0, y))
            im.alpha_composite(ra if k % 2 == 0 else rb, (624, y))
    if L.get("bonus"):
        # berry vines hanging under the two upper levels (berries drawn by the game)
        stem = x2(tile_img(0x3A, BG[0]))
        for (col, top, bot) in [(9, 8, 10), (22, 8, 10), (13, 8, 10), (18, 8, 10), (7, 14, 16), (24, 14, 16), (11, 14, 16), (20, 14, 16)]:
            x = col * CW + 10 - 8
            for y in range(top * CH + 6, bot * CH, 16):
                im.alpha_composite(stem.crop((0, 0, 16, min(16, bot * CH - y))), (x, y))
    # HUD band
    im.paste(BLACK + (255,), (0, 0, 640, 46))
    return im

def menu_bg():
    im = Image.new("RGBA", (640, 360), BLACK + (255,))
    comb = x2(tile_img(0x0E, BG[1]))
    for x in range(0, 640, 16):
        im.alpha_composite(comb, (x, 4)); im.alpha_composite(comb, (x, 340))
    return im
