#!/bin/bash
# Builds the gameplay core for the PC (gcc) and runs the automated checks.
#   tests/run_tests.sh [matches_per_board]      -> gameplay tests
#   tests/run_tests.sh balance 400              -> blue/yellow win balance per board
set -e
cd "$(dirname "$0")/.."
mkdir -p build/host
for f in game.h game.c ai.c flow.c levels.h; do python3 tools/to_host_c.py src/$f build/host/$f; done
cp tests/test_main.c tests/balance.c build/host/
cd build/host
if [ "$1" = "balance" ]; then gcc -O2 -w -o balance balance.c && ./balance ${2:-200}
else gcc -O2 -w -o test_core test_main.c && ./test_core ${1:-40}; fi
