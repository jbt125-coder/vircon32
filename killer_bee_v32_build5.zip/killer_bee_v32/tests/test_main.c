// PC test build of the gameplay core (generated host/*.c from src/ via tools/to_host_c.py)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "game.h"
#include "game.c"
#include "ai.c"
#include "flow.c"

static int fails = 0, passes = 0;
static void check(const char* name, int ok, const char* detail)
{
    if (ok) passes++; else fails++;
    printf("%s %s%s%s\n", ok ? "PASS" : "FAIL", name, detail[0] ? "  " : "", detail);
}

// run one CPU-vs-CPU match, return winner (or -1 on timeout)
static int cpu_match(int level, int seed, int maxframes, int* type, int* frames, int* clipfail)
{
    game_init(seed);
    cpu_all = 1;
    force_level = level + 1;
    team_size = 3;
    for (int p = 0; p < MAX_PLAYERS; p++) pl_joined[p] = 0;
    start_match();
    int f;
    for (f = 0; f < maxframes && game_state == ST_PLAY; f++)
    {
        int oy[MAXE], od[MAXE], oa[MAXE];
        for (int i = 0; i < num_ents; i++) { oy[i] = px(ents[i].y); od[i] = ents[i].drop; oa[i] = ents[i].alive; }
        memset(pad, 0, sizeof pad); memset(pad_new, 0, sizeof pad_new);
        game_frame();
        if (clipfail)
            for (int i = 0; i < num_ents; i++)
            {
                Ent* e = &ents[i];
                if (!oa[i] || !e->alive || od[i] || e->drop || snail_rider == i) continue;
                int y = px(e->y); int h = ent_h(e);
                if (y <= oy[i] || y - oy[i] > 40) continue;
                for (int r = 1; r < GROUND_ROW; r++)
                {
                    int top = r * CH;
                    if (oy[i] + h <= top && y + h > top && check_under(e, r)) { (*clipfail)++; }
                }
            }
    }
    *type = win_type; *frames = f;
    if (game_state == ST_PLAY) return -1;
    return winner;
}

int main(int argc, char** argv)
{
    char buf[256];
    int n = argc > 1 ? atoi(argv[1]) : 40;
    // ---- 1. queen dash clipping regression (the NES bug scenario)
    {
        game_init(1); force_level = 1; team_size = 3; start_match();
        for (int i = 1; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 30000; }
        Ent* q = &ents[0];
        q->timer = 0; q->ground = 0; q->face = 0; q->cool = 0; q->drop = 0;
        q->x = 200 * FP; q->y = (168 - QH) * FP + 240;    // feet level with a plank top, high sub-pixel fraction
        q->vy = -16;                                      // was rising
        q->atk = DASH_FRAMES;
        for (int f = 0; f < 80; f++) { memset(pad, 0, sizeof pad); memset(pad_new, 0, sizeof pad_new); queen_update(0); }
        sprintf(buf, "x=%d y=%d ground=%d (plank top 168 -> standing y=%d)", px(q->x), px(q->y), q->ground, 168 - QH);
        check("queen dash over a plank does not clip through", px(q->y) == 168 - QH && q->ground, buf);
    }
    // ---- 2. exhaustive version: every sub-pixel fraction and speed
    {
        int bad = 0, total = 0;
        for (int frac = 0; frac < 256; frac += 8)
            for (int vy = -1152; vy <= 768; vy += 64)
                for (int off = -3; off <= 0; off++)
                {
                    game_init(1); force_level = 1; team_size = 3; start_match();
                    for (int i = 1; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 30000; }
                    Ent* q = &ents[0];
                    q->timer = 0; q->ground = 0; q->face = 0; q->cool = 0; q->drop = 0;
                    q->x = 200 * FP; q->y = (168 - QH + off) * FP + frac; q->vy = vy; q->atk = DASH_FRAMES;
                    for (int f = 0; f < 90; f++) queen_update(0);
                    total++;
                    if (px(q->x) + 3 >= 260 && px(q->x) + 20 < 380 && px(q->y) > 168 - QH) bad++;
                }
        sprintf(buf, "%d of %d dash starts ended below the plank", bad, total);
        check("no clipping for any sub-pixel/speed combination", bad == 0, buf);
    }
    // ---- 3. random rotation, never the same board twice
    {
        game_init(7); int seen[NUM_MATCH_LEVELS] = {0}; int rep = 0, prev = -1;
        for (int k = 0; k < 500; k++) { pick_level(); seen[cur_level]++; if (cur_level == prev) rep++; prev = cur_level; }
        int all = 1; for (int l = 0; l < NUM_MATCH_LEVELS; l++) if (!seen[l]) all = 0;
        sprintf(buf, "counts %d %d %d %d %d, repeats %d", seen[0], seen[1], seen[2], seen[3], seen[4], rep);
        check("board rotation covers all 5, never repeats", all && rep == 0, buf);
    }
    // ---- 4. team select: first to lock in gets the queen
    {
        game_init(3); enter_setup();
        pl_joined[1] = 1; pl_team[1] = 0; pl_team[0] = 0;   // P1 and P2 both blue, both want queen
        memset(pad_new, 0, sizeof pad_new); pad_new[1] = BTN_A; game_frame();      // P2 locks first
        memset(pad_new, 0, sizeof pad_new); pad_new[0] = BTN_A; game_frame();      // then P1
        check("first to lock in gets queen", pl_wantq[1] == 1 && pl_wantq[0] == 0 && pl_bumped[0] > 0, "");
        memset(pad_new, 0, sizeof pad_new); pad_new[0] = BTN_START; game_frame();
        sprintf(buf, "P2 ctrl=%d P1 ctrl=%d state=%d", pl_ctrl[1], pl_ctrl[0], game_state);
        check("match starts with P2 as blue queen, P1 as blue worker", game_state == ST_PLAY && pl_ctrl[1] == 0 && pl_ctrl[0] == worker_index(0, 0), buf);
        // SELECT cycling skips the teammate's queen
        memset(pad_new, 0, sizeof pad_new); pad_new[0] = BTN_SELECT; game_frame();
        int c1 = pl_ctrl[0];
        memset(pad_new, 0, sizeof pad_new); pad_new[0] = BTN_SELECT; game_frame();
        int c2 = pl_ctrl[0];
        sprintf(buf, "P1: %d -> %d -> %d", worker_index(0,0), c1, c2);
        check("SELECT cycles workers and skips the human-controlled queen", c1 == worker_index(0, 1) && c2 == worker_index(0, 0), buf);
    }
    // ---- 5. four humans on one team: team grows to 4 bees, CPUs fill the other team
    {
        game_init(5); enter_setup();
        for (int p = 0; p < 4; p++) { pl_joined[p] = 1; pl_team[p] = 0; pl_wantq[p] = (p == 0); }
        for (int p = 0; p < 4; p++) { memset(pad_new, 0, sizeof pad_new); pad_new[p] = BTN_A; game_frame(); }
        memset(pad_new, 0, sizeof pad_new); pad_new[0] = BTN_START; game_frame();
        sprintf(buf, "team_size=%d ents=%d ctrl=%d,%d,%d,%d", team_size, num_ents, pl_ctrl[0], pl_ctrl[1], pl_ctrl[2], pl_ctrl[3]);
        check("4 humans on blue -> 4 bees per team", team_size == 4 && num_ents == 8 && pl_ctrl[0] == 0 && pl_ctrl[3] == worker_index(0, 2), buf);
    }
    // ---- 5b. down-dash dive
    {
        // (a) from a platform: drops through it, kills a worker right below, no stun
        game_init(9); force_level = 1; team_size = 3; start_match();
        for (int i = 1; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 30000; }
        Ent* q = &ents[0]; q->timer = 0; q->cool = 0;
        q->x = 300 * FP; q->y = (168 - QH) * FP; q->ground = 1; q->vy = 0;           // standing on Meadow row-14 plank (cols 13-18)
        Ent* w = &ents[worker_index(1, 0)];
        spawn_entity(worker_index(1, 0)); w->x = 306 * FP; w->y = (240 - WH) * FP; w->ground = 1;   // on the row-20 plank below
        q->inp = BTN_DOWN | BTN_B; q->inpn = BTN_B; queen_update(0);
        q->inp = 0; q->inpn = 0;
        int f; for (f = 0; f < 40 && w->alive; f++) { queen_update(0); combat(); }
        sprintf(buf, "worker alive=%d after %d frames, queen stun=%d dive=%d", w->alive, f, q->stun, q->dive);
        check("dive from a platform kills the worker below, no stun", !w->alive && q->stun == 0 && q->dive == 0, buf);
        // (b) a miss: lands on the next plank and is stunned ~0.5 s, and can be stung meanwhile
        game_init(9); force_level = 1; team_size = 3; start_match();
        for (int i = 2; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 30000; }
        q = &ents[0]; q->timer = 0; q->cool = 0; q->x = 300 * FP; q->y = 100 * FP; q->ground = 0; q->vy = 0;
        Ent* y = &ents[1]; y->timer = 0; y->x = 560 * FP; y->y = 60 * FP;
        q->inp = BTN_DOWN | BTN_B; q->inpn = BTN_B; queen_update(0); q->inp = 0; q->inpn = 0;
        int landed = -1, stunframes = 0, movedwhilestunned = 0, sy = 0;
        for (f = 0; f < 80; f++)
        {
            int before = q->y;
            queen_update(0);
            if (q->stun > 0) { if (landed < 0) { landed = f; sy = px(q->y); } else { stunframes++; if (q->y != before) movedwhilestunned = 1; } }
        }
        sprintf(buf, "landed after %d frames at y=%d (plank top 168 -> %d), frozen %d frames, moved=%d", landed, sy, 168 - QH, stunframes + 1, movedwhilestunned);
        check("missed dive lands on the next plank and is stunned ~0.5 s", landed > 0 && sy == 168 - QH && stunframes + 1 == STUN_FRAMES && !movedwhilestunned, buf);
        q->dive = 0; q->stun = STUN_FRAMES; q->ground = 1;
        y->x = (px(q->x) - 20) * FP; y->y = q->y; y->face = 0; y->atk = DASH_LIVE;
        queen_attack(1);
        check("a stunned queen can be stung", !q->alive, "");
    }
    // ---- 5c. head-to-head per difficulty (scripted human vs CPU queen, both sides)
    for (int dlev = 0; dlev < 3; dlev++)
    {
        int hk = 0, ck = 0;
        for (int side = 0; side < 2; side++)
            for (int s2 = 0; s2 < 300; s2++)
            {
                game_init(777 + s2 * 13); force_level = 2; team_size = 3;
                pl_joined[0] = 1; pl_team[0] = side; start_match(); pl_ctrl[0] = side;
                difficulty = dlev;
                for (int i = 2; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
                for (int t2 = 0; t2 < 2; t2++) { ents[t2].timer = 0; ents[t2].y = (120 + (s2 % 5) * 20) * FP; }
                ents[0].x = (200 + (s2 % 7) * 6) * FP; ents[1].x = mirror_x(200 + (s2 % 7) * 6, QW) * FP;
                int prev = 0, l0[2] = {lives[0], lives[1]};
                for (int f2 = 0; f2 < 900; f2++)
                {
                    Ent* me = &ents[side]; Ent* o = &ents[1 - side];
                    int b = 0; int d = dxs(px(me->x) + 12, px(o->x) + 12); int dy = px(o->y) - px(me->y);
                    if (d > 0) b |= BTN_RIGHT; else b |= BTN_LEFT;
                    if (dy < -4 && me->vy >= 0) b |= BTN_A;
                    int facing = (d >= 0 && me->face == 0) || (d < 0 && me->face == 1);
                    if (facing && iabs(d) < 60 && iabs(dy) < 18 && me->cool == 0) b |= BTN_B;
                    pad_new[0] = b & ~prev; pad[0] = b; prev = b;
                    game_frame();
                    if (lives[side] < l0[side]) { ck++; break; }
                    if (lives[1 - side] < l0[1 - side]) { hk++; break; }
                }
            }
        const char* dn[] = {"EASY", "NORMAL", "HARD"};
        printf("head-to-head vs CPU %-6s: human first kills %3d, CPU first kills %3d  (human share %d%%)\n", dn[dlev], hk, ck, hk * 100 / (hk + ck ? hk + ck : 1));
    }
    difficulty = DIFF_NORMAL;
    // ---- 5d. snail speed: berry-carrying rider, fed berries, both
    {
        int dist[4];
        for (int mode = 0; mode < 4; mode++)     // 0 plain, 1 rider carries berry, 2 fed, 3 both
        {
            game_init(21); force_level = 1; team_size = 3; start_match(); cpu_all = 0;
            for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
            int r = worker_index(0, 0); spawn_entity(r); snail_rider = r; ents[r].carry = (mode & 1);
            if (mode & 2) { snail_boost = SNAIL_FEED_FRAMES; snail_boost_team = 0; }
            int x0 = snail_x;
            for (int f = 0; f < 120; f++) snail_update();
            dist[mode] = snail_x - x0;
        }
        sprintf(buf, "distance in 2 s: plain %d, berry rider %d (x%.2f), fed %d (x%.2f), both %d (x%.2f)  [1/256 px]",
                dist[0], dist[1], dist[1] / (double)dist[0], dist[2], dist[2] / (double)dist[0], dist[3], dist[3] / (double)dist[0]);
        int ok = abs(dist[1] * 2 - dist[0] * 3) <= 6 && abs(dist[2] - dist[0] * 2) <= 6 && abs(dist[3] - dist[0] * 3) <= 6;
        check("snail speed: rider with berry x1.5, fed x2, both x3", ok, buf);
        // the boost lasts 3 s
        game_init(21); force_level = 1; team_size = 3; start_match();
        snail_boost = SNAIL_FEED_FRAMES; snail_boost_team = 0;
        for (int f = 0; f < SNAIL_FEED_FRAMES; f++) snail_update();
        check("fed boost lasts 3 seconds", snail_boost == 0, "");
    }
    {
        // feeding rules: teammate feeds automatically on touch; enemy or riderless does not
        int fed_team = 0, fed_enemy = 0, fed_norider = 0;
        for (int mode = 0; mode < 3; mode++)
        {
            game_init(22); force_level = 1; team_size = 3; start_match();
            for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
            int r = worker_index(0, 0); spawn_entity(r);
            if (mode != 2) snail_rider = r;
            int fi = (mode == 1) ? worker_index(1, 0) : worker_index(0, 1);
            spawn_entity(fi); Ent* fe = &ents[fi];
            fe->carry = 1; fe->ground = 1; fe->x = (px(snail_x) + 20) * FP; fe->y = lp[LP_SNAIL_Y] * FP;
            worker_berries(fi);
            int fed = (fe->carry == 0 && snail_boost > 0);
            if (mode == 0) fed_team = fed; if (mode == 1) fed_enemy = fed; if (mode == 2) fed_norider = fed;
        }
        sprintf(buf, "teammate fed=%d, enemy fed=%d, no rider fed=%d", fed_team, fed_enemy, fed_norider);
        check("only a teammate feeds, only while their team rides", fed_team && !fed_enemy && !fed_norider, buf);
    }
    {
        // CPU feeds only when the snail is close to winning
        int fedclose = 0, fedfar = 0;
        for (int mode = 0; mode < 2; mode++)
            for (int s2 = 0; s2 < 20; s2++)
            {
                game_init(300 + s2); force_level = 1; team_size = 3; start_match(); cpu_all = 1;
                for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
                int r = worker_index(0, 0); spawn_entity(r); snail_rider = r;
                int total = lp[LP_GOAL_R] - lp[LP_SNAIL_START];
                int sx = lp[LP_SNAIL_START] + (mode == 0 ? total * 70 / 100 : total * 20 / 100);
                snail_x = sx * FP;
                int fi = worker_index(0, 1); spawn_entity(fi); ents[fi].carry = 1;
                ents[fi].x = (sx - 120) * FP; ents[fi].y = (lp[LP_SNAIL_Y]) * FP; ents[fi].ground = 1;
                int left = -1;
                for (int f = 0; f < 300; f++)
                {
                    int keepx = snail_x;                           // hold the snail still for the test
                    ai_worker(fi); ents[fi].inp = ai_t0; ents[fi].inpn = ai_t1; worker_update(fi);
                    tb_update();                                   // thrown berries fly too
                    snail_x = keepx; ents[r].x = snail_x + 6 * FP;
                    if (snail_boost > 0) break;
                    if (!ents[fi].carry && left < 0) left = f;
                    if (left >= 0 && f - left > 90) break;         // the berry had time to land
                }
                if (snail_boost > 0) { if (mode == 0) fedclose++; else fedfar++; }
            }
        sprintf(buf, "fed when close: %d/20, fed when far: %d/20", fedclose, fedfar);
        check("CPU workers feed the snail (by hand or by throwing) only when it is close to winning", fedclose >= 18 && fedfar == 0, buf);
    }
    // ---- 5e. throwing berries
    {
        // find a spot on the ground floor from which a standing throw lands in the blue hive
        int scored = 0, at = -1;
        for (int x0 = 60; x0 < 260 && !scored; x0 += 2)
        {
            game_init(31); force_level = 1; team_size = 3; start_match();
            for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
            int w = worker_index(0, 0); spawn_entity(w); Ent* e = &ents[w];
            e->x = x0 * FP; e->y = GROUND_Y_WORKER * FP; e->ground = 1; e->face = 1; e->carry = 1;
            int b0 = berries[0];
            e->inp = BTN_B; e->inpn = BTN_B; worker_update(w); e->inp = 0; e->inpn = 0;
            for (int f = 0; f < 120; f++) tb_update();
            if (berries[0] == b0 + 1) { scored = 1; at = x0; }
        }
        sprintf(buf, "standing throw from x=%d scored", at);
        check("a berry thrown into your own hive scores", scored, buf);
        // same throw toward the ENEMY hive: no score, it lands as a pickup
        game_init(31); force_level = 1; team_size = 3; start_match();
        for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
        int w = worker_index(0, 0); spawn_entity(w); Ent* e = &ents[w];
        e->x = (SCREEN_W - 12 - at) * FP; e->y = GROUND_Y_WORKER * FP; e->ground = 1; e->face = 0; e->carry = 1;
        int b1 = berries[1], b0 = berries[0];
        e->inp = BTN_B; e->inpn = BTN_B; worker_update(w); e->inp = 0; e->inpn = 0;
        for (int f = 0; f < 120; f++) tb_update();
        int lying = 0; for (int k = 0; k < MAX_TB; k++) if (tb_on[k] == 2) lying++;
        check("a berry thrown into the enemy hive does not score; it lands as a pickup", berries[1] == b1 && berries[0] == b0 && lying == 1, "");
        // an enemy worker can grab it
        int y = worker_index(1, 0); spawn_entity(y); Ent* ey = &ents[y];
        for (int k = 0; k < MAX_TB; k++) if (tb_on[k] == 2) { ey->x = tb_x[k]; ey->y = tb_y[k]; }
        ey->carry = 0; ey->ground = 1; worker_berries(y);
        check("anyone can pick up a berry lying on the board", ey->carry == 1, "");
        // thrown into a teammate-ridden snail = turbo; B next to an empty snail = ride with the berry
        game_init(32); force_level = 1; team_size = 3; start_match();
        for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
        int r = worker_index(0, 1); spawn_entity(r); snail_rider = r;
        w = worker_index(0, 0); spawn_entity(w); e = &ents[w];
        int fed = 0;
        for (int x0 = px(snail_x) - 160; x0 < px(snail_x) - 20 && !fed; x0 += 2)
        {
            snail_boost = 0; for (int k = 0; k < MAX_TB; k++) tb_on[k] = 0;
            e->x = x0 * FP; e->y = GROUND_Y_WORKER * FP; e->ground = 1; e->face = 0; e->carry = 1;
            e->inp = BTN_B; e->inpn = BTN_B; worker_update(w); e->inp = 0; e->inpn = 0;
            for (int f = 0; f < 90; f++) { int kx = snail_x; tb_update(); snail_x = kx; }
            if (snail_boost > 0) fed = 1;
        }
        check("a berry thrown into a teammate-ridden snail gives the turbo", fed, "");
        game_init(33); force_level = 1; team_size = 3; start_match();
        for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
        w = worker_index(0, 0); spawn_entity(w); e = &ents[w];
        e->x = snail_x + 4 * FP; e->y = lp[LP_SNAIL_Y] * FP; e->ground = 1; e->carry = 1;
        e->inp = BTN_B; e->inpn = BTN_B; worker_update(w);
        check("B next to an empty snail while carrying rides it (keeps the berry)", snail_rider == w && e->carry == 1, "");
        // throwing while jumping
        game_init(34); force_level = 1; team_size = 3; start_match();
        for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
        w = worker_index(0, 0); spawn_entity(w); e = &ents[w];
        e->x = 300 * FP; e->y = GROUND_Y_WORKER * FP; e->ground = 1; e->carry = 1;
        e->inp = BTN_A; e->inpn = BTN_A; worker_update(w);
        for (int f = 0; f < 6; f++) { e->inp = 0; e->inpn = 0; worker_update(w); }
        e->inp = BTN_B | BTN_RIGHT; e->inpn = BTN_B; worker_update(w);
        int flying = 0; for (int k = 0; k < MAX_TB; k++) if (tb_on[k] == 1) flying++;
        check("workers can throw while jumping", !e->ground && e->carry == 0 && flying == 1, "");
    }
    // ---- 5f. HONEYCOMB HOOPS bonus round
    {
        game_init(41); team_size = 3; start_bonus();
        int vines = 0; for (int k = 0; k < NUM_VINES; k++) vines += vine_on[k];
        check("bonus round starts on the Hoops board with 8 berry vines", game_state == ST_PLAY && bonus_mode && cur_level == LEVEL_HOOPS && vines == 8, "");
        // a queen's sting knocks a vine berry down; it lands as a pickup
        for (int i = 1; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
        Ent* q = &ents[0]; q->timer = 0; q->x = (vine_x[0] - 12 - 30) * FP; q->y = (vine_y[0] - 12) * FP; q->face = 0; q->cool = 0; q->ground = 0;
        q->inp = BTN_B; q->inpn = BTN_B; queen_update(0); q->inp = 0; q->inpn = 0;
        for (int f = 0; f < 20; f++) { queen_update(0); hoops_vine_strikes(); hoops_update(); tb_update(); }
        int falling = 0; for (int k = 0; k < MAX_TB; k++) if (tb_on[k]) falling++;
        for (int f = 0; f < 120; f++) { hoops_update(); tb_update(); }
        int lying = 0, ly = 0; for (int k = 0; k < MAX_TB; k++) if (tb_on[k] == 2) { lying++; ly = px(tb_y[k]); }
        sprintf(buf, "vine 0 on=%d, berries knocked=%d, lying=%d at y=%d", vine_on[0], falling, lying, ly);
        check("a queen's sting knocks a vine berry down; it lands as a pickup", !vine_on[0] && falling == 1 && lying == 1, buf);
        // throwing into your own moving honeycomb scores (search a position/time that works)
        int scored = 0;
        for (int ph = 0; ph < 360 && !scored; ph += 6)
            for (int x0 = 70; x0 < 300 && !scored; x0 += 8)
            {
                game_init(42); team_size = 3; start_bonus();
                for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
                hc_phase = ph; hc_y = hc_y_at(ph);
                int w = worker_index(0, 0); spawn_entity(w); Ent* e = &ents[w];
                e->x = x0 * FP; e->y = GROUND_Y_WORKER * FP; e->ground = 1; e->face = 1; e->carry = 1;
                e->inp = BTN_B; e->inpn = BTN_B; worker_update(w); e->inp = 0; e->inpn = 0;
                for (int f = 0; f < 90; f++) { hoops_update(); tb_update(); }
                if (hoops[0] == 1 && hoops[1] == 0) scored = 1;
            }
        check("a berry thrown into your own moving honeycomb scores", scored, "");
        // placing from the ground when the honeycomb comes down
        game_init(43); team_size = 3; start_bonus();
        for (int i = 0; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
        int w = worker_index(1, 0); spawn_entity(w); Ent* e = &ents[w];
        e->x = (hc_left(1) + 14) * FP; e->y = GROUND_Y_WORKER * FP; e->ground = 1; e->carry = 1;
        int frames = 0;
        while (hoops[1] == 0 && frames < 800) { hoops_update(); worker_update(w); frames++; }
        sprintf(buf, "scored after %d frames (honeycomb comes down every %d)", frames, 2 * HC_HALF);
        check("standing under your honeycomb, you place the berry when it comes down", hoops[1] == 1 && frames < 2 * HC_HALF + PLACE_FRAMES + 5, buf);
        // queens stung in the bonus lose no crown; first to 10 wins and earns a 4th crown next match
        game_init(44); team_size = 3; start_bonus();
        int l0 = lives[1]; kill_entity(1);
        check("a queen stung in the bonus round loses no crown", lives[1] == l0 && !ents[1].alive && ents[1].timer > 0, "");
        for (int k = 0; k < HOOPS_GOAL; k++) hoops_score(0);
        check("first team to fill 10 holes wins the bonus", winner == 0 && win_type == WIN_HOOPS, "");
        start_match();
        sprintf(buf, "blue lives %d, yellow lives %d", lives[0], lives[1]);
        check("the bonus winner's queen starts the next match with a 4th crown", lives[0] == 4 && lives[1] == 3 && !bonus_mode, buf);
        // CPU-vs-CPU bonus rounds: they finish, and blue/yellow are even
        int bw[2] = {0, 0}, tos = 0; long fr = 0;
        for (int r = 0; r < 200; r++)
        {
            game_init(5000 + r * 17); cpu_all = 1; team_size = 3; start_bonus();
            int f;
            for (f = 0; f < 60 * 60 * 4 && game_state == ST_PLAY; f++) { memset(pad_new, 0, sizeof pad_new); game_frame(); }
            if (game_state == ST_PLAY) tos++; else { bw[winner]++; fr += f; }
        }
        sprintf(buf, "blue %d, yellow %d, unfinished after 4 min %d, average %.0f s", bw[0], bw[1], tos, fr / 60.0 / (bw[0] + bw[1] ? bw[0] + bw[1] : 1));
        check("CPU bonus rounds finish and are even (200 rounds)", tos == 0 && bw[0] > 75 && bw[1] > 75, buf);
    }
    // ---- 6. CPU-vs-CPU matches on every board
    int typecount[3] = {0, 0, 0}, timeouts = 0, clips = 0;
    int bywin[NUM_LEVELS][2] = {{0}};
    long totalf = 0; int games = 0;
    for (int l = 0; l < NUM_MATCH_LEVELS; l++)
        for (int s = 0; s < n; s++)
        {
            int t, f;
            int w = cpu_match(l, 1000 + s * 7919 + l, 60 * 60 * 6, &t, &f, &clips);
            if (w < 0) timeouts++; else { typecount[t]++; bywin[l][w]++; totalf += f; games++; }
        }
    sprintf(buf, "military %d, economic %d, snail %d, timeouts %d", typecount[0], typecount[1], typecount[2], timeouts);
    check("CPU matches finish and all three victories occur", typecount[0] && typecount[1] && typecount[2] && timeouts == 0, buf);
    sprintf(buf, "%d plank pass-throughs in %d matches", clips, NUM_LEVELS * n);
    check("no bee passes down through a plank without dropping", clips == 0, buf);
    printf("average match length %.1f s\n", games ? totalf / 60.0 / games : 0);
    const char* names[] = {"Meadow", "Wrap Hive", "Meadow Warp", "Wrap Hive Warp", "Divide"};
    for (int l = 0; l < NUM_MATCH_LEVELS; l++) printf("  %-15s blue %3d  yellow %3d\n", names[l], bywin[l][0], bywin[l][1]);
    printf("\n%d passed, %d failed\n", passes, fails);
    return fails ? 1 : 0;
}
