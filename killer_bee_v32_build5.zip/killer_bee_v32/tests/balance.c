#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "game.h"
#include "game.c"
#include "ai.c"
#include "flow.c"
int main(int argc, char** argv)
{
    int n = atoi(argv[1]);
    const char* names[] = {"Meadow", "Wrap Hive", "Meadow Warp", "Wrap Hive Warp", "Divide"};
    for (int l = 0; l < NUM_MATCH_LEVELS; l++)
    {
        int w[2] = {0, 0}, ty[2][3] = {{0}}, to = 0;
        for (int s = 0; s < n; s++)
        {
            game_init(5000 + s * 104729 + l * 31); cpu_all = 1; force_level = l + 1; team_size = 3;
            start_match();
            int f;
            for (f = 0; f < 60 * 60 * 6 && game_state == ST_PLAY; f++) { memset(pad_new, 0, sizeof pad_new); game_frame(); }
            if (game_state == ST_PLAY) to++; else { w[winner]++; ty[winner][win_type]++; }
        }
        printf("%-15s blue %4d (mil %3d eco %3d snail %3d)  yellow %4d (mil %3d eco %3d snail %3d)  timeouts %d\n",
               names[l], w[0], ty[0][0], ty[0][1], ty[0][2], w[1], ty[1][0], ty[1][1], ty[1][2], to);
    }
}
