// Head-to-head: a scripted "human" queen vs the CPU queen, from both sides.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "game.h"
#include "game.c"
#include "ai.c"
#include "flow.c"
// human script: steer at the enemy's height, dash when lined up and in range
int human(int me)
{
    Ent* q = &ents[me]; Ent* o = &ents[1 - me];
    int b = 0;
    int d = dxs(px(q->x) + 12, px(o->x) + 12);
    int dy = (px(o->y)) - px(q->y);
    if (d > 0) b |= BTN_RIGHT; else b |= BTN_LEFT;
    if (dy < -4 && q->vy >= 0) b |= BTN_A;
    int facing = (d >= 0 && q->face == 0) || (d < 0 && q->face == 1);
    if (facing && abs(d) < 60 && abs(dy) < 18 && q->cool == 0) b |= BTN_B;
    return b;
}
int main(int argc, char** argv)
{
    int n = argc > 1 ? atoi(argv[1]) : 200;
    for (int humanteam = 0; humanteam < 2; humanteam++)
    {
        int hw = 0, cw = 0, none = 0, clashes = 0;
        for (int s = 0; s < n; s++)
        {
            game_init(777 + s * 13); force_level = 1; team_size = 3;
            pl_joined[0] = 1; pl_ctrl[0] = humanteam; pl_team[0] = humanteam;
            start_match();
            for (int i = 2; i < num_ents; i++) { ents[i].alive = 0; ents[i].timer = 1 << 28; }
            for (int t = 0; t < 2; t++) { ents[t].timer = 0; ents[t].y = (120 + (s % 5) * 20) * FP; }
            ents[0].x = (200 + (s % 7) * 6) * FP; ents[1].x = mirror_x(200 + (s % 7) * 6, QW) * FP;
            int prev = 0, lives0[2] = {lives[0], lives[1]};
            int result = -1;
            for (int f = 0; f < 900 && result < 0; f++)
            {
                int b = human(humanteam);
                pad_new[0] = b & ~prev; pad[0] = b; prev = b;
                game_frame();
                for (int k = 0; k < ev_count; k++) if (ev_list[k] == EV_CLANK) clashes++;
                if (lives[humanteam] < lives0[humanteam]) result = 1;       // human died
                else if (lives[1 - humanteam] < lives0[1 - humanteam]) result = 0;
            }
            if (result == 0) hw++; else if (result == 1) cw++; else none++;
        }
        printf("human plays %-6s: human first kill %3d, CPU first kill %3d, no kill %3d, clashes %d\n",
               humanteam == 0 ? "BLUE" : "YELLOW", hw, cw, none, clashes);
    }
}
