// Counts workers frozen in place (same x and y for 4+ seconds) during CPU matches.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "game.h"
#include "game.c"
#include "ai.c"
#include "flow.c"
int main(int argc, char** argv)
{
    int n = atoi(argv[1]); long stuck = 0, matches = 0; int shown = 0;
    for (int l = 0; l < NUM_LEVELS; l++)
        for (int s = 0; s < n; s++)
        {
            game_init(900 + s * 31 + l); cpu_all = 1; force_level = l + 1; team_size = 3; start_match(); matches++;
            int still[MAXE] = {0}, lx[MAXE], ly[MAXE];
            for (int i = 0; i < MAXE; i++) { lx[i] = -1; ly[i] = -1; }
            for (int f = 0; f < 60 * 60 * 4 && game_state == ST_PLAY; f++)
            {
                memset(pad_new, 0, sizeof pad_new); game_frame();
                for (int i = 2; i < num_ents; i++)
                {
                    Ent* e = &ents[i];
                    if (!e->alive || snail_rider == i) { still[i] = 0; continue; }
                    if (e->x == lx[i] && e->y == ly[i]) still[i]++; else still[i] = 0;
                    lx[i] = e->x; ly[i] = e->y;
                    if (still[i] == 240)
                    {
                        stuck++;
                        if (shown < 6) { shown++; printf("  board %d: worker %d stuck at x=%d y=%d (col %d row %d) carry=%d warrior=%d inputs=%d\n",
                            l, i, px(e->x), px(e->y), colof(px(e->x) + 6), rowof(px(e->y) + 12), e->carry, e->warrior, e->inp); }
                    }
                }
            }
        }
    printf("stuck workers: %ld in %ld matches\n", stuck, matches);
}
