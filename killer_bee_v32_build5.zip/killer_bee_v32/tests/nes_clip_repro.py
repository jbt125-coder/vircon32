import sys
# usage: python3 nes_clip_repro.py /path/to/killer_bee/tests/test_rom.py  (NES project, needs cynes)
__file__ = sys.argv[1]; sys.argv = ['x']
exec(open(__file__).read().split("def check(")[0])
from cynes import NES
nes=NES(ROM)
for _ in range(30): nes.controller=0; nes.step(1)
nes[L['force_level']]=1
for p in (0x10,0x10,0,0): nes.controller=p; nes.step(1)
def W(n,v,i=0): nes[L[n]+i]=v&255
def R(n,i=0): return nes[L[n]+i]
for _ in range(10): nes.controller=0; nes.step(1)
# park everyone else far away
for e in (1,2,3,4,5): W('ealive',0,e); W('etimer',250,e)
W('ex',80); W('ey',96); W('eylo',0xF0); W('evyh',0xFF); W('evyl',0xF0); W('eground',0); W('eface',0); W('ecool',0); W('edrop',0)
log=[]
for f in range(60):
    for e in (1,2,3,4,5): W('ealive',0,e); W('etimer',250,e)
    nes.controller = 0x40 if f<2 else 0
    nes.step(1)
    log.append((f,R('ex'),R('ey'),R('eatk'),R('eground')))
for l in log[:40]: print(l)
print("final y",R('ey'),"(plank top 112 => standing y is 96)")
