# KILLER BEE for Vircon32 (test build 5)

## New in test build 5
- **Bonus round: HONEYCOMB HOOPS**. After every match, START on the result screen begins it.
  - Each team shoots berries into its own **moving honeycomb** (blue left, yellow right; 10 holes each).
  - Berries hang from **vines** under the two upper levels. A queen's sting or dive knocks a berry down, and anyone can grab it. Vines regrow after 5 s.
  - **Throw** at the honeycomb as it moves (shots can go over or under it), or stand on the ground underneath. When it comes down to you, the worker **places** the berry (slower, but sure).
  - Queens can sting each other. A stung queen is out for a while but loses no crown.
  - The first team to fill all 10 holes wins, and **its queen starts the next match with a 4th crown**.
  - The Scorpion King is next. The vote screen comes once both bonus rounds exist.
- **NES CLASSIC art style** (title menu: ART: CLEAN / GRUNGE / NES CLASSIC). It uses the original NES game's own tile art and palettes (`tools/nes_original/`), drawn at exactly 2x for crisp square pixels: the black sky, NES planks, ground, bricks, vines, hives, weapon boxes, bees, snail and berries.
- **Queens redrawn** in Clean and Grunge: wasp-like, with a long striped abdomen. During the stinger dash the abdomen **curls under** and a big silver stinger points forward.

Tested:
- 30/30 gameplay tests pass, including 9 new Hoops tests.
- 200 CPU bonus rounds all finished (about 25 s each), blue 107 vs yellow 93.
- Match balance is within normal variation on every board.
- On the Vircon32 console core: a full match -> Hoops -> next match, 100% speed, with the winner's 4th crown confirmed from memory.

(previous: test build 4)

## New in test build 4: throwing berries + a fairness overhaul
- **Throwing:**
  - A worker carrying a berry presses **B** to throw it forward in an arc, standing, running (farther) or jumping.
  - A berry that lands in **your own hive scores**. One that hits your snail while a teammate rides it gives the **turbo** (same rules as feeding). Otherwise it **lands as a pickup anyone can grab**; dropped berries blink and vanish after 15 s.
  - Next to an empty snail, B still climbs on (keeping the berry, so the 1.5x carried-berry speed still works).
- **CPU throwing:** CPU workers throw only when a throw will land. They use **throw tables** worked out by the build script for every board, position and direction. These match the real berry physics in 73,744 out of 73,744 test throws.
- **Fairness fixes:** a mirror test compared every CPU decision and every bee move against its mirror image. It found several old blue/yellow asymmetries, now fixed:
  - pixel rounding was always downward, so one team was off by a pixel on every check;
  - the yo-yo dodge picked its flee direction from the bees' left edges;
  - small off-by-one deposit and wrap zones;
  - queen tie-breaks;
  - a frame-locked update order.
  Result: every board is within normal random variation over 400 CPU matches per board, and **the old Wrap Hive snail bias is gone**.
- **Console speed:** Vircon32's `>>` does not keep the sign of negative numbers (found with a test ROM). That made the game crawl at 8-50% speed once a bee stood just past the left screen edge; it is fixed.
  - Measured on the console core: **100% speed in every 2-second stretch** of a 110-second run.
  - The CPU throw logic now costs one table lookup per frame.

(previous: test build 3)

## New in test build 3: snail berries
- **A rider carrying a berry** moves the snail 1.5× faster.
- **Feeding:** a teammate carrying a berry who touches the snail while their team is riding feeds it automatically. The berry is used up and the snail goes 2× faster for 3 seconds; feeding again resets the timer.
- **Both together multiply** to 3×. The boost only helps the team that fed it.
- **CPU workers** with a berry go and feed their team's snail when it is close to winning (35% or less of the track left).
- The snail now glides smoothly every frame (same average speed as before) and shows speed streaks while boosted.
- A new "chomp" sound plays on feeding.

Tests:
- Measured distances: ×1.50, ×2.00 and ×3.00.
- The boost lasts exactly 3 s.
- Only teammates feed, and only while their team rides.
- CPU fed 20/20 times when close to winning, 0/20 when far.

(previous: test build 2)

## New in test build 2
- **Grunge art set** (punk/skate meets creepy-realistic). Choose ART: CLEAN / GRUNGE on the title menu.
  - Insect-like bees with faceted compound eyes, hairy thoraxes, jointed legs and veined wings, with neon team stripes.
  - Skate-deck platforms, graffiti brick walls, chain-link fence, torn posters, cinderblock walls, oil-drum hives, and thorny vines with barbed wire on solid-sided boards.
  - Distressed lettering.
- **Stinger dash pose** (both art sets): the queen now curls her abdomen forward so the stinger leads, matching where the dash actually hits. The old art drew it at the back.
- **Down-dash dive (Down + B)**: the queen dives straight down fast (from a platform she drops through it first).
  - It kills any worker or queen right below her, and a kill ends the dive cleanly.
  - If she hits a platform or the ground, she is stunned for half a second, shaking in place, and can be stung.
  - CPU queens dive rarely (never on Easy).
- **CPU difficulty: EASY / NORMAL / HARD** on the title menu. Measured against a sharp scripted player in head-on queen duels (human share of first kills):

  | CPU | Human share |
  |---|---|
  | Easy | 76% |
  | Normal | 50% |
  | Hard | 31% |

  The old CPU (NES behaviour) sat around 35%.
- **Why yellow seemed to win head-to-head:** over 2,000 duels per side, the CPU queen won ~55% of head-on fights from *either* side, so it wasn't a blue/yellow bug. It sees your dash on its very first frame and counter-stings, and most kills happen while the loser's stinger is recharging after a dash. That's what the difficulty setting now controls.
- **Stuck workers fixed.**
  - Workers that froze in place: 57 in 300 CPU matches before, 0 after.
  - All were armed (yo-yo) workers pushing Divide's wall. The NES "stuck" escape only covered unarmed workers, and drop-through attempts were never checked at all.
  - Now every worker checks, failed drops are remembered, and a stuck worker turns around and heads low.
- Bees now update in alternating order each frame, so neither team wins same-frame ties.

A port of the NES game *Killer Bee* to the Vircon32 fantasy console (640×360).
Play it by loading `killer_bee.v32` in the Vircon32 emulator (vircon32.com).

## Controls (Vircon32 gamepad)

| Button | Queen | Worker |
|---|---|---|
| D-pad left/right | Fly / walk | Walk |
| A | Flap (tap to fly) | Jump |
| Down + A | Drop through a platform | Drop through a platform |
| B | Stinger dash | Climb onto / hop off the snail; spin the yo-yo when armed |
| Down + B | Dive straight down (stun if she hits a platform) | |
| **Y, L or R** | **SELECT**: switch to your next bee (queen → worker → worker) | |
| Start | Pause / resume | |

The Vircon32 gamepad has no SELECT button, so Y, L and R all do the SELECT job.
In the emulator's default keyboard setup these are mapped to keys; check
*Controls* in the emulator menu.

## Flow

1. **Title menu**: Up/Down picks a line; Left/Right changes CPU difficulty or art set; Start plays.
2. **Team select** (up to 4 gamepads):
   - Each player presses A to join.
   - Left/Right picks a team.
   - Up/Down, Y, L or R toggles Queen or Worker.
   - A locks in. The **first player to lock in as a team's queen gets her**; anyone after is bumped to worker.
   - B unlocks or backs out.
   - Once everyone who joined is locked in, Start begins the match.
   - Each team gets 3 bees (queen + 2 workers), or 4 if 4 humans join the same team. **The CPU plays every bee no human steers**, so 4 humans can take on 4 CPU bees.
3. **Match**: random board, never the same one twice in a row. The three victories are unchanged: military (sting the enemy queen 3 times), economic (8 berries) and snail.
4. **Result**: Start for a rematch with the same teams; Y, L or R for the title.

## What carried over from the NES version

All gameplay rules and constants:
- the five boards with random no-repeat rotation;
- vines on solid-sided boards;
- Wrap Hive's ceiling-gap/pit wrap and snail trench;
- side warping on the Warp boards;
- Divide's wall, bridge, weapon boxes and yo-yo;
- queen clashes, shields and respawns;
- SELECT bee switching;
- the CPU AI for workers and queens, translated routine by routine from `main.s`;
- four music styles that switch on big moments at most once every 4 s, with a random starting octave and a possible octave jump on each loop.

The boards keep the NES 32×30 grid, but each cell is now 20×12 px. Boards are 2.5× wider while bees are 1.5× bigger and move at NES speeds × 1.5, so matches are roomier and a bit longer, as chosen.

## New for Vircon32

- **Art**: all redrawn, original, procedurally drawn with outlines, gradients and anti-aliasing (`tools/gen_art.py`). Text uses DejaVu Sans Bold (free licence).
- **Audio**: every instrument, drum and sound effect is synthesized by `tools/gen_audio.py`. The songs keep your NES melodies and add new layers:
  - harmony lines (twin guitars in metal);
  - sustained chords;
  - an arpeggio (fun);
  - fuller drum parts with hats, crashes, toms and fills.
- **Players**: up to 4 gamepads and the team-select screen.

## Fixed NES bugs

**1. The queen could sink through a platform after a dash.**
I reproduced this in the real `killer_bee.nes` with the cynes emulator (`tests/nes_clip_repro.py`). The queen dashes over a Meadow plank with her feet level with its top, then falls 48 px through it.

The cause: the NES landing check only landed a bee if its whole-pixel fall speed was at least as large as how far its feet were into the tile (`evyh >= feet&7`). The dash zeroed the speed but left the sub-pixel fraction (`eylo`). On the next gravity tick the feet rolled 1 px into the plank at whole-pixel speed 0, so the landing check failed every frame.

The port asks the right question instead: did the feet reach or cross a plank top since last frame? Tests:
- 3,968 dash starts (every sub-pixel fraction × speed): 0 clips. With the NES rule put back, 155 clip, so the test catches the bug.
- 200 CPU matches: no bee ever passes down through a plank without dropping.

**2. The CPU favoured yellow on Divide.**
Measured over 400 CPU-vs-CPU matches per run:

| Run | Blue | Yellow |
|---|---|---|
| Before | 136 | 263 |
| Both queens hunt at the same time | 180 | 220 |
| Hunt windows swapped | 235 | 165 |
| After the fix | 192 | 208 (statistically even) |

The main cause: the CPU queens hunt in alternating windows, and blue *always* got the first one. Which team goes first is now drawn at random each match.

I also made every yellow-side position an exact mirror of blue's. The NES had the yellow queen's guard post and home target 16 px off-mirror.

## Building

Requirements:
- `python3` with `numpy` and `pillow`: `pip install numpy pillow`.
- The official Vircon32 DevTools: `compile`, `assemble`, `png2vircon`, `wav2vircon`, `packrom`.
  - Windows/Linux/Mac: download the DevTools from vircon32.com (Downloads), unzip, and add the folder to PATH or set `V32TOOLS=/path/to/tools`.
  - Or build them from source on Linux:
    ```
    sudo apt install cmake g++ libsdl2-dev libpng-dev
    git clone https://github.com/vircon32/ComputerSoftware
    cd ComputerSoftware/DevelopmentTools && mkdir build && cd build && cmake .. && make
    ```
    The compiler needs its `include` folder (`DevelopmentTools/Data/include`) next to the `compile` binary.

Then run:
```
./build.sh                      # or: V32TOOLS=/path/to/devtools ./build.sh
```
This regenerates levels, art and audio from source, converts them, compiles `src/main.c`, and packs `killer_bee.v32`.

## Tests

`tests/run_tests.sh` compiles the same gameplay sources with gcc (via `tools/to_host_c.py`, which converts the Vircon32 C dialect). It runs the clipping tests, board rotation, team-select rules, SELECT cycling, 4-player team sizes, and 200 CPU-vs-CPU matches checking that all three victories happen.

`tests/run_tests.sh balance 400` prints the win balance per board.

## What was actually tested

- **Gameplay core**: the automated PC tests above, 9/9 passing.
- **The ROM**: run headless on the **official Vircon32 console core** (CPU/GPU/SPU code from the emulator source) with a small software renderer of mine, scripted gamepad input and screenshots. Verified:
  - boot; the title and team-select screens (2 players joining, team switching, lock-in);
  - matches running on several boards with CPU and human-controlled bees;
  - HUD meters and crowns, pause, an economic victory and the result screen;
  - different boards for different start times;
  - audio output present and not clipping.
- **Not tested**:
  - I could not run the regular Vircon32 desktop emulator interactively here.
  - Nobody has played it with a real gamepad.
  - I measured the audio but have not listened to it, so the mix and arrangements may need tuning.
  - I did not specifically screenshot the Divide board in the ROM (its art is in `screens/07`), the yo-yo or a 4-gamepad match on the console. Those are covered only by the gameplay tests.

## Known issues / still to do

- **Wrap Hive snail imbalance:** blue still gets more snail wins on Wrap Hive (11 vs 0 in 300 CPU matches). Processing order was ruled out; the cause is still open.
- Art is a first pass. The workers' wings and the queen's flight animation could use more frames.
- The music arrangements are built from your melodies plus automatic harmony and chords; they may want hand-tuning once heard.

## Files

```
killer_bee.v32        the ROM
build.sh, rom.xml     reproducible build
src/                  main.c (Vircon32 layer), game.c/ai.c/flow.c (gameplay), game.h,
                      generated levels.h / art.h / music.h
tools/                gen_levels.py, gen_art.py, gen_audio.py, to_host_c.py
assets/               generated PNG / WAV sources
build/tex, build/snd  converted textures (.vtex, both art sets) and sounds (.vsnd)
tests/                PC test suite, balance report, NES clip repro
screens/              screenshots captured from the ROM
```
