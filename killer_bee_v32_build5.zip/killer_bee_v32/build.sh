#!/bin/bash
# KILLER BEE for Vircon32 - reproducible build.
# Needs: python3 with numpy + pillow, and the official Vircon32 DevTools
# (compile, assemble, png2vircon, wav2vircon, packrom) on PATH or in $V32TOOLS.
set -e
cd "$(dirname "$0")"
T=${V32TOOLS:-}
tool() { if [ -n "$T" ]; then echo "$T/$1"; else echo "$1"; fi; }
mkdir -p build/obj build/tex build/snd assets
echo "== generating levels, art and audio"
python3 tools/gen_levels.py src
python3 tools/gen_art.py assets src
python3 tools/gen_audio.py assets src
echo "== converting textures"
$(tool png2vircon) assets/sprites.png -o build/tex/sprites.vtex
$(tool png2vircon) assets/sprites_grunge.png -o build/tex/sprites_grunge.vtex
$(tool png2vircon) assets/sprites_nes.png -o build/tex/sprites_nes.vtex
for i in 0 1 2 3; do
  $(tool png2vircon) assets/bg$i.png -o build/tex/bg$i.vtex
  $(tool png2vircon) assets/gbg$i.png -o build/tex/gbg$i.vtex
  $(tool png2vircon) assets/nbg$i.png -o build/tex/nbg$i.vtex
done
echo "== converting sounds"
SOUNDS=""
while read -r s; do
  $(tool wav2vircon) assets/snd_$s.wav -o build/snd/$s.vsnd
  SOUNDS="$SOUNDS        <sound path=\"build/snd/$s.vsnd\" />\n"
done < assets/sounds.txt
echo "== compiling"
$(tool compile) src/main.c -o build/obj/main.asm
$(tool assemble) build/obj/main.asm -o build/obj/main.vbin
cat > rom.xml <<XML
<rom-definition version="1.0">
    <rom type="cartridge" title="Killer Bee" version="1.0" />
    <binary path="build/obj/main.vbin" />
    <textures>
        <texture path="build/tex/sprites.vtex" />
        <texture path="build/tex/bg0.vtex" />
        <texture path="build/tex/bg1.vtex" />
        <texture path="build/tex/bg2.vtex" />
        <texture path="build/tex/bg3.vtex" />
        <texture path="build/tex/sprites_grunge.vtex" />
        <texture path="build/tex/gbg0.vtex" />
        <texture path="build/tex/gbg1.vtex" />
        <texture path="build/tex/gbg2.vtex" />
        <texture path="build/tex/gbg3.vtex" />
        <texture path="build/tex/sprites_nes.vtex" />
        <texture path="build/tex/nbg0.vtex" />
        <texture path="build/tex/nbg1.vtex" />
        <texture path="build/tex/nbg2.vtex" />
        <texture path="build/tex/nbg3.vtex" />
    </textures>
    <sounds>
$(printf "$SOUNDS")
    </sounds>
</rom-definition>
XML
$(tool packrom) rom.xml -o killer_bee.v32
echo "== built killer_bee.v32 ($(stat -c %s killer_bee.v32) bytes)"
